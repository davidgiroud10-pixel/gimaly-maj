"""Lance le bot de trading (recepteur de signaux) et le relance s'il s'arrete (remplace le moteur GIMALY).
Mise a jour automatique : au demarrage puis toutes les 30 min, il cherche une nouvelle version signee par
l'editeur (maj_auto.py), l'installe, la teste (retour arriere si elle echoue) et se relance tout seul.
Arret propre : creer le fichier ~/GIMALY/trading/lanceur.stop (ou Ctrl+C dans cette fenetre)."""
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

RACINE = Path(__file__).resolve().parent
DOSSIER = Path.home() / "GIMALY" / "trading"
STOP_TRADES = DOSSIER / "icebergs.stop"      # arret des trades (le detecteur ne repart pas tant qu'il existe)
STOP_BOT = DOSSIER / "bot.stop"              # arret complet du bot
STOP_LANCEUR = DOSSIER / "lanceur.stop"
FLAG_REDEMARRAGE = DOSSIER / "redemarrage_bot.flag"   # pose par attribution.py : un nouvel identifiant attend un redemarrage du bot
ATTENTE_RELANCE = 60                         # secondes minimum entre deux demarrages d'un meme processus
PROCESSUS = {
    "bot": ["-u", "-m", "gimaly.trading.trading", "--boucle"],
}
MODULE_DE_TEST = os.environ.get("GIMALY_LANCEUR_TEST") == "1"
PERIODE_MAJ = float(os.environ.get("GIMALY_MAJ_PERIODE") or 30 * 60)    # secondes entre deux verifications


def journal(texte):
    DOSSIER.mkdir(parents=True, exist_ok=True)
    ligne = f"{time.strftime('%d/%m/%Y %H:%M:%S')}  {texte}"
    try:
        print(ligne, flush=True)
    except Exception:
        pass
    with open(DOSSIER / "lanceur.log", "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


CONFIG = RACINE / "config.local.yaml"
_CONFIG_SIGNALEE = {"msg": None}


def verifier_config():
    """True si config.local.yaml est lisible. Sinon le bot retombe en silence sur ses valeurs par defaut (inactif, sans
    signaux) : on repare le cas connu (chemin MT5 entre guillemets doubles) ou on le dit clairement."""
    import re
    try:
        import yaml
    except ImportError:
        return True
    try:
        brut = CONFIG.read_bytes()
    except OSError:
        return True
    erreur = ""
    try:
        texte = brut.decode("utf-8-sig")
        yaml.safe_load(texte)
        _CONFIG_SIGNALEE["msg"] = None
        return True
    except Exception as exc:  # noqa: BLE001
        erreur = (str(exc).splitlines() or [repr(exc)])[0]
        texte = brut.decode("utf-8-sig", "replace")
    nouveau = re.sub(r'(?m)^(trading_mt5_chemin:[ \t]*)"([^"\r\n]*)"',
                     lambda m: m.group(1) + "'" + m.group(2).replace("'", "''") + "'", texte)
    if nouveau != texte:
        try:
            yaml.safe_load(nouveau)
            copie = CONFIG.with_name("config.local.yaml.avant_reparation")
            if not copie.exists():
                copie.write_bytes(brut)
            CONFIG.write_bytes((b"\xef\xbb\xbf" if brut.startswith(b"\xef\xbb\xbf") else b"") + nouveau.encode("utf-8"))
            journal("config.local.yaml : ligne trading_mt5_chemin reparee (guillemets doubles illisibles pour le bot)")
            _CONFIG_SIGNALEE["msg"] = None
            return True
        except Exception:  # noqa: BLE001
            pass
    msg = (f"ALERTE config.local.yaml illisible ({erreur}) : le bot tourne avec ses valeurs par defaut, donc SANS trader. "
           f"Previens l'editeur.")
    if _CONFIG_SIGNALEE["msg"] != msg:
        journal(msg)
        _CONFIG_SIGNALEE["msg"] = msg
    return False


_VERROU_MT5 = threading.Lock()


def compte_demo():
    with _VERROU_MT5:                                  # le signe de vie l'appelle aussi, depuis un autre fil
        return _compte_demo()


def _compte_demo():
    """True si le compte MT5 connecte est un compte DEMO ; False si reel/concours ; None si on ne peut pas le savoir."""
    try:
        import MetaTrader5 as mt5
        if not mt5.initialize():
            return None
        try:
            compte = mt5.account_info()
            if compte is not None:
                try:
                    from gimaly.trading.symbole import assurer
                    assurer(mt5)
                except Exception:
                    pass
            return None if compte is None else compte.trade_mode == 0
        finally:
            mt5.shutdown()
    except Exception:
        return None


def positions_ouvertes():
    """Nombre de positions ouvertes sur le compte MT5, ou None si on ne peut pas le savoir."""
    with _VERROU_MT5:
        try:
            import MetaTrader5 as mt5
            if not mt5.initialize():
                return None
            try:
                return mt5.positions_total()
            finally:
                mt5.shutdown()
        except Exception:
            return None


def redemarrage_possible(maj):
    """Redemarrer le bot sans risque : marche de l'or ferme, ou aucune position ouverte."""
    try:
        if maj is not None and maj.marche_ferme():
            return True
    except Exception:  # noqa: BLE001
        pass
    return positions_ouvertes() == 0


def maj_disponible():
    try:
        import maj_auto
        return maj_auto
    except Exception as exc:  # noqa: BLE001 - jamais bloquant
        journal(f"mise a jour automatique indisponible : {exc!r}")
        return None


def pret_pour_maj(maj, procs):
    """Installer une mise a jour sans gener un trade : marche ferme, ou aucune position ouverte sur le compte.
    Si MetaTrader ne repond pas et que le bot ne tourne pas, il n'y a rien a proteger."""
    try:
        if maj is not None and maj.marche_ferme():
            return True
    except Exception:  # noqa: BLE001
        pass
    n = positions_ouvertes()
    if n == 0:
        return True
    if n is None:
        p = procs.get("bot")
        return p is None or p.poll() is not None
    return False


_ECOUTE = {"rec": None, "secret": None, "verifie": 0.0, "erreur": ""}


def ecouter_commandes():
    """Ordres de l'editeur (« mets-toi a jour maintenant ») : canal PRIVE a part, signe Ed25519, lu par le lanceur lui-meme
    (donc meme si le bot est arrete). Renvoie le recepteur, ou None."""
    if time.time() - _ECOUTE["verifie"] < 60:
        return _ECOUTE["rec"]
    _ECOUTE["verifie"] = time.time()
    try:
        import retour
        from gimaly.trading import signaux_distants as sd
        secret = retour.lire_config().get("trading_signaux_secret")
        if not secret or sd.cle_publique_installee() is None:
            return _ECOUTE["rec"]
        if secret != _ECOUTE["secret"]:
            if _ECOUTE["rec"] is not None:
                _ECOUTE["rec"].arreter()
            rec = sd.Recepteur(sd.canal_commande(secret), secret, journal=journal)
            rec.suivre_dernier = False
            rec.demarrer()
            _ECOUTE["rec"], _ECOUTE["secret"] = rec, secret
    except Exception as exc:  # noqa: BLE001 - jamais bloquant
        if _ECOUTE["erreur"] != repr(exc):
            _ECOUTE["erreur"] = repr(exc)
            journal(f"ecoute des ordres de l'editeur : erreur ignoree {exc!r}")
    return _ECOUTE["rec"]


def moment_ok(manifeste, maj):
    """Quand installer : "immediat" tout de suite ; "week-end" marche de l'or ferme ; "demarrage" au prochain
    demarrage du lanceur seulement."""
    quand = manifeste.get("quand", "demarrage")
    return quand == "immediat" or (quand == "week-end" and maj.marche_ferme())


def relancer_lanceur(procs, verrou):
    """Arrete le bot, libere le verrou et demarre un nouveau lanceur (avec le nouveau code)."""
    journal("relance du lanceur avec la nouvelle version")
    for p in procs.values():
        if p is not None and p.poll() is None:
            p.terminate()
    time.sleep(3)
    for p in procs.values():
        if p is not None and p.poll() is None:
            p.kill()
    try:
        (DOSSIER / "lanceur_vivant.txt").unlink()
    except OSError:
        pass
    verrou.close()
    options = {}
    if os.name == "nt":
        options["creationflags"] = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
    subprocess.Popen([sys.executable, str(RACINE / "lancer.py")], cwd=str(RACINE), close_fds=True,
                     env={**os.environ, "GIMALY_RELANCE": "1", "GIMALY_APRES_MAJ": "1"}, **options)
    if sys.stdout is not None and getattr(sys.stdout, "isatty", lambda: False)():
        print("Mise a jour installee : le bot continue en arriere-plan. Tu peux fermer cette fenetre.")


def demarrer(nom):
    sortie = open(DOSSIER / f"{nom}_sortie.log", "a", encoding="utf-8")
    options = {}
    if os.name == "nt":
        options["creationflags"] = subprocess.CREATE_NO_WINDOW
    return subprocess.Popen([sys.executable] + PROCESSUS[nom], cwd=str(RACINE), stdout=sortie,
                            stderr=subprocess.STDOUT, **options)


def autorise(nom):
    demo = compte_demo()
    if demo is None:
        return False, "compte MT5 introuvable (MT5 ouvert et connecte ?) : rien n'est lance"
    if demo is False:
        return False, "compte REEL detecte : cette version ne trade QUE sur un compte DEMO, rien n'est lance"
    if nom == "detecteur" and STOP_TRADES.exists():
        return False, "arret des trades demande (icebergs.stop) : detecteur non lance"
    if nom == "bot" and STOP_BOT.exists():
        return False, "arret du bot demande (bot.stop) : bot non lance"
    return True, ""


def main():
    DOSSIER.mkdir(parents=True, exist_ok=True)
    import socket
    verrou = socket.socket(socket.AF_INET, socket.SOCK_STREAM)      # un seul lanceur a la fois
    for essai in range(30 if os.environ.get("GIMALY_RELANCE") == "1" else 1):    # apres une mise a jour : l'ancien lanceur se ferme
        try:
            verrou.bind(("127.0.0.1", 47824))
            break
        except OSError:
            if essai == 29 or os.environ.get("GIMALY_RELANCE") != "1":
                print("Un lanceur tourne deja : ce lancement est annule.")
                return
            time.sleep(1)
    if STOP_LANCEUR.exists():
        STOP_LANCEUR.unlink()
    procs, dernier, signale, verifie = {}, {}, {}, {}
    journal("lanceur demarre (Ctrl+C ou fichier lanceur.stop pour l'arreter)")
    verifier_config()
    try:
        import identifiant
        message = identifiant.auto()
        if message:
            journal(message)
    except Exception as exc:  # noqa: BLE001 - l'identifiant ne doit jamais empecher le bot de demarrer
        journal(f"identifiant : erreur ignoree {exc!r}")
    try:
        FLAG_REDEMARRAGE.unlink()                      # le bot demarre maintenant : il lira le nouvel identifiant
    except OSError:
        pass
    maj = maj_disponible()
    prochaine_maj, en_attente = 0.0, None
    forcer_fin, attente_depuis, prochain_test_maj, signale_maj = 0.0, None, 0.0, False
    prochain_retour = 0.0
    debut_retour = time.time() + 45            # le bot a le temps de demarrer avant le 1er signe de vie (sinon « arrete » a tort)
    retour_etat = {"etat": None, "sig": 0.0, "envoi": 0.0, "evts": []}
    if maj is not None and os.environ.get("GIMALY_APRES_MAJ") != "1":
        try:
            etat, msg = maj.verifier_et_appliquer(lambda m: True)        # au demarrage : on installe tout de suite
            journal(f"mise a jour : {msg}")
            prochaine_maj = time.time() + PERIODE_MAJ
            if etat == "installee":
                relancer_lanceur(procs, verrou)
                return
        except Exception as exc:  # noqa: BLE001
            journal(f"mise a jour : erreur ignoree {exc!r}")
    try:
        while not STOP_LANCEUR.exists():
            rec_cmd = ecouter_commandes()
            if rec_cmd is not None:
                for ordre in rec_cmd.recuperer():
                    if ordre.get("cmd") == "maj":
                        journal("ordre de mise a jour recu de l'editeur")
                        forcer_fin, prochaine_maj = time.time() + 600, 0.0
            if maj is not None:
                try:
                    if time.time() >= prochaine_maj:
                        prochaine_maj = time.time() + PERIODE_MAJ
                        nouveau, msg = maj.chercher()            # toujours la plus recente version signee
                        if nouveau is not None:
                            if en_attente is None or nouveau.get("numero") != en_attente.get("numero"):
                                journal(f"mise a jour : {msg}")
                            en_attente = nouveau
                        else:
                            if msg.startswith("a jour"):
                                en_attente = None
                                if time.time() < forcer_fin:
                                    prochaine_maj = time.time() + 120      # ordre recu : le cache de GitHub peut retarder la version
                            else:
                                journal(f"mise a jour : {msg}")
                    pret = False
                    if en_attente is not None and (time.time() < forcer_fin or moment_ok(en_attente, maj)):
                        if attente_depuis is None:
                            attente_depuis = time.time()
                        if time.time() >= prochain_test_maj:
                            prochain_test_maj = time.time() + 30
                            pret = pret_pour_maj(maj, procs) or time.time() - attente_depuis > 4 * 3600
                            if not pret and not signale_maj:
                                signale_maj = True
                                journal("mise a jour en attente : un trade est ouvert (installation des qu'il sera ferme)")
                    if pret:
                        ok, msg = maj.appliquer(en_attente)
                        journal(f"mise a jour : {msg}")
                        en_attente, attente_depuis, signale_maj = None, None, False
                        if ok:
                            relancer_lanceur(procs, verrou)
                            return
                except Exception as exc:  # noqa: BLE001 - la mise a jour ne doit jamais arreter le bot
                    journal(f"mise a jour : erreur ignoree {exc!r}")
                    en_attente = None
            try:
                (DOSSIER / "lanceur_vivant.txt").write_text(str(time.time()), encoding="utf-8")
            except OSError:
                pass
            maintenant = time.time()
            vivant = procs.get("bot") is not None and procs["bot"].poll() is None
            etat_cour = "arrete" if not vivant else ("pause" if STOP_TRADES.exists() else "actif")
            try:
                sig_cour = (DOSSIER / "dernier_signal.txt").stat().st_mtime
            except OSError:
                sig_cour = 0.0
            retour_etat["evts"] = [t for t in retour_etat["evts"] if maintenant - t < 3600]
            evenement = (maintenant - retour_etat["envoi"] >= 30 and len(retour_etat["evts"]) < 12
                         and (etat_cour != retour_etat["etat"] or sig_cour != retour_etat["sig"]))
            if maintenant >= debut_retour and (maintenant >= prochain_retour or evenement):   # signe de vie vers l'editeur (retour.py)
                if maintenant < prochain_retour:
                    retour_etat["evts"].append(maintenant)       # hors cadence : changement d'etat ou signal recu
                prochain_retour = maintenant + 600
                try:
                    import retour
                    etat_bot = etat_cour
                    if vivant and not verifier_config():
                        etat_bot = "config"              # visible dans la fenetre Amis de l'editeur
                    retour.battement(etat_bot, compte_demo, journal)
                    retour_etat.update(etat=etat_cour, sig=sig_cour, envoi=maintenant)
                except Exception as exc:  # noqa: BLE001 - le signe de vie ne doit jamais gener le bot
                    journal(f"retour : erreur ignoree {exc!r}")
            if FLAG_REDEMARRAGE.exists():                        # nouvel identifiant installe (attribution.py)
                p = procs.get("bot")
                if p is None or p.poll() is not None:
                    FLAG_REDEMARRAGE.unlink()                   # le bot ne tourne pas : il lira le nouvel identifiant
                elif redemarrage_possible(maj):
                    journal("nouvel identifiant installe : redemarrage du bot")
                    FLAG_REDEMARRAGE.unlink()
                    p.terminate()
            for nom in PROCESSUS:
                p = procs.get(nom)
                if p is not None and p.poll() is None:
                    if time.time() - verifie.get(nom, 0) > 60:
                        verifie[nom] = time.time()
                        if compte_demo() is False:
                            journal(f"compte REEL detecte : arret de {nom}")
                            p.terminate()
                    continue
                if p is not None:
                    journal(f"{nom} arrete (code {p.returncode})")
                    procs[nom] = None
                ok, motif = autorise(nom)
                if not ok:
                    if signale.get(nom) != motif:
                        journal(motif)
                        signale[nom] = motif
                    continue
                signale[nom] = None
                if time.time() - dernier.get(nom, 0) < ATTENTE_RELANCE:
                    continue
                procs[nom] = demarrer(nom)
                dernier[nom] = time.time()
                journal(f"{nom} demarre (pid {procs[nom].pid})")
            time.sleep(2 if MODULE_DE_TEST else 5)
    except KeyboardInterrupt:
        pass
    journal("arret du lanceur : arret des processus")
    try:
        (DOSSIER / "lanceur_vivant.txt").unlink()
    except OSError:
        pass
    for nom, p in procs.items():
        if p is not None and p.poll() is None:
            p.terminate()
    time.sleep(2)
    for nom, p in procs.items():
        if p is not None and p.poll() is None:
            p.kill()


if __name__ == "__main__":
    main()
