@echo off
cd /d %~dp0
.venv\Scripts\python.exe compte_mt5.py
