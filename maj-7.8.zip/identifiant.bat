@echo off
cd /d %~dp0
.venv\Scripts\python.exe identifiant.py %1
echo.
pause
