"""Bilan des trades REELS du bot depuis une date (trades_bot.csv) : par type, par jour, par sens.
Aucune simulation, aucun fantome. Ne modifie rien.

Une sortie « stop loss » avec un R entre -0,9 et 0 n'est pas un vrai SL (fermeture manuelle ou
sortie anticipee) : elle est comptee a part dans la colonne « hors SL/TP ».

Usage (depuis le dossier du paquet) :
  .\\.venv\\Scripts\\python.exe bilan_reel.py --depuis 19/10/2026
"""
import argparse
import csv
from collections import defaultdict
from datetime import datetime
from pathlib import Path

DOSSIER = Path.home() / "GIMALY" / "trading"


def nombre(x):
    try:
        return float(str(x).replace(",", "."))
    except (TypeError, ValueError):
        return None


def charger(depuis):
    with open(DOSSIER / "trades_bot.csv", encoding="utf-8-sig", errors="replace") as fh:
        lignes = list(csv.DictReader(fh, delimiter=";"))
    trades = {}
    for l in lignes:
        try:
            dt = datetime.strptime(f"{l['date']} {l['heure']}", "%d/%m/%Y %H:%M:%S")
        except (KeyError, ValueError):
            continue
        t = trades.setdefault(l["message_id"], {"ouv": dt, "genre": l["genre"], "sens": l["sens"], "R": None,
                                                "res": "ouvert", "ligue": None, "gain": None,
                                                "vol": nombre(l.get("volume")), "pe": nombre(l.get("pe")),
                                                "sl": nombre(l.get("sl"))})
        if l["resultat"] != "ouvert":
            t["sortie"], t["res"], t["R"] = dt, l["resultat"], nombre(l.get("R"))
            t["ligue"], t["gain"] = nombre(l.get("resultat_ligue_pct")), nombre(l.get("gain_devise"))
    return [t for t in trades.values() if t["ouv"] >= depuis]


def manuel(t):
    if t["res"] == "fermeture manuelle":
        return True
    if not (t["res"] == "stop loss" and t["R"] is not None and -0.9 < t["R"] < 0):
        return False
    # un vrai stop coute ~0,89 x (volume x 100 x distance du stop) en euros (change) : pas une sortie a la main
    if None not in (t["vol"], t["pe"], t["sl"], t["gain"]):
        cout = t["vol"] * 100 * abs(t["pe"] - t["sl"])
        if cout and 0.82 <= t["gain"] / -cout <= 0.96:
            return False
    return True


def ligne(nom, ts):
    rs = [t["R"] for t in ts]
    g = sum(r > 0 for r in rs)
    hors = sum(manuel(t) for t in ts)
    return (f"  {nom:<26}{len(rs):>4}{g / len(rs):>8.0%}{sum(rs):>+9.2f}R{sum(rs) / len(rs):>+8.2f}R{hors:>6}")


def tableau(titre, cles, finis):
    groupes = defaultdict(list)
    for t in finis:
        groupes[cles(t)].append(t)
    print(f"\n{titre}")
    print(f"  {'':<26}{'n':>4}{'gagn.':>8}{'total':>10}{'moyen':>9}{'hors SL/TP':>11}")
    for k in sorted(groupes):
        print(ligne(k, groupes[k]))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--depuis", default="19/10/2026")
    depuis = datetime.strptime(p.parse_args().depuis, "%d/%m/%Y")
    trades = charger(depuis)
    finis = sorted((t for t in trades if t["R"] is not None), key=lambda t: t["ouv"])
    ouverts = [t for t in trades if t["R"] is None]
    if not finis:
        raise SystemExit("aucun trade termine")
    print(f"\nTrades reels depuis le {depuis:%d/%m/%Y} : {len(finis)} termines, {len(ouverts)} ouverts")
    rs = [t["R"] for t in finis]
    cum, pire, haut, bas = 0.0, 0.0, 0.0, 0.0
    for r in rs:
        cum += r
        haut = max(haut, cum)
        pire = min(pire, cum - haut)
    print(f"Total {sum(rs):+.2f}R | {sum(r > 0 for r in rs) / len(rs):.0%} gagnants | "
          f"moyenne {sum(rs) / len(rs):+.2f}R | pire baisse depuis un sommet {pire:+.2f}R")
    gains = [t["gain"] for t in finis if t["gain"] is not None]
    ligues = [t["ligue"] for t in finis if t["ligue"] is not None]
    if gains:
        print(f"Argent reel : {sum(gains):+.2f} (devise du compte)")
    if ligues:
        print(f"Ligue (somme de resultat_ligue_pct, theorique) : {sum(ligues):+.2f} %")
    tableau("PAR TYPE", lambda t: t["genre"], finis)
    tableau("PAR TYPE ET SENS", lambda t: f"{t['genre']} {t['sens']}", finis)
    tableau("PAR JOUR", lambda t: t["ouv"].strftime("%d/%m %a"), finis)
    print("\nDERNIERS TRADES")
    for t in finis[-12:]:
        marque = "  (hors SL/TP)" if manuel(t) else ""
        print(f"  {t['ouv']:%d/%m %H:%M}  {t['genre']:<20}{t['sens']:<7}{t['res']:<12}{t['R']:>+6.2f}R{marque}")
    print("\n'hors SL/TP' : sortie a la main ou anticipee, comptee dans le total.")
    print("Petits echantillons : la moyenne par type n'est pas fiable sous une trentaine de trades.\n")


if __name__ == "__main__":
    main()
