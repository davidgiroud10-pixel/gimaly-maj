@echo off
cd /d %~dp0
echo.
echo ==============================================================
echo   GIMALY Trading - installation guidee
echo ==============================================================
echo.
set PYTHON=
py -3 --version >nul 2>&1 && set PYTHON=py -3
if "%PYTHON%"=="" python --version >nul 2>&1 && set PYTHON=python
if not "%PYTHON%"=="" goto python_ok
echo Python n'est pas installe sur ce PC.
where winget >nul 2>&1
if errorlevel 1 goto sans_winget
choice /C ON /M "Installer Python automatiquement maintenant (O = oui, N = non)"
if errorlevel 2 goto sans_winget
winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
echo.
echo Python est installe. FERME cette fenetre, puis double-clique de nouveau sur installer.bat.
pause
exit /b 0
:sans_winget
echo.
echo Installe Python depuis la page qui va s'ouvrir : clique sur le bouton jaune "Download Python",
echo ouvre le fichier, COCHE "Add python.exe to PATH" en bas, puis "Install Now".
echo Ensuite ferme cette fenetre et double-clique de nouveau sur installer.bat.
start https://www.python.org/downloads/
pause
exit /b 1
:python_ok
echo Etape technique : installation des composants ^(1 a 3 minutes, ne ferme pas cette fenetre^)...
%PYTHON% -m venv .venv || (echo PROBLEME : creation de l'environnement impossible. Envoie-moi une capture d'ecran. & pause & exit /b 1)
.venv\Scripts\python.exe -m pip install --upgrade pip >nul
.venv\Scripts\python.exe -m pip install -r requirements.txt || (echo PROBLEME : installation des composants echouee ^(Internet ? Python 64 bits ?^). & pause & exit /b 1)
.venv\Scripts\python.exe assistant_installation.py
if errorlevel 1 pause
