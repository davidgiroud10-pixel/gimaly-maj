"""Verifie l'installation : MT5 joignable, compte demo, symbole de l'or, trading algo autorise, configuration.
Lance-le AVANT le lanceur (installer.bat le fait deja)."""
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent
DOSSIER = Path.home() / "GIMALY" / "trading"
problemes, avertissements = [], []


def ok(t):
    print("  [OK]       " + t)


def ko(t):
    print("  [PROBLEME] " + t)
    problemes.append(t)


def att(t):
    print("  [ATTENTION]" + " " + t)
    avertissements.append(t)


print("\nVerification de l'installation GIMALY Trading\n")
print(f"Python {sys.version.split()[0]} ({'64 bits' if sys.maxsize > 2**32 else '32 bits : MetaTrader5 exige 64 bits'})")
try:
    import yaml
    cfg = yaml.safe_load((RACINE / "config.local.yaml").read_text(encoding="utf-8")) or {}
    ok("config.local.yaml lisible")
    ok(f"risque par trade : {cfg.get('trading_risque')} % ; perte max par jour : {cfg.get('trading_perte_max_jour')} %")
except Exception as e:
    ko(f"config.local.yaml illisible : {e}")

try:
    import MetaTrader5 as mt5
except ImportError:
    ko("le paquet MetaTrader5 n'est pas installe (relance installer.bat)")
    mt5 = None

if mt5 is not None:
    if not mt5.initialize():
        ko(f"MT5 injoignable : {mt5.last_error()}. Ouvre MetaTrader 5, connecte-toi a ton compte, puis relance.")
    else:
        compte, terminal = mt5.account_info(), mt5.terminal_info()
        if compte is None:
            ko("aucun compte connecte dans MT5")
        else:
            demo = compte.trade_mode == 0
            if demo:
                ok(f"compte {compte.login} sur {compte.server} : DEMO")
            else:
                ko(f"compte {compte.login} sur {compte.server} : ce n'est PAS un compte demo. Cette version ne tourne que sur demo : connecte MT5 a un compte demo.")
            ok(f"solde {compte.balance} {compte.currency} (mets-le dans trading_capital)")
        if terminal is not None and not terminal.trade_allowed:
            ko("le trading algorithmique est DESACTIVE dans MT5 (bouton « Algo Trading » en haut, doit etre vert)")
        elif terminal is not None:
            ok("trading algorithmique autorise")
        sys.path.insert(0, str(RACINE))
        from gimaly.trading import symbole as sym
        nom = sym.assurer(mt5)
        if nom is None:
            ko("aucun symbole de l'or (XAUUSD, GOLD...) chez ton courtier : affiche-le dans Market Watch (Ctrl+M)")
        else:
            info = mt5.symbol_info(nom)
            ok(f"or trouve : {nom} (spread {info.spread} points, lot min {info.volume_min})")
        mt5.shutdown()

try:
    DOSSIER.mkdir(parents=True, exist_ok=True)
    ok(f"dossier de donnees : {DOSSIER}")
except OSError as e:
    ko(f"impossible de creer {DOSSIER} : {e}")

print()
if problemes:
    print(f"{len(problemes)} probleme(s) a corriger avant de lancer.\n")
    sys.exit(1)
print("Tout est bon. Tu peux ouvrir le panneau (panneau.bat)." + (f" ({len(avertissements)} attention(s) a lire)" if avertissements else "") + "\n")
