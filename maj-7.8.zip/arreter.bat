@echo off
if not exist "%USERPROFILE%\GIMALY\trading" mkdir "%USERPROFILE%\GIMALY\trading"
type nul > "%USERPROFILE%\GIMALY\trading\icebergs.stop"
echo Arret des trades demande : plus aucun nouveau trade. Les trades ouverts gardent leur SL et leur TP.
echo Pour reprendre : reprendre.bat
pause
