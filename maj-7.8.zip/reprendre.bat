@echo off
del "%USERPROFILE%\GIMALY\trading\icebergs.stop" 2>nul
echo Reprise : le bot reprend les nouveaux signaux (le lanceur doit tourner).
pause
