# -*- coding: utf-8 -*-
"""Choisir le compte MetaTrader 5 sur lequel le bot a le droit de trader (lance par compte.bat).

On ne saisit que le NUMERO du compte (jamais de mot de passe). Le bot ne trade que si MetaTrader 5 est
connecte a ce compte ; sinon il attend et l'ecrit dans le journal. Pris en compte en moins d'une minute,
sans redemarrer.
"""
import re
import sys
from pathlib import Path

CONFIG = Path(__file__).resolve().parent / "config.local.yaml"
CLE = "trading_mt5_compte"


def lire_voulu():
    try:
        m = re.search(r"(?m)^%s:[ \t]*(\d+)" % CLE, CONFIG.read_text(encoding="utf-8-sig"))
    except OSError:
        return 0
    return int(m.group(1)) if m else 0


def ecrire(valeur):
    texte = CONFIG.read_text(encoding="utf-8-sig")
    motif = re.compile(r"(?m)^%s:[ \t]*[^#\n]*?([ \t]*#.*)?$" % CLE)
    ligne = "%s: %s" % (CLE, valeur)
    if motif.search(texte):
        texte = motif.sub(lambda m: ligne + (m.group(1) or ""), texte, count=1)
    else:
        texte = (texte.rstrip("\n") + "\n\n# compte MT5 sur lequel le bot a le droit de trader (0 = celui qui est actif)\n"
                 + ligne + "\n")
    CONFIG.write_text(texte, encoding="utf-8", newline="")


def compte_actif():
    try:
        import MetaTrader5 as mt5
        if not mt5.initialize():
            return None
        info = mt5.account_info()
        mt5.shutdown()
        return info
    except Exception:
        return None


def main():
    print("COMPTE MT5 DU BOT")
    print("-----------------")
    voulu = lire_voulu()
    print("Compte autorise pour le bot : " + (str(voulu) if voulu else "aucun choix (le bot prend le compte actif de MT5)"))
    actif = compte_actif()
    if actif is None:
        print("Compte actif dans MetaTrader 5 : introuvable (MT5 ferme, ou aucun compte connecte)")
    else:
        genre = "DEMO" if actif.trade_mode == 0 else "REEL (refuse par le bot)"
        print("Compte actif dans MetaTrader 5 : %s sur %s [%s]" % (actif.login, actif.server, genre))
    print()
    print("  1) Utiliser le compte actif de MetaTrader 5 (connecte-toi d'abord au bon compte dans MT5)")
    print("  2) Taper un numero de compte")
    print("  3) Ne plus restreindre (le bot prend le compte actif de MT5)")
    print("  Entree) Ne rien changer")
    choix = input("\nTon choix : ").strip()
    if choix == "1":
        if actif is None:
            print("Impossible : MetaTrader 5 n'est pas connecte. Ouvre-le, connecte-toi au compte voulu, puis recommence.")
            return 1
        if actif.trade_mode != 0:
            print("Ce compte n'est pas un compte DEMO : le bot refuse de trader dessus. Connecte MT5 a un compte demo.")
            return 1
        ecrire(actif.login)
        print("OK : le bot ne tradera que sur le compte %s." % actif.login)
    elif choix == "2":
        saisie = re.sub(r"\s", "", input("Numero du compte (chiffres seulement) : "))
        if not re.fullmatch(r"\d{4,12}", saisie):
            print("Numero invalide (4 a 12 chiffres, sans lettres). Rien n'a ete change.")
            return 1
        ecrire(int(saisie))
        print("OK : le bot ne tradera que sur le compte %s." % int(saisie))
        print("Pour qu'il trade, MetaTrader 5 doit etre connecte a CE compte (et ce doit etre un compte DEMO).")
    elif choix == "3":
        ecrire(0)
        print("OK : plus de restriction, le bot trade sur le compte actif de MetaTrader 5 (demo uniquement).")
    else:
        print("Rien n'a ete change.")
        return 0
    print("Pris en compte en moins d'une minute, sans redemarrer le bot.")
    return 0


if __name__ == "__main__":
    code = main()
    input("\nAppuie sur Entree pour fermer.")
    sys.exit(code)
