@echo off
cd /d %~dp0
set /p DEPUIS=Depuis quelle date (JJ/MM/AAAA) ?
.venv\Scripts\python.exe bilan_reel.py --depuis %DEPUIS%
pause
