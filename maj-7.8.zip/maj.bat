@echo off
cd /d %~dp0
.venv\Scripts\python.exe maj_auto.py --etat
echo.
echo (journal complet : %USERPROFILE%\GIMALY\trading\maj.log)
pause
