@echo off
cd /d %~dp0
.venv\Scripts\python.exe terminal_dedie.py --assistant
echo.
pause
