@echo off
cd /d %~dp0
echo GIMALY Trading : laisse cette fenetre ouverte. Pour arreter : fermer la fenetre ou arreter.bat puis Ctrl+C.
.venv\Scripts\python.exe lancer.py
pause
