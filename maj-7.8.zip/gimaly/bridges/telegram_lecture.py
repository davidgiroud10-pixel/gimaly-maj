"""Remplace l'envoi Telegram de GIMALY : rien n'est publie. Les messages que le bot publierait sont
ecrits dans ~/GIMALY/trading/publication_locale.log, et on rend un identifiant de message fictif mais
unique (le bot s'en sert pour suivre ses trades)."""
import time
from pathlib import Path

DOSSIER = Path.home() / "GIMALY" / "trading"


def envoyer_signal(config, destination, texte, repondre_a=None):
    DOSSIER.mkdir(parents=True, exist_ok=True)
    fichier = DOSSIER / "publication_locale_id.txt"
    try:
        courant = int(fichier.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        courant = 1000
    courant += 1
    fichier.write_text(str(courant), encoding="utf-8")
    with open(DOSSIER / "publication_locale.log", "a", encoding="utf-8") as f:
        suite = f" (en reponse a {repondre_a})" if repondre_a else ""
        f.write(f"{time.strftime('%d/%m/%Y %H:%M:%S')}  #{courant}{suite}\n{texte}\n---\n")
    return courant
