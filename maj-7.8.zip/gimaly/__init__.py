"""G.I.M.A.L.Y — assistant personnel modulaire."""
__version__ = "0.1.0"
