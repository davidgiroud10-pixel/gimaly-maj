r"""
gimaly/trading/contexte_marche.py - G.I.M.A.L.Y
Ce qui se passe AUTOUR de l'or, et que le flux d'ordres ne dit pas :

  - la session en cours (Asie, Londres, New York, cloture) ;
  - la volatilite du moment : ATR M1 compare a sa moyenne ;
  - le dollar : DXY si ton broker le propose, sinon l'EURUSD inverse ;
  - le calendrier economique (Forex Factory, semaine en cours), pour savoir
    si une annonce a fort impact approche ou vient de tomber.

Chaque signal (iceberg, cycle, balayage) est marque avec ces informations :
le bilan dira ensuite s'il vaut mieux eviter les annonces, ne trader qu'une
session, ou suivre le dollar.

Test :
  .\.venv\Scripts\python.exe -m gimaly.trading.contexte_marche
"""
from __future__ import annotations

import json
import math
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

CALENDRIER_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
CACHE = Path.home() / "GIMALY" / "trading" / "calendrier.json"
CACHE_HEURES = 6
NAVIGATEUR = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/140.0 Safari/537.36")
DEVISES = ("USD",)          # annonces qui bougent l'or
FENETRE_ANNONCE = 30        # minutes avant / apres une annonce
SYMBOLES_DOLLAR = ("DXY", "USDX", "USIDX", "USDIDX", "DX", "USDOLLAR")


# ---------------------------------------------------------------- session
def session(maintenant=None):
    """Session en cours, a l'heure de Paris (heure du PC)."""
    h = (maintenant or datetime.now()).hour + (maintenant or datetime.now()).minute / 60
    if h < 8:
        return "Asie"
    if h < 14.5:
        return "Londres"
    if h < 22:
        return "New York"
    return "apres cloture"


# ---------------------------------------------------------------- volatilite
def volatilite(bougies, court=14, long=120):
    """ATR court compare a l'ATR long : marche calme, normal ou agite."""
    if len(bougies) < long + 2:
        return None
    def atr(n, fin=None):
        serie = bougies[:fin] if fin else bougies
        tr = [max(h - l, abs(h - serie[i - 1][3]), abs(l - serie[i - 1][3]))
              for i, (o, h, l, c) in enumerate(serie) if i > 0][-n:]
        return sum(tr) / len(tr)
    rapide, lent = atr(court), atr(long)
    if not lent:
        return None
    ratio = rapide / lent
    etat = "calme" if ratio < 0.7 else "agitee" if ratio > 1.5 else "normale"
    return {"atr": rapide, "ratio": ratio, "etat": etat}


# ---------------------------------------------------------------- dollar
def dollar(mt5):
    """Variation du dollar sur 15 et 60 minutes (DXY, sinon EURUSD inverse)."""
    if mt5 is None:
        return None
    symbole, inverse = None, False
    for s in SYMBOLES_DOLLAR:
        if mt5.symbol_info(s) is not None:
            symbole = s
            break
    if symbole is None:
        if mt5.symbol_info("EURUSD") is None:
            return None
        symbole, inverse = "EURUSD", True
    mt5.symbol_select(symbole, True)
    rates = mt5.copy_rates_from_pos(symbole, mt5.TIMEFRAME_M1, 0, 70)
    if rates is None or len(rates) < 61:
        return None
    c = [float(r["close"]) for r in rates]
    def variation(n):
        v = 100 * (c[-1] - c[-1 - n]) / c[-1 - n]
        return -v if inverse else v
    v15, v60 = variation(15), variation(60)
    return {"symbole": "EURUSD inverse" if inverse else symbole,
            "var_15min": v15, "var_60min": v60,
            "sens": "hausse" if v60 > 0.02 else "baisse" if v60 < -0.02 else "stable"}


def dollar_contre_or(info, cote):
    """'oui' si le dollar va dans le sens favorable a un signal acheteur /
    vendeur sur l'or (dollar en baisse = favorable a l'achat d'or)."""
    if not info or info["sens"] == "stable":
        return ""
    favorable = (info["sens"] == "baisse" and cote in ("acheteur", "achat")) or \
                (info["sens"] == "hausse" and cote in ("vendeur", "vente"))
    return "oui" if favorable else "non"


# ---------------------------------------------------------------- calendrier
def _charger_calendrier():
    """Annonces de la semaine, en cache 6 h (Forex Factory, acces public)."""
    try:
        if CACHE.exists() and time.time() - CACHE.stat().st_mtime < CACHE_HEURES * 3600:
            return json.loads(CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    try:
        # sans identite de navigateur, le serveur repond 403 ; et il limite le
        # nombre d'appels (429), d'ou le cache de 6 h
        requete = urllib.request.Request(CALENDRIER_URL, headers={
            "User-Agent": NAVIGATEUR, "Accept": "application/json, text/plain, */*"})
        with urllib.request.urlopen(requete, timeout=20) as reponse:
            donnees = json.loads(reponse.read().decode("utf-8"))
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(json.dumps(donnees), encoding="utf-8")
        return donnees
    except Exception:
        try:
            return json.loads(CACHE.read_text(encoding="utf-8"))   # vieux cache, mieux que rien
        except (OSError, ValueError):
            return None


def annonces(maintenant=None):
    """Annonce a fort impact la plus proche : celle qui vient et celle qui vient de tomber."""
    donnees = _charger_calendrier()
    if not donnees:
        return None
    maintenant = maintenant or datetime.now(timezone.utc)
    if maintenant.tzinfo is None:
        maintenant = maintenant.astimezone()
    avant, apres = None, None
    retenues = 0
    for e in donnees:
        # les noms et les ecritures varient : impact "High"/"high", pays dans
        # "country" ou "currency"
        impact = str(e.get("impact", "")).lower()
        pays = e.get("country") or e.get("currency") or ""
        if impact not in ("high", "3") or str(pays).upper() not in DEVISES:
            continue
        retenues += 1
        try:
            quand = datetime.fromisoformat(e["date"])
        except (KeyError, ValueError):
            continue
        minutes = (quand - maintenant).total_seconds() / 60
        titre = e.get("title", "annonce")
        if 0 <= minutes and (apres is None or minutes < apres[0]):
            apres = (minutes, titre)
        if minutes < 0 and (avant is None or -minutes < -avant[0]):
            avant = (minutes, titre)
    proche = ""
    if apres and apres[0] <= FENETRE_ANNONCE:
        proche = f"dans {apres[0]:.0f} min"
    elif avant and -avant[0] <= FENETRE_ANNONCE:
        proche = f"il y a {-avant[0]:.0f} min"
    return {"retenues": retenues,
            "prochaine": apres[1] if apres else "", "dans_min": round(apres[0]) if apres else "",
            "derniere": avant[1] if avant else "", "depuis_min": round(-avant[0]) if avant else "",
            "fenetre": proche, "proche": "oui" if proche else "non"}


# ---------------------------------------------------------------- resume
def resume(mt5=None, bougies=None):
    """Tout le contexte marche en un dict, pour l'affichage et les bilans."""
    info = {"session": session()}
    v = volatilite(bougies) if bougies else None
    if v:
        info["volatilite"] = v["etat"]
        info["volatilite_ratio"] = round(v["ratio"], 2)
    d = dollar(mt5)
    if d:
        info["dollar"] = d["sens"]
        info["dollar_15min"] = round(d["var_15min"], 3)
        info["dollar_60min"] = round(d["var_60min"], 3)
        info["dollar_symbole"] = d["symbole"]
    a = annonces()
    if a:
        info["annonces_semaine"] = a["retenues"]
        info["annonce_proche"] = a["proche"]
        info["annonce_fenetre"] = a["fenetre"]
        info["prochaine_annonce"] = a["prochaine"]
        info["annonce_dans_min"] = a["dans_min"]
    return info


from gimaly.trading.symbole import symbole_or  # symbole de l'or du courtier

if __name__ == "__main__":
    try:
        import MetaTrader5 as mt5
        ouvert = mt5.initialize()
    except ImportError:
        mt5, ouvert = None, False
    try:
        bougies = None
        if ouvert:
            rates = mt5.copy_rates_from_pos(symbole_or(), mt5.TIMEFRAME_M1, 1, 300)
            if rates is not None:
                bougies = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                           for r in rates]
        for cle, valeur in resume(mt5 if ouvert else None, bougies).items():
            print(f"{cle:<20} {valeur}")
    finally:
        if ouvert:
            mt5.shutdown()
