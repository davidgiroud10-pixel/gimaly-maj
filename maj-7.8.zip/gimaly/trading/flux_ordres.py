r"""
gimaly/trading/flux_ordres.py - G.I.M.A.L.Y
Lecture du flux d'ordres a partir des messages KMM (transactions + meilleur
prix acheteur/vendeur). Tout est calcule ici, comme le fait la page KMM :

  - CVD de session (volume acheteur - volume vendeur, cumule)
  - delta et pression acheteurs sur 1 et 5 minutes
  - VWAP de session et ecart-type (bandes comme MegaZones)
  - profil de volume : POC, zone de valeur (VAH / VAL, 70 %)
  - murs visibles au meilleur prix (quantite affichee anormalement grosse)
  - desequilibre du carnet au meilleur prix
  - bougies d'une minute avec delta (pour le futur bot)
  - le "cycle des 5 bougies" : une serie de bougies M1 dont la couleur
    contredit le delta, suivie d'une bougie saine (couleur = delta)

KMM n'envoie pas l'historique de la session a la connexion : les cumuls
(CVD, VWAP, profil de volume...) sont donc sauvegardes chaque minute
(sauvegarder / charger) pour reprendre apres un redemarrage de GIMALY, tant
qu'on est dans la meme session. Ce qui s'est passe pendant l'arret manque.

Session : elle change a 22:00 UTC (18:00 New York en ete, ouverture du
Globex). En hiver l'ouverture reelle est a 23:00 UTC : la premiere heure est
alors comptee dans la session precedente.
"""
from __future__ import annotations

import json
import math
import os
import statistics
import time
from collections import deque
from pathlib import Path

TICK = 0.1
MUR_MIN = 10          # contrats affiches au minimum pour parler de mur
MUR_FACTEUR = 4.0     # ... et au moins 4 fois la quantite affichee habituelle
ZONE_VALEUR = 0.70

# Cycle des 5 bougies M1
CYCLE_N = 5            # bougies examinees avant la bougie saine
CYCLE_DIV_MIN = 4      # au moins 4 sur 5 de meme couleur avec un delta oppose
CYCLE_DELTA_MIN = 3    # delta minimum (contrats) pour qu'une bougie compte
CYCLE_PAUSE_S = 300    # pas deux signaux a moins de 5 minutes


def _session(ts_ms: float) -> int:
    """Numero de session : le jour change a 22:00 UTC."""
    return int((ts_ms / 1000 + 2 * 3600) // 86400)


class FluxOrdres:
    def __init__(self) -> None:
        self.session = None
        self._raz()
        self.bid = self.ask = math.nan
        self.bid_taille = self.ask_taille = 0.0
        self._tailles = deque(maxlen=1000)
        self._mediane = 1.0
        self._n_carnet = 0
        self.mur_acheteur = None     # (prix, taille) ou None
        self.mur_vendeur = None
        self._dernier_ts = 0.0
        self.sur_cycle = None           # fonction appelee a chaque cycle detecte
        self._dernier_cycle = 0

    def _raz(self) -> None:
        self.cvd = 0.0
        self.volume = 0.0
        self.volume_achat = 0.0
        self._pv = 0.0
        self._pv2 = 0.0
        self.profil: dict[float, float] = {}
        self.profil_min: dict[int, dict[float, float]] = {}   # minute -> {prix: volume}
        self.fenetre = deque()           # (ts_ms, volume signe, volume)
        self.bougies = deque(maxlen=240)
        self.dernier_prix = math.nan
        self.nb_trades = 0

    # ------------------------------------------------------------ entrees
    def message(self, m: dict) -> None:
        genre = m.get("type")
        if genre == "trade":
            self._transaction(m)
        elif genre == "book":
            self._carnet(m)

    def _transaction(self, m: dict) -> None:
        ts = float(m.get("timestamp") or 0)
        prix = float(m.get("price") or 0)
        taille = float(m.get("size") or 0)
        # ATTENTION : chez KMM, "side" est le cote du carnet touche, pas celui qui
        # attaque ("sell" s'execute au prix vendeur = acheteur agressif).
        cote = {"sell": "buy", "buy": "sell"}.get(m.get("side"))
        if cote is None and not math.isnan(self.ask):      # "unknown" : d'apres le carnet
            cote = "buy" if prix >= self.ask - 1e-9 else "sell" if prix <= self.bid + 1e-9 else None
        if not ts or not prix or not taille or cote is None:
            return
        # Apres une reconnexion, KMM rejoue l'historique : on ignore ce qui a
        # deja ete compte, sinon le CVD et le VWAP seraient faux.
        # (plusieurs transactions identiques dans la meme milliseconde sont
        # normales : seules les plus anciennes que la derniere vue sont ecartees)
        if ts < self._dernier_ts:
            return
        self._dernier_ts = ts
        s = _session(ts)
        if s != self.session:
            self.session = s
            self._raz()
        signe = 1 if cote == "buy" else -1
        self.nb_trades += 1
        self.dernier_prix = prix
        self.cvd += signe * taille
        self.volume += taille
        if signe > 0:
            self.volume_achat += taille
        self._pv += prix * taille
        self._pv2 += prix * prix * taille
        niveau = round(round(prix / TICK) * TICK, 1)
        self.profil[niveau] = self.profil.get(niveau, 0.0) + taille
        _pm = self.profil_min.setdefault(int(ts // 60_000) * 60, {})
        _pm[niveau] = _pm.get(niveau, 0.0) + taille
        if len(self.profil_min) > 1500:                      # on garde ~24 h
            for _t in sorted(self.profil_min)[:len(self.profil_min) - 1440]:
                del self.profil_min[_t]

        self.fenetre.append((ts, signe * taille, taille))
        while self.fenetre and ts - self.fenetre[0][0] > 300_000:
            self.fenetre.popleft()

        minute = int(ts // 60_000) * 60
        if not self.bougies or self.bougies[-1]["t"] != minute:
            if self.bougies:
                self._verifier_cycle()          # la bougie precedente vient de fermer
            self.bougies.append({"t": minute, "o": prix, "h": prix, "l": prix, "c": prix,
                                 "v": 0.0, "achat": 0.0, "vente": 0.0, "delta": 0.0})
        b = self.bougies[-1]
        b["h"], b["l"], b["c"] = max(b["h"], prix), min(b["l"], prix), prix
        b["v"] += taille
        b["achat" if signe > 0 else "vente"] += taille
        b["delta"] += signe * taille

    def _carnet(self, m: dict) -> None:
        bids, asks = m.get("bids") or [], m.get("asks") or []
        if not bids or not asks:
            return
        self.bid, self.bid_taille = float(bids[0][0]), float(bids[0][1])
        self.ask, self.ask_taille = float(asks[0][0]), float(asks[0][1])
        self._tailles.append(self.bid_taille)
        self._tailles.append(self.ask_taille)
        self._n_carnet += 1
        if self._n_carnet % 200 == 0 and len(self._tailles) > 50:
            self._mediane = max(1.0, statistics.median(self._tailles))
        seuil = max(MUR_MIN, MUR_FACTEUR * self._mediane)
        self.mur_acheteur = (self.bid, self.bid_taille) if self.bid_taille >= seuil else None
        self.mur_vendeur = (self.ask, self.ask_taille) if self.ask_taille >= seuil else None

    # ------------------------------------------------------------ cycle 5 bougies
    @staticmethod
    def _couleur(b):
        return 1 if b["c"] > b["o"] else -1 if b["c"] < b["o"] else 0

    def _verifier_cycle(self) -> None:
        fermees = list(self.bougies)
        if len(fermees) < CYCLE_N + 1:
            return
        serie, saine = fermees[-CYCLE_N - 1:-1], fermees[-1]
        # bougies consecutives uniquement (pas de trou dans les donnees)
        temps = [b["t"] for b in serie] + [saine["t"]]
        if any(b - a != 60 for a, b in zip(temps, temps[1:])):
            return
        if saine["t"] - self._dernier_cycle < CYCLE_PAUSE_S:
            return
        rouges = sum(1 for b in serie if self._couleur(b) < 0 and b["delta"] >= CYCLE_DELTA_MIN)
        vertes = sum(1 for b in serie if self._couleur(b) > 0 and b["delta"] <= -CYCLE_DELTA_MIN)
        if rouges >= CYCLE_DIV_MIN:
            couleur_serie = -1
        elif vertes >= CYCLE_DIV_MIN:
            couleur_serie = 1
        else:
            return
        c = self._couleur(saine)
        moyenne = sum(abs(b["delta"]) for b in serie) / CYCLE_N
        seuil = max(CYCLE_DELTA_MIN, 0.5 * moyenne)
        if c == 0 or c * saine["delta"] < seuil:
            return                               # pas (encore) de bougie saine
        self._dernier_cycle = saine["t"]
        signal = {
            "t": saine["t"] + 60, "sens": "achat" if c > 0 else "vente",
            "scenario": "retournement" if c != couleur_serie else "continuation",
            "prix": saine["c"], "couleur_serie": "rouge" if couleur_serie < 0 else "verte",
            "divergentes": rouges if couleur_serie < 0 else vertes,
            "delta_serie": sum(b["delta"] for b in serie), "delta_saine": saine["delta"],
        }
        if self.sur_cycle:
            try:
                self.sur_cycle(signal)
            except Exception as e:
                print(f"[flux_ordres] cycle non traite : {e!r}")

    # ------------------------------------------------------------ sauvegarde
    def sauvegarder(self, chemin) -> None:
        """Ecrit les cumuls de la session (appele chaque minute)."""
        if self.session is None:
            return
        donnees = {
            "session": self.session, "cvd": self.cvd, "volume": self.volume,
            "volume_achat": self.volume_achat, "pv": self._pv, "pv2": self._pv2,
            "profil": {f"{p:.1f}": v for p, v in self.profil.items()},
            "profil_min": {str(t): {f"{p:.1f}": v for p, v in dd.items()}
                           for t, dd in self.profil_min.items()},
            "fenetre": list(self.fenetre), "bougies": list(self.bougies),
            "dernier_prix": self.dernier_prix, "nb_trades": self.nb_trades,
            "dernier_ts": self._dernier_ts,
        }
        chemin = Path(chemin)
        temporaire = chemin.with_suffix(".tmp")
        temporaire.write_text(json.dumps(donnees), encoding="utf-8")
        os.replace(temporaire, chemin)          # jamais de fichier a moitie ecrit

    def charger(self, chemin) -> bool:
        """Reprend les cumuls si la sauvegarde date de la session en cours."""
        try:
            d = json.loads(Path(chemin).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return False
        if d.get("session") != _session(time.time() * 1000):
            return False                        # session terminee : on repart de zero
        self.session = d["session"]
        self.cvd, self.volume = d["cvd"], d["volume"]
        self.volume_achat, self._pv, self._pv2 = d["volume_achat"], d["pv"], d["pv2"]
        self.profil = {float(p): v for p, v in d["profil"].items()}
        self.profil_min = {int(t): {float(p): v for p, v in dd.items()}
                           for t, dd in d.get("profil_min", {}).items()}
        self.fenetre = deque(tuple(x) for x in d.get("fenetre", []))
        self.bougies = deque(d.get("bougies", []), maxlen=240)
        self.dernier_prix = d.get("dernier_prix", math.nan)
        self.nb_trades = d.get("nb_trades", 0)
        self._dernier_ts = d.get("dernier_ts", 0.0)
        return True

    # ------------------------------------------------------------ lectures
    def _fenetre(self, ts_fin: float, duree_ms: float) -> tuple[float, float, float]:
        delta = volume = achat = 0.0
        for ts, signe_vol, vol in reversed(self.fenetre):
            if ts_fin - ts > duree_ms:
                break
            delta += signe_vol
            volume += vol
            if signe_vol > 0:
                achat += vol
        return delta, volume, achat

    def vwap(self) -> tuple[float, float]:
        if not self.volume:
            return math.nan, math.nan
        v = self._pv / self.volume
        variance = max(0.0, self._pv2 / self.volume - v * v)
        return v, math.sqrt(variance)

    def profil_volume(self) -> tuple[float, float, float]:
        """POC, VAH, VAL de la session."""
        if not self.profil:
            return math.nan, math.nan, math.nan
        prix = sorted(self.profil)
        vols = [self.profil[p] for p in prix]
        i_poc = max(range(len(prix)), key=vols.__getitem__)
        haut = bas = i_poc
        cumul, objectif = vols[i_poc], ZONE_VALEUR * sum(vols)
        while cumul < objectif and (bas > 0 or haut < len(prix) - 1):
            dessus = vols[haut + 1] if haut < len(prix) - 1 else -1
            dessous = vols[bas - 1] if bas > 0 else -1
            if dessus >= dessous:
                haut += 1
                cumul += dessus
            else:
                bas -= 1
                cumul += dessous
        return prix[i_poc], prix[haut], prix[bas]

    def profil_fenetre(self, minutes: int = 60, pas: float = 0.4) -> tuple[float, float, float]:
        """POC, VAH, VAL sur les `minutes` dernieres minutes (tranches de `pas` $), prix GC."""
        pm = getattr(self, "profil_min", None)
        if not pm:
            return math.nan, math.nan, math.nan
        fin = max(pm)
        agrege: dict[float, float] = {}
        for t, dd in pm.items():
            if t > fin - minutes * 60:
                for p, v in dd.items():
                    k = round(math.floor(p / pas + 1e-9) * pas, 2)
                    agrege[k] = agrege.get(k, 0.0) + v
        if not agrege:
            return math.nan, math.nan, math.nan
        prix = sorted(agrege)
        vols = [agrege[p] for p in prix]
        i_poc = max(range(len(prix)), key=vols.__getitem__)
        haut = bas = i_poc
        cumul, objectif = vols[i_poc], ZONE_VALEUR * sum(vols)
        while cumul < objectif and (bas > 0 or haut < len(prix) - 1):
            dessus = vols[haut + 1] if haut < len(prix) - 1 else -1
            dessous = vols[bas - 1] if bas > 0 else -1
            if dessus >= dessous:
                haut += 1
                cumul += dessus
            else:
                bas -= 1
                cumul += dessous
        return prix[i_poc], prix[haut], prix[bas]

    def instantane(self) -> dict:
        """Photo du flux d'ordres, pour l'affichage et le contexte des icebergs."""
        ts = self.fenetre[-1][0] if self.fenetre else 0
        d1, v1, a1 = self._fenetre(ts, 60_000)
        d5, v5, a5 = self._fenetre(ts, 300_000)
        vw, sigma = self.vwap()
        poc, vah, val = self.profil_volume()
        prix = self.dernier_prix
        pos_sigma = (prix - vw) / sigma if sigma and not math.isnan(vw) and sigma > 0 else math.nan
        tot = self.bid_taille + self.ask_taille
        return {
            "prix": prix, "cvd": self.cvd, "delta_1min": d1, "delta_5min": d5,
            "pression_1min": 100 * a1 / v1 if v1 else math.nan,
            "pression_5min": 100 * a5 / v5 if v5 else math.nan,
            "pression_session": 100 * self.volume_achat / self.volume if self.volume else math.nan,
            "vwap": vw, "sigma": sigma, "position_sigma": pos_sigma,
            "poc": poc, "vah": vah, "val": val, "volume": self.volume, "trades": self.nb_trades,
            "desequilibre": 100 * self.bid_taille / tot if tot else math.nan,
            "mur_acheteur": self.mur_acheteur, "mur_vendeur": self.mur_vendeur,
        }

    def contexte(self, prix: float, cote: str) -> dict:
        """Contexte au moment d'un iceberg (cote : 'vendeur' ou 'acheteur')."""
        i = self.instantane()
        vw, sigma = i["vwap"], i["sigma"]
        sig = (prix - vw) / sigma if sigma and sigma > 0 and not math.isnan(vw) else math.nan
        dans_le_sens = (i["delta_5min"] < 0) if cote == "vendeur" else (i["delta_5min"] > 0)
        mur = i["mur_vendeur"] if cote == "vendeur" else i["mur_acheteur"]
        poc, vah, val = i["poc"], i["vah"], i["val"]
        if math.isnan(poc):
            zone = ""
        elif prix > vah:
            zone = "au-dessus de la zone de valeur"
        elif prix < val:
            zone = "sous la zone de valeur"
        else:
            zone = "dans la zone de valeur"
        return {
            "vwap_sigma": sig, "cote_vwap": "" if math.isnan(sig) else ("dessus" if sig > 0 else "dessous"),
            "cvd": i["cvd"], "delta_1min": i["delta_1min"], "delta_5min": i["delta_5min"],
            "pression_1min": i["pression_1min"], "dist_poc": prix - poc if not math.isnan(poc) else math.nan,
            "zone_valeur": zone, "flux_dans_le_sens": "oui" if dans_le_sens else "non",
            "mur": "oui" if mur and abs(mur[0] - prix) < 1e-9 else "non",
        }
