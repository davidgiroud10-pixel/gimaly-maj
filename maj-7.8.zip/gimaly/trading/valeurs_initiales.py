"""Valeurs initiales - G.I.M.A.L.Y

La « valeur initiale » est la zone d'où part une impulsion : la base, les
dernières bougies avant que le prix « explose ». Le prix y revient souvent :
  - il rebondit dessus  -> continuation du mouvement ;
  - il la traverse      -> inversion.

Tout est recalculé à partir des bougies MT5 (M1, M5, M15), sans rien retenir
en mémoire : chaque retour dans une zone, et ce qui s'est passé ensuite, est
écrit une seule fois dans valeurs_initiales.csv pour le bilan.

Observation seulement : n'entre ni dans la note ni dans les filtres du bot.
"""
from __future__ import annotations

import csv
import time
from dataclasses import dataclass, field
from pathlib import Path

DOSSIER = Path.home() / "GIMALY" / "trading"
FICHIER = DOSSIER / "valeurs_initiales.csv"
COLONNES = ["date", "heure", "type", "unite", "sens", "bas", "haut", "impulsion_atr", "entree_prix",
            "issue", "mouv_15min", "mouv_60min", "retour_n", "cle",
            # trade simule : entree au bord de la zone, stop de l'autre cote, objectif 2R
            "trade_r", "trade_issue", "risque",
            # variantes de gestion, en R (voir VARIANTES)
            "r_1r", "r_15r", "r_mi_zone", "r_4h", "r_mi_zone_1r", "r_be1", "r_be15",
            "r_atr1", "r_atr15", "r_invalidation", "r_confirmation",
            # 05/10 : stop chasse ? liquidite (plus bas / plus haut recents) pres
            # du stop, et stop replace au-dela de cette liquidite
            "r_liq05", "r_liq1", "liq_proche",
            # 05/10 : entree APRES le balayage de la liquidite (stop sous la meche)
            "r_balayage",
            # taille des stops ($) : un stop plus loin n'est acceptable que s'il reste raisonnable
            "stop_liq05", "stop_liq1", "stop_balayage",
            # tendance H1 au moment du retour, et la zone par rapport a elle
            "tendance_h1", "sens_tendance",
            # tendance H1 du dollar (DXY, ou EURUSD inverse) et accord avec la zone
            "dollar_h1", "accord_dollar"]
MARGE_STOP = 0.5             # $ au-dela de la zone pour le stop du trade simule
DUREE_TRADE_MIN = 120        # au-dela, le trade simule est solde au prix du moment
# (colonne, libelle, objectif en R, stop : "zone" = de l'autre cote, "mi" = au milieu, duree en min)
VARIANTES = (
    ("trade_r", "2R, stop zone, 2 h", 2.0, "zone", 120),
    ("r_1r", "1R, stop zone, 2 h", 1.0, "zone", 120),
    ("r_15r", "1,5R, stop zone, 2 h", 1.5, "zone", 120),
    ("r_4h", "2R, stop zone, 4 h", 2.0, "zone", 240),
    ("r_mi_zone", "2R, stop mi-zone, 2 h", 2.0, "mi", 120),
    ("r_mi_zone_1r", "1R, stop mi-zone, 2 h", 1.0, "mi", 120),
    # 01/10 : faut-il passer au point mort une fois le prix bien parti ?
    ("r_be1", "2R 4 h, BE a +1R", 2.0, "zone", 240, 1.0),
    ("r_be15", "2R 4 h, BE a +1,5R", 2.0, "zone", 240, 1.5),
    # 01/10 : stop plus court, fonde sur la volatilite de l'unite de la zone
    ("r_atr1", "2R 4 h, stop 1 ATR", 2.0, "atr:1.0", 240),
    ("r_atr15", "2R 4 h, stop 1,5 ATR", 2.0, "atr:1.5", 240),
    # 02/10 : fausses cassures. « invalidation » : sortie au marche des qu'une
    # bougie cloture de nouveau de l'autre cote du niveau casse ; « confirmation » :
    # on n'entre que si la bougie suivante cloture encore au-dela du niveau
    ("r_invalidation", "2R 4 h, sortie si fausse cassure", 2.0, "zone", 240, None, "invalidation"),
    ("r_confirmation", "2R 4 h, entree confirmee", 2.0, "zone", 240, None, "confirmation"),
    # 05/10 : stop chasse (vi_contre du 05/10 17h21 : stop 0,5 $ sous un plus bas
    # evident, mèche jusqu'a 4 $ dessous puis depart dans le sens du trade).
    # Stop replace sous la liquidite la plus basse proche + 0,5 ou 1 ATR ;
    # objectif toujours a 2R de la nouvelle distance (meme risque en R).
    ("r_liq05", "2R 4 h, stop sous liq. +0,5 ATR", 2.0, "liq:0.5", 240),
    ("r_liq1", "2R 4 h, stop sous liq. +1 ATR", 2.0, "liq:1.0", 240),
    # entree apres balayage : s'il y a une liquidite pres du stop, on attend
    # qu'une bougie passe dessous puis cloture au-dessus (balayage repris) ;
    # entree a la cloture, stop sous la meche + 0,5 $ : stop souvent PLUS
    # COURT que celui de la zone. Sans balayage dans les 2 h : pas de trade.
    ("r_balayage", "2R 4 h, entree apres balayage", 2.0, "balayage", 240),
)
BALAYAGE_ATTENTE = 8         # bougies d'attente du balayage (2 h en M15)
TAILLES_STOP = {"r_liq05": "stop_liq05", "r_liq1": "stop_liq1", "r_balayage": "stop_balayage"}
LIQ_RECUL = 48               # bougies relues pour trouver les plus bas / hauts recents
LIQ_PIVOT = 2                # un plus bas = plus bas que 2 bougies de chaque cote

# réglages par unité de temps : (pivot, bougies max de l'impulsion, taille min en ATR)
REGLAGES = {"M1": (3, 8, 3.0), "M5": (3, 6, 2.5), "M15": (2, 5, 2.0)}
MINUTES = {"M1": 1, "M5": 5, "M15": 15}
ZONE_MIN_ATR = 0.25          # une base plus fine est élargie à 0,25 ATR
ZONES_MAX = 6                # zones actives gardées par unité


@dataclass
class Zone:
    unite: str
    sens: str                # "haussiere" (origine d'une hausse) ou "baissiere"
    bas: float
    haut: float
    debut: int               # heure (epoch) de la bougie d'origine
    creee: int               # fin de l'impulsion : la zone existe à partir de là
    impulsion_atr: float
    cassee: int | None = None
    retours: list = field(default_factory=list)   # (heure, prix, issue, mouv15, mouv60)
    type: str = "VI"         # VI (origine d'impulsion ~ order block), FVG, IFVG, BPR, OPR
    niveau: float = 0.0      # BOS / CHoCH : le niveau casse (sommet ou creux)


def _atr(bougies, n=14):
    tr = []
    for i, (_, o, h, b, c) in enumerate(bougies):
        pc = bougies[i - 1][4] if i else c
        tr.append(max(h - b, abs(h - pc), abs(b - pc)))
    sortie, s = [], 0.0
    for i, v in enumerate(tr):
        s = v if i == 0 else (s * (n - 1) + v) / n
        sortie.append(s)
    return sortie


def tendance_h1(bougies_h1):
    """Renvoie une fonction heure -> tendance H1 (« haussiere », « baissiere »
    ou « mixte ») calculee UNIQUEMENT sur les bougies H1 closes avant cette heure :
    moyenne exponentielle 20 au-dessus (ou au-dessous) de la 50 ET qui monte
    (ou descend) depuis 3 heures."""
    if not bougies_h1 or len(bougies_h1) < 60:
        return lambda t: ""

    def ema(valeurs, n):
        k, sortie, m = 2 / (n + 1), [], None
        for v in valeurs:
            m = v if m is None else m + k * (v - m)
            sortie.append(m)
        return sortie

    heures = [b[0] for b in bougies_h1]
    closes = [b[4] for b in bougies_h1]
    e20, e50 = ema(closes, 20), ema(closes, 50)
    import bisect

    def lire(t):
        # derniere bougie H1 terminee avant t (elle a commence au moins 1 h avant)
        i = bisect.bisect_right(heures, t - 3600) - 1
        if i < 53:
            return ""
        if e20[i] > e50[i] and e20[i] > e20[i - 3]:
            return "haussiere"
        if e20[i] < e50[i] and e20[i] < e20[i - 3]:
            return "baissiere"
        return "mixte"
    return lire


_DOLLAR = None      # fonction heure -> tendance H1 du dollar, fournie par le detecteur


def definir_dollar(fonction) -> None:
    global _DOLLAR
    _DOLLAR = fonction


def _dollar(t) -> str:
    try:
        return _DOLLAR(t) if _DOLLAR else ""
    except Exception:
        return ""


def zones(bougies, unite: str, tendance=None) -> list[Zone]:
    """bougies : [(heure, open, high, low, close), ...] du plus ancien au plus récent.
    Renvoie les zones d'origine avec leurs retours et leur éventuelle cassure."""
    if len(bougies) < 40:
        return []
    pivot, max_b, min_atr = REGLAGES[unite]
    atr = _atr(bougies)
    trouvees: list[Zone] = []
    n = len(bougies)
    for i in range(pivot, n - pivot - 1):
        t, o, h, b, c = bougies[i]
        a = atr[i] or 1e-9
        bas_local = all(b <= bougies[j][3] for j in range(i - pivot, i + pivot + 1) if j != i)
        haut_local = all(h >= bougies[j][2] for j in range(i - pivot, i + pivot + 1) if j != i)
        fin = min(n - 1, i + max_b)
        if bas_local:
            k = max(range(i + 1, fin + 1), key=lambda j: bougies[j][2])
            if bougies[k][2] - b >= min_atr * a:
                haut_z = max(o, c) if max(o, c) - b >= ZONE_MIN_ATR * a else b + ZONE_MIN_ATR * a
                trouvees.append(Zone(unite, "haussiere", round(b, 2), round(haut_z, 2), t,
                                     bougies[max(k, i + pivot)][0], round((bougies[k][2] - b) / a, 1)))
        if haut_local:
            k = min(range(i + 1, fin + 1), key=lambda j: bougies[j][3])
            if h - bougies[k][3] >= min_atr * a:
                bas_z = min(o, c) if h - min(o, c) >= ZONE_MIN_ATR * a else h - ZONE_MIN_ATR * a
                trouvees.append(Zone(unite, "baissiere", round(bas_z, 2), round(h, 2), t,
                                     bougies[max(k, i + pivot)][0], round((h - bougies[k][3]) / a, 1)))

    # deux pivots voisins pour la meme impulsion : on garde la plus forte
    pas = MINUTES[unite] * 60
    uniques: list[Zone] = []
    for z in sorted(trouvees, key=lambda z: -z.impulsion_atr):
        if not any(u.sens == z.sens and abs(u.debut - z.debut) <= max_b * pas
                   and u.bas <= z.haut and z.bas <= u.haut for u in uniques):
            uniques.append(z)
    trouvees = sorted(uniques, key=lambda z: z.debut)
    return _suivre(trouvees, bougies, unite, tendance)


def _suivre(trouvees: list[Zone], bougies, unite: str, tendance=None) -> list[Zone]:
    """Retours du prix dans chaque zone, issue et trades simules, jusqu'a la cassure."""
    pas = MINUTES[unite] * 60
    n = len(bougies)
    index = {bg[0]: i for i, bg in enumerate(bougies)}
    for z in trouvees:
        depart = index.get(z.creee, None)
        if depart is None:
            continue
        dedans = False
        for i in range(depart + 1, n):
            t, o, h, b, c = bougies[i]
            touche = b <= z.haut and h >= z.bas
            if touche and not dedans:
                z.retours.append(_issue(bougies, i, z, pas) + ((tendance(t) if tendance else ""), _dollar(t)))
            dedans = touche
            # cassure : clôture franchement de l'autre côté
            if (z.sens == "haussiere" and c < z.bas) or (z.sens == "baissiere" and c > z.haut):
                z.cassee = t
                break
    return trouvees


# ------------------------------------------------------------ autres zones
FVG_MIN_ATR = 0.15           # trou minimal pour compter comme FVG
BPR_ECART_MAX = 12           # bougies max entre les deux FVG d'un BPR
OPR_MINUTES = 30             # duree de l'opening range
OUVERTURES_UTC = (("Londres", 7, 0), ("New York", 13, 30))


def _fvg(bougies, unite, atr):
    """Fair Value Gap : trou entre la meche de la bougie k-2 et celle de k."""
    sortie = []
    for k in range(2, len(bougies)):
        a = atr[k] or 1e-9
        haut_2, bas_2 = bougies[k - 2][2], bougies[k - 2][3]
        haut_0, bas_0 = bougies[k][2], bougies[k][3]
        if bas_0 - haut_2 >= FVG_MIN_ATR * a:
            sortie.append(Zone(unite, "haussiere", round(haut_2, 2), round(bas_0, 2), bougies[k - 1][0],
                               bougies[k][0], round((bas_0 - haut_2) / a, 1), type="FVG"))
        elif bas_2 - haut_0 >= FVG_MIN_ATR * a:
            sortie.append(Zone(unite, "baissiere", round(haut_0, 2), round(bas_2, 2), bougies[k - 1][0],
                               bougies[k][0], round((bas_2 - haut_0) / a, 1), type="FVG"))
    return sortie


def _ifvg(fvgs, bougies, unite):
    """FVG traverse par une cloture : il change de camp (support <-> resistance)."""
    index = {bg[0]: i for i, bg in enumerate(bougies)}
    sortie = []
    for z in fvgs:
        depart = index.get(z.creee)
        if depart is None:
            continue
        for t, o, h, b, c in bougies[depart + 1:]:
            if z.sens == "haussiere" and c < z.bas:
                sortie.append(Zone(unite, "baissiere", z.bas, z.haut, z.debut, t, z.impulsion_atr, type="IFVG"))
                break
            if z.sens == "baissiere" and c > z.haut:
                sortie.append(Zone(unite, "haussiere", z.bas, z.haut, z.debut, t, z.impulsion_atr, type="IFVG"))
                break
    return sortie


def _bpr(fvgs, unite):
    """Balanced Price Range : chevauchement d'un FVG haussier et d'un FVG baissier
    proches ; le sens est celui du plus recent."""
    pas = MINUTES[unite] * 60
    sortie = []
    for i, a in enumerate(fvgs):
        for b in fvgs[i + 1:]:
            if b.creee - a.creee > BPR_ECART_MAX * pas:
                break
            if a.sens == b.sens:
                continue
            bas, haut = max(a.bas, b.bas), min(a.haut, b.haut)
            if haut > bas:
                sortie.append(Zone(unite, b.sens, round(bas, 2), round(haut, 2), a.debut, b.creee,
                                   round(max(a.impulsion_atr, b.impulsion_atr), 1), type="BPR"))
    return sortie


def _opr(bougies, unite, atr):
    """Opening range (30 premieres minutes de Londres et de New York) : a la
    premiere cassure, le bord casse devient la zone a retester (haussiere si
    cassure par le haut)."""
    import calendar
    sortie = []
    jours = sorted({time.strftime("%Y-%m-%d", time.gmtime(bg[0])) for bg in bougies})
    for jour in jours:
        for _, heure, minute in OUVERTURES_UTC:
            debut = calendar.timegm(time.strptime(f"{jour} {heure}:{minute}", "%Y-%m-%d %H:%M"))
            fin = debut + OPR_MINUTES * 60
            range_ = [bg for bg in bougies if debut <= bg[0] < fin]
            if len(range_) < 2:
                continue
            haut = max(bg[2] for bg in range_)
            bas = min(bg[3] for bg in range_)
            apres = [(i, bg) for i, bg in enumerate(bougies) if bg[0] >= fin]
            for i, (t, o, h, b, c) in apres:
                a = atr[i] or 1e-9
                epaisseur = max(0.25 * a, 0.5)
                if c > haut:
                    sortie.append(Zone(unite, "haussiere", round(haut - epaisseur, 2), round(haut, 2),
                                       debut, t, round((haut - bas) / a, 1), type="OPR"))
                    break
                if c < bas:
                    sortie.append(Zone(unite, "baissiere", round(bas, 2), round(bas + epaisseur, 2),
                                       debut, t, round((haut - bas) / a, 1), type="OPR"))
                    break
    return sortie


def _structure(bougies, unite, atr, tendance=None):
    """BOS (cassure dans le sens de la structure) et CHoCH (cassure contre elle,
    premier signe d'inversion), sur les derniers plus hauts / plus bas confirmes.
    Deux facons de les trader sont mesurees :
      - « cassure » : entree a la cloture qui casse, stop sous le dernier creux
        (au-dessus du dernier sommet pour une vente) ;
      - « retest »  : le niveau casse devient une zone, on attend le retour dessus.
    Renvoie (zones a suivre pour le retest, zones deja suivies pour la cassure)."""
    pivot = REGLAGES[unite][0]
    pas = MINUTES[unite] * 60
    retests, cassures = [], []
    sommet = creux = None             # (index, prix) du dernier pivot confirme
    sommet_casse = creux_casse = True
    structure = None
    for i in range(len(bougies)):
        t, o, h, b, c = bougies[i]
        # un pivot en j n'est connu qu'une fois « pivot » bougies passees apres lui
        j = i - pivot
        if j >= pivot:
            fenetre = bougies[j - pivot:j + pivot + 1]
            if bougies[j][2] >= max(x[2] for x in fenetre):
                sommet, sommet_casse = (j, bougies[j][2]), False
            if bougies[j][3] <= min(x[3] for x in fenetre):
                creux, creux_casse = (j, bougies[j][3]), False
        a = atr[i] or 1e-9
        for sens, niveau, casse in (("haussiere", sommet, sommet_casse), ("baissiere", creux, creux_casse)):
            if niveau is None or casse:
                continue
            franchi = c > niveau[1] if sens == "haussiere" else c < niveau[1]
            if not franchi:
                continue
            genre = "BOS" if structure in (None, sens) else "CHoCH"
            structure = sens
            if sens == "haussiere":
                sommet_casse = True
                oppose = creux[1] if creux else b
                zone_retest = Zone(unite, sens, round(niveau[1] - 0.25 * a, 2), round(niveau[1], 2),
                                   bougies[niveau[0]][0], t, 0.0, type=f"{genre} retest")
                zone_cassure = Zone(unite, sens, round(min(oppose, c - 0.25 * a), 2), round(c, 2),
                                    bougies[niveau[0]][0], t, 0.0, type=f"{genre} cassure")
            else:
                creux_casse = True
                oppose = sommet[1] if sommet else h
                zone_retest = Zone(unite, sens, round(niveau[1], 2), round(niveau[1] + 0.25 * a, 2),
                                   bougies[niveau[0]][0], t, 0.0, type=f"{genre} retest")
                zone_cassure = Zone(unite, sens, round(c, 2), round(max(oppose, c + 0.25 * a), 2),
                                    bougies[niveau[0]][0], t, 0.0, type=f"{genre} cassure")
            zone_retest.niveau = round(niveau[1], 2)
            zone_cassure.niveau = round(niveau[1], 2)
            retests.append(zone_retest)
            # la cassure est « tradee » tout de suite, a la cloture de la bougie i
            zone_cassure.retours.append(_issue(bougies, i, zone_cassure, pas)
                                        + ((tendance(t) if tendance else ""), _dollar(t)))
            cassures.append(zone_cassure)
    return retests, cassures


def zones_toutes(bougies, unite: str, tendance=None) -> list[Zone]:
    """Valeurs initiales + FVG, IFVG, BPR (M5 et M15) + opening range (M5)."""
    sortie = zones(bougies, unite, tendance)
    if unite not in ("M5", "M15") or len(bougies) < 40:
        return sortie
    atr = _atr(bougies)
    fvgs = _fvg(bougies, unite, atr)
    autres = fvgs + _ifvg(fvgs, bougies, unite) + _bpr(fvgs, unite)
    if unite == "M5":
        autres += _opr(bougies, unite, atr)
    retests, cassures = _structure(bougies, unite, atr, tendance)
    return sortie + _suivre(autres + retests, bougies, unite, tendance) + cassures


def _issue(bougies, i, z: Zone, pas: int):
    """Ce qui s'est passé après un retour dans la zone : continuation si le prix
    repart dans le sens de l'impulsion sans clôturer au-delà, inversion s'il la
    traverse ; mouvements mesurés à 15 et 60 min depuis le milieu de la zone."""
    t0 = bougies[i][0]
    milieu = (z.bas + z.haut) / 2
    signe = 1 if z.sens == "haussiere" else -1
    m15 = m60 = None
    issue = "en cours"
    for t, o, h, b, c in bougies[i:]:
        ecoule = t - t0
        if (z.sens == "haussiere" and c < z.bas) or (z.sens == "baissiere" and c > z.haut):
            issue = "inversion"
            if m15 is None:
                m15 = round((c - milieu) * signe, 2)
            break
        if m15 is None and ecoule >= 15 * 60:
            m15 = round((c - milieu) * signe, 2)
        if ecoule >= 60 * 60:
            m60 = round((c - milieu) * signe, 2)
            issue = "continuation" if m60 > 0 else "indecis"
            break
    if issue == "inversion" and m60 is None:
        m60 = m15
    trade = _trade(bougies, i, z)
    variantes = {v[0]: _trade(bougies, i, z, v[2], v[3], v[4], v[5] if len(v) > 5 else None,
                              v[6] if len(v) > 6 else None)[0]
                 for v in VARIANTES}
    variantes["liq_proche"] = "oui" if liquidites_pres_du_stop(bougies, i, z) else "non"
    for v in VARIANTES:
        if v[0] in TAILLES_STOP:
            variantes[TAILLES_STOP[v[0]]] = _trade(bougies, i, z, v[2], v[3], v[4])[2]
    return (t0, bougies[i][3] if z.sens == "haussiere" else bougies[i][2], issue, m15, m60,
            trade, variantes)


def _atr_avant(bougies, i, periode=14) -> float:
    """ATR(14) mesure sur les bougies jusqu'a i (sans information du futur).
    Nom distinct de `_atr(bougies)` : la meme nom ecrasait l'autre fonction
    et bloquait tout le calcul des zones (05/10, 17h32)."""
    debut = max(1, i - periode)
    vraies = [max(bougies[j][2] - bougies[j][3], abs(bougies[j][2] - bougies[j - 1][4]),
                  abs(bougies[j][3] - bougies[j - 1][4])) for j in range(debut, i + 1)]
    return sum(vraies) / len(vraies) if vraies else 1.0


def liquidites_pres_du_stop(bougies, i, z: Zone) -> list[float]:
    """Plus bas (zone haussiere) ou plus hauts (baissiere) recents, formes AVANT
    l'entree, situes entre l'entree et 1 ATR au-dela du stop habituel : la ou
    les stops des autres traders s'accumulent, et ou le prix va souvent les
    chercher avant de repartir."""
    haussiere = z.sens == "haussiere"
    entree = z.haut if haussiere else z.bas
    stop = z.bas - MARGE_STOP if haussiere else z.haut + MARGE_STOP
    atr = _atr_avant(bougies, i)
    niveaux = []
    for j in range(max(LIQ_PIVOT, i - LIQ_RECUL), i - LIQ_PIVOT):
        voisins = list(bougies[j - LIQ_PIVOT:j]) + list(bougies[j + 1:j + 1 + LIQ_PIVOT])
        if haussiere:
            prix = bougies[j][3]
            # « <= » : des plus bas EGAUX (double creux) sont justement la liquidite type
            if all(prix <= v[3] for v in voisins) and stop - atr <= prix <= entree:
                niveaux.append(prix)
        else:
            prix = bougies[j][2]
            if all(prix >= v[2] for v in voisins) and entree <= prix <= stop + atr:
                niveaux.append(prix)
    return niveaux


def _trade(bougies, i, z: Zone, objectif_r=2.0, mode_stop="zone", duree_min=DUREE_TRADE_MIN,
           point_mort_r=None, regle=None):
    """Trade simule au retour dans la zone : entree au bord de la zone (haut
    pour une zone haussiere, bas pour une baissiere), stop de l'autre cote de
    la zone + marge, objectif 2R. Si le stop et l'objectif sont dans la meme
    bougie, on compte le stop (prudence). Renvoie (R, issue, risque en $)."""
    haussiere = z.sens == "haussiere"
    if regle == "confirmation" and z.niveau:
        # entree une bougie plus tard, seulement si elle cloture encore au-dela
        # du niveau casse ; sinon pas de trade (0 R)
        if i + 1 >= len(bougies):
            return None, "en cours", 0.0
        c_suiv = bougies[i + 1][4]
        if (haussiere and c_suiv <= z.niveau) or (not haussiere and c_suiv >= z.niveau):
            return 0.0, "pas de trade", 0.0
        z = Zone(z.unite, z.sens, z.bas if haussiere else c_suiv, c_suiv if haussiere else z.haut,
                 z.debut, z.creee, z.impulsion_atr, type=z.type, niveau=z.niveau)
        i = i + 1
    entree = z.haut if haussiere else z.bas
    if mode_stop == "balayage":
        niveaux = liquidites_pres_du_stop(bougies, i, z)
        if niveaux:
            liq = min(niveaux) if haussiere else max(niveaux)
            for j in range(i, min(len(bougies), i + BALAYAGE_ATTENTE)):
                _t, _o, h, b, c = bougies[j]
                if (haussiere and c < z.bas - MARGE_STOP) or (not haussiere and c > z.haut + MARGE_STOP):
                    return 0.0, "pas de balayage", 0.0      # la zone a cede sans balayage repris
                if (haussiere and b < liq and c > liq) or (not haussiere and h > liq and c < liq):
                    entree = c
                    stop = b - MARGE_STOP if haussiere else h + MARGE_STOP
                    i = j                                   # le trade demarre a cette bougie
                    break
            else:
                if i + BALAYAGE_ATTENTE > len(bougies):
                    return None, "en cours", 0.0
                return 0.0, "pas de balayage", 0.0
            mode_stop = "deja_place"
        else:
            mode_stop = "zone"                              # pas de liquidite : trade normal
    if mode_stop == "deja_place":
        pass
    elif mode_stop == "mi":
        milieu = (z.bas + z.haut) / 2
        stop = milieu - MARGE_STOP if haussiere else milieu + MARGE_STOP
    elif str(mode_stop).startswith("atr:"):
        # stop a k fois l'ATR(14) de l'unite, mesure sur les bougies closes
        # avant l'entree (pas d'information du futur)
        k = float(str(mode_stop).split(":", 1)[1])
        debut = max(1, i - 14)
        vraies = [max(bougies[j][2] - bougies[j][3], abs(bougies[j][2] - bougies[j - 1][4]),
                      abs(bougies[j][3] - bougies[j - 1][4])) for j in range(debut, i + 1)]
        atr = sum(vraies) / len(vraies) if vraies else 1.0
        stop = entree - k * atr if haussiere else entree + k * atr
    elif str(mode_stop).startswith("liq:"):
        # stop habituel, ou plus loin s'il y a une liquidite proche : sous le
        # plus bas le plus bas (au-dessus du plus haut le plus haut) + k ATR
        k = float(str(mode_stop).split(":", 1)[1])
        stop = z.bas - MARGE_STOP if haussiere else z.haut + MARGE_STOP
        niveaux = liquidites_pres_du_stop(bougies, i, z)
        if niveaux:
            atr = _atr_avant(bougies, i)
            if haussiere:
                stop = min(stop, min(niveaux) - k * atr)
            else:
                stop = max(stop, max(niveaux) + k * atr)
    else:
        stop = z.bas - MARGE_STOP if haussiere else z.haut + MARGE_STOP
    risque = abs(entree - stop)
    objectif = entree + objectif_r * risque if haussiere else entree - objectif_r * risque
    t0 = bougies[i][0]
    dernier = entree
    stop_vers_zero = False
    for j, (t, o, h, b, c) in enumerate(bougies[i:]):
        stop_touche = (b <= stop) if haussiere else (h >= stop)
        but_touche = (h >= objectif) if haussiere else (b <= objectif)
        if j == 0:
            but_touche = False            # la bougie d'entree ne compte pas pour l'objectif
        if stop_touche:
            if stop_vers_zero:
                return 0.0, "point mort", round(risque, 2)
            return -1.0, "stop", round(risque, 2)
        if but_touche:
            return objectif_r, "objectif", round(risque, 2)
        if regle == "invalidation" and z.niveau and j > 0:
            # cloture revenue de l'autre cote du niveau casse : fausse cassure
            if (haussiere and c < z.niveau) or (not haussiere and c > z.niveau):
                r = ((c - entree) if haussiere else (entree - c)) / risque
                return round(r, 2), "fausse cassure", round(risque, 2)
        # point mort : une fois le prix parti de point_mort_r, le stop passe a
        # l'entree (applique a partir de la bougie suivante, par prudence)
        if point_mort_r and j > 0:
            seuil = entree + point_mort_r * risque if haussiere else entree - point_mort_r * risque
            if (h >= seuil) if haussiere else (b <= seuil):
                if (haussiere and stop < entree) or (not haussiere and stop > entree):
                    stop = entree
                    stop_vers_zero = True
        dernier = c
        if t - t0 >= duree_min * 60:
            r = ((dernier - entree) if haussiere else (entree - dernier)) / risque
            return round(r, 2), "temps", round(risque, 2)
    return None, "en cours", round(risque, 2)


def actives(toutes: list[Zone], maintenant: float) -> list[Zone]:
    """Zones non cassées, les plus récentes d'abord, ZONES_MAX par unité."""
    sortie = []
    for unite in REGLAGES:
        vivantes = [z for z in toutes if z.unite == unite and z.cassee is None and z.type == "VI"
                    and maintenant - z.creee < 24 * 3600]
        sortie += sorted(vivantes, key=lambda z: -z.creee)[:ZONES_MAX]
    return sortie


def enregistrer(toutes: list[Zone], deja: set) -> None:
    """Écrit les retours terminés (issue connue) une seule fois."""
    nouvelles = []
    for z in toutes:
        for n_retour, (t, prix, issue, m15, m60, trade, variantes, tend, dol) in enumerate(z.retours, 1):
            if issue == "en cours" or any(v is None for v in variantes.values()):
                continue
            cle = f"{z.type}|{z.unite}|{z.debut}|{z.creee}|{t}"
            if cle in deja:
                continue
            deja.add(cle)
            quand = time.localtime(t)
            nouvelles.append({
                "date": time.strftime("%d/%m/%Y", quand), "heure": time.strftime("%H:%M", quand),
                "type": z.type, "unite": z.unite, "sens": z.sens, "bas": z.bas, "haut": z.haut,
                "impulsion_atr": z.impulsion_atr, "entree_prix": prix, "issue": issue,
                "mouv_15min": "" if m15 is None else m15, "mouv_60min": "" if m60 is None else m60,
                "retour_n": n_retour, "cle": cle,
                "trade_issue": trade[1], "risque": trade[2], **variantes,
                "tendance_h1": tend,
                "sens_tendance": ("" if not tend else "mixte" if tend == "mixte"
                                  else "avec" if tend == z.sens else "contre"),
                # dollar « avec » la zone quand il va en sens inverse de l'or attendu
                "dollar_h1": dol,
                "accord_dollar": ("" if not dol else "mixte" if dol == "mixte"
                                  else "avec" if dol != z.sens else "contre"),
            })
    if not nouvelles:
        return
    DOSSIER.mkdir(parents=True, exist_ok=True)
    if FICHIER.exists():
        # ancien format (sans trade simule) : on repart d'un fichier neuf, l'historique
        # recent est de toute facon recalcule depuis les bougies
        with open(FICHIER, encoding="utf-8-sig") as f:
            entete = f.readline()
        if "r_be15" not in entete:
            FICHIER.replace(FICHIER.with_name(time.strftime("valeurs_initiales_%Y%m%d_%H%M.csv")))
            deja.clear()
            return enregistrer(toutes, deja)
    nouveau = not FICHIER.exists()
    with open(FICHIER, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=COLONNES, delimiter=";")
        if nouveau:
            w.writeheader()
        w.writerows(nouvelles)


def cles_existantes() -> set:
    """Retours deja enregistres. Si le fichier date d'une version sans les
    dernieres colonnes (ex. variantes avec point mort), il est mis de cote :
    tout l'historique recent est alors recalcule avec les nouvelles colonnes.
    (01/10 : les colonnes BE restaient vides, rien n'etant reecrit.)"""
    try:
        with open(FICHIER, encoding="utf-8-sig") as f:
            entete = f.readline()
        if any(col not in entete for col in COLONNES):
            FICHIER.replace(FICHIER.with_name(time.strftime("valeurs_initiales_%Y%m%d_%H%M.csv")))
            return set()
        with open(FICHIER, encoding="utf-8-sig") as f:
            return {l.get("cle", "") for l in csv.DictReader(f, delimiter=";")} - {""}
    except OSError:
        return set()


def position(prix: float, cote: str, zones_actives: list[Zone]) -> str:
    """Pour un signal : « soutien » s'il se produit dans une zone d'origine
    de son sens (continuation), « contre » dans une zone de sens opposé,
    « aucune » sinon."""
    for z in zones_actives:
        if z.bas - 0.3 <= prix <= z.haut + 0.3:
            meme = (z.sens == "haussiere") == (cote == "acheteur")
            return f"{'soutien' if meme else 'contre'} {z.unite}"
    return "aucune"


def _historique_complet() -> tuple:
    """Toutes les lignes de TOUS les fichiers de resultats (le fichier en cours
    et les anciens mis de cote avec leur date), sans doublon : un meme retour
    present dans deux fichiers ne compte qu'une fois (on garde la version la
    plus recente, qui a le plus de colonnes)."""
    fichiers = sorted(DOSSIER.glob("valeurs_initiales*.csv"), key=lambda f: f.stat().st_mtime)
    if FICHIER in fichiers:
        fichiers.remove(FICHIER)
        fichiers.append(FICHIER)
    par_cle: dict = {}
    for fichier in fichiers:
        try:
            with open(fichier, encoding="utf-8-sig") as f:
                for l in csv.DictReader(f, delimiter=";"):
                    cle = (l.get("date"), l.get("heure"), l.get("type") or "VI", l.get("unite"),
                           l.get("sens"), l.get("bas"), l.get("haut"))
                    par_cle[cle] = l
        except OSError:
            continue
    return list(par_cle.values()), fichiers


def _semaine(date_texte):
    from datetime import datetime, timedelta
    try:
        jour = datetime.strptime(date_texte, "%d/%m/%Y")
    except (TypeError, ValueError):
        return None
    return (jour - timedelta(days=jour.weekday())).date()


def _table_liquidite(lignes: list) -> None:
    """Stop chasse ? Pour les deux signaux du bot, selon qu'une liquidite se
    trouve pres du stop : esperance de chaque facon de faire ET taille moyenne
    du stop (en pips) - un meilleur resultat avec un stop de 200 pips ne sert a rien."""
    def chiffres(groupe, col_r, col_stop):
        rs, stops = [], []
        for l in groupe:
            try:
                rs.append(float(l[col_r]))
            except (KeyError, TypeError, ValueError):
                continue
            try:
                taille = float(l.get(col_stop) or 0)
                if taille > 0:
                    stops.append(taille * 10)          # 1 $ = 10 pips sur l'or
            except (TypeError, ValueError):
                pass
        if not rs:
            return "-"
        stop = f"{sum(stops) / len(stops):.0f} p" if stops else "-"
        return f"{sum(rs) / len(rs):+.2f} R · {stop} ({len(rs)})"

    familles = [
        ("VI M15 · contre la tendance",
         lambda l: (l.get("type") or "VI") == "VI" and l.get("unite") == "M15" and l.get("sens_tendance") == "contre"),
        ("BOS cassure M15 · avec la tendance",
         lambda l: l.get("type") == "BOS cassure" and l.get("unite") == "M15" and l.get("sens_tendance") == "avec"),
        ("Toutes zones M15", lambda l: l.get("unite") == "M15"),
    ]
    avec_colonne = [l for l in lignes if l.get("liq_proche") in ("oui", "non")]
    if not avec_colonne:
        return
    print("\n  LIQUIDITE PRES DU STOP : esperance · stop moyen en pips (cas)")
    print("  " + " " * 52 + "".join(f"{t:>28}" for t in ("stop zone (actuel)", "stop sous liq. +0,5 ATR",
                                                           "stop sous liq. +1 ATR", "entree apres balayage")))
    for nom, filtre in familles:
        for etat in ("oui", "non"):
            groupe = [l for l in avec_colonne if filtre(l) and l.get("liq_proche") == etat]
            if not groupe:
                continue
            cases = [chiffres(groupe, "r_4h", "risque"), chiffres(groupe, "r_liq05", "stop_liq05"),
                     chiffres(groupe, "r_liq1", "stop_liq1"), chiffres(groupe, "r_balayage", "stop_balayage")]
            print(f"  {nom:<36} liquidite {etat:<5}" + "".join(f"{c:>28}" for c in cases))

def _par_semaine(lignes: list) -> None:
    """La meme strategie, semaine par semaine : on voit si elle tient en
    tendance ET en range, ou seulement dans un des deux regimes."""
    def zone(types, unite=None, tend=None):
        return lambda l: ((l.get("type") or "VI") in types and (unite is None or l.get("unite") == unite)
                          and (tend is None or l.get("sens_tendance") == tend))
    familles = [
        ("Valeur initiale M15 · avec la tendance", zone(("VI",), "M15", "avec")),
        ("Valeur initiale M15 · contre la tendance", zone(("VI",), "M15", "contre")),
        ("FVG/IFVG/BPR · avec la tendance", zone(("FVG", "IFVG", "BPR"), None, "avec")),
        ("FVG/IFVG/BPR · contre la tendance", zone(("FVG", "IFVG", "BPR"), None, "contre")),
        ("BOS cassure M15 · avec la tendance", zone(("BOS cassure",), "M15", "avec")),
        ("Toutes zones · avec la tendance", lambda l: l.get("sens_tendance") == "avec"),
        ("Toutes zones · contre la tendance", lambda l: l.get("sens_tendance") == "contre"),
        ("Toutes zones · tendance mixte", lambda l: l.get("sens_tendance") == "mixte"),
    ]
    semaines = sorted({_semaine(l.get("date", "")) for l in lignes} - {None})
    if not semaines:
        return

    def esperance(groupe, col):
        valeurs = []
        for l in groupe:
            try:
                valeurs.append(float(l[col]))
            except (KeyError, TypeError, ValueError):
                continue
        return f"{sum(valeurs) / len(valeurs):+.2f} R ({len(valeurs)})" if valeurs else "-"

    print("\n  PAR SEMAINE : esperance « 2R, stop zone, 4 h »  /  « 2R 4 h, stop 1,5 ATR »")
    print("  " + " " * 42 + "".join(f"{'sem. du ' + s_.strftime('%d/%m'):>32}" for s_ in semaines))
    for nom, filtre in familles:
        cases = []
        for s_ in semaines:
            groupe = [l for l in lignes if filtre(l) and _semaine(l.get("date", "")) == s_]
            cases.append(f"{esperance(groupe, 'r_4h')} / {esperance(groupe, 'r_atr15')}")
        print(f"  {nom:<42}" + "".join(f"{c:>32}" for c in cases))


def bilan() -> None:
    lignes, fichiers = _historique_complet()
    if not lignes:
        print("RETOURS SUR VALEUR INITIALE - aucun enregistrement pour l'instant")
        return
    from datetime import datetime
    dates = sorted({datetime.strptime(l["date"], "%d/%m/%Y") for l in lignes if l.get("date")})
    if dates:
        print(f"HISTORIQUE COMPLET : {len(fichiers)} fichier(s), du {dates[0]:%d/%m} au {dates[-1]:%d/%m}, "
              f"{len(lignes)} retours sans doublon. Les colonnes recentes (BE, ATR, fausse cassure,"
              f" dollar) n'existent que pour les retours recents : le nombre de cas est entre"
              f" parentheses.\n")
    nb_vi = sum(1 for l in lignes if l.get("type", "VI") == "VI")
    print(f"RETOURS SUR VALEUR INITIALE - {nb_vi} retours termines "
          f"(+ FVG, IFVG, BPR et OPR plus bas : {len(lignes) - nb_vi} retours)")
    print("(zone d'origine d'une impulsion ; continuation = le prix repart dans le sens de")
    print(" l'impulsion sans cloturer au-dela ; inversion = il traverse la zone ;")
    print(" mouvements en $ depuis le milieu de la zone, positifs = sens de l'impulsion ;")
    print(" trade 2R = entree au bord de la zone, stop de l'autre cote + 0,50 $, objectif 2R,")
    print(" solde au bout de 2 h ; stop et objectif dans la meme bougie = stop)\n")
    toutes_lignes = lignes
    lignes = [l for l in toutes_lignes if l.get("type", "VI") == "VI"]
    groupes: dict[str, list] = {"Tous": lignes}
    autres_types = []
    for l in toutes_lignes:
        typ = l.get("type", "VI")
        if typ == "VI":
            continue
        if typ not in autres_types:
            autres_types.append(typ)
        tend = l.get("sens_tendance") or ""
        retour = "1er" if l["retour_n"] == "1" else "2e+"
        dol = l.get("accord_dollar") or ""
        for cle in (f"{typ} : tous", f"{typ} {l['unite']}", f"{typ} {l['unite']} tendance {tend}" if tend else None,
                    f"{typ} {l['unite']} tendance {tend} {retour}" if tend else None,
                    f"{typ} {l['unite']} tendance {tend} dollar {dol}" if tend and dol else None):
            if cle:
                groupes.setdefault(cle, []).append(l)
    for l in lignes:
        retour = "1er" if l["retour_n"] == "1" else "2e+"
        tend = l.get("sens_tendance") or ""
        cles = [f"unite : {l['unite']}", f"sens : {l['sens']}",
                f"retour : {'1er' if retour == '1er' else '2e et plus'}",
                f"unite et sens : {l['unite']} {l['sens']}"]
        if tend:
            cles += [f"tendance H1 : {tend}", f"{l['unite']} tendance {tend}",
                     f"{l['unite']} tendance {tend} {retour}"]
        dol = l.get("accord_dollar") or ""
        if dol:
            cles += [f"dollar : {dol}", f"{l['unite']} dollar {dol}"]
            if tend:
                cles.append(f"{l['unite']} tendance {tend} dollar {dol}")
        for cle in cles:
            groupes.setdefault(cle, []).append(l)

    def med(vals):
        vals = sorted(vals)
        return vals[len(vals) // 2] if vals else None

    for nom in sorted(groupes, key=lambda k: (k != "Tous", k)):
        g = groupes[nom]
        cont = sum(1 for l in g if l["issue"] == "continuation") / len(g) * 100
        inv = sum(1 for l in g if l["issue"] == "inversion") / len(g) * 100
        m15 = med([float(l["mouv_15min"]) for l in g if l["mouv_15min"] not in ("", None)])
        m60 = med([float(l["mouv_60min"]) for l in g if l["mouv_60min"] not in ("", None)])
        rs = [float(l["trade_r"]) for l in g if l.get("trade_r") not in ("", None)]
        risques = [float(l["risque"]) for l in g if l.get("risque") not in ("", None)]
        esp = sum(rs) / len(rs) if rs else None
        gagnes = sum(1 for r in rs if r >= 2) / len(rs) * 100 if rs else 0
        f = lambda v: "    -  " if v is None else f"{v:+6.2f}"
        print(f"  {nom:<42} {len(g):4d} | continuation {cont:5.1f} % | inversion {inv:5.1f} % | "
              f"15 min med {f(m15)} $ | 60 min med {f(m60)} $ | trade 2R : objectif {gagnes:5.1f} % | "
              f"esperance {f(esp)} R | stop med {med(risques) or 0:.2f} $")

    # comparaison des gestions : esperance en R de chaque variante
    print("\n  GESTION DU TRADE : esperance en R selon la variante (entree au bord de la zone)")
    entete = "  " + " " * 30 + "".join(f"{lib:>24}" for _, lib, *_ in VARIANTES)
    print(entete)
    for nom in ["Tous", "unite : M1", "unite : M5", "unite : M15", "unite et sens : M5 haussiere",
                "unite et sens : M5 baissiere", "unite et sens : M15 haussiere",
                "unite et sens : M15 baissiere", "retour : 1er", "retour : 2e et plus",
                "tendance H1 : avec", "tendance H1 : contre", "tendance H1 : mixte",
                "M5 tendance avec", "M5 tendance avec 2e+", "M15 tendance avec", "M15 tendance avec 2e+",
                "M15 tendance contre", "M15 tendance mixte",
                "dollar : avec", "dollar : contre", "dollar : mixte",
                "M15 tendance avec dollar avec", "M15 tendance avec dollar contre",
                "M15 tendance avec dollar mixte",
                "BOS cassure M15 tendance avec dollar avec", "BOS cassure M15 tendance avec dollar contre"] + [
                f"{typ} {u}{suite}" for typ in autres_types for u in ("M5", "M15")
                for suite in ("", " tendance avec", " tendance avec 2e+", " tendance contre")]:
        g = groupes.get(nom)
        if not g:
            continue
        cellules = []
        for col, *_ in VARIANTES:
            rs = [float(l[col]) for l in g if l.get(col) not in ("", None)]
            cellules.append(f"{(sum(rs) / len(rs)):+.2f} R ({len(rs)})" if rs else "-")
        print(f"  {nom:<30}" + "".join(f"{c:>24}" for c in cellules))
    _par_semaine(toutes_lignes)
    _table_liquidite(toutes_lignes)
