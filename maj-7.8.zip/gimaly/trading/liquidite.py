r"""
gimaly/trading/liquidite.py - G.I.M.A.L.Y
Traduction en Python de l'indicateur TradingView
"Buyside & Sellside Liquidity [LuxAlgo]".

Licence d'origine : CC BY-NC-SA 4.0 (c) LuxAlgo
https://creativecommons.org/licenses/by-nc-sa/4.0/
-> usage personnel et non commercial uniquement, attribution conservee.
   Ne pas inclure ce fichier dans une version vendue de GIMALY.

Ce module ne dessine rien : il calcule les memes niveaux que l'indicateur
et signale les evenements utiles au bot :
  - "niveau_achat"  : nouvelle liquidite cote achat (au-dessus des sommets)
  - "niveau_vente"  : nouvelle liquidite cote vente (sous les creux)
  - "casse_achat"   : le prix a balaye une liquidite cote achat
  - "casse_vente"   : le prix a balaye une liquidite cote vente
A appeler une fois par bougie FERMEE.

Test sur ton MT5 (compare avec ton graphique TradingView en M1) :
  .\.venv\Scripts\python.exe -m gimaly.trading.liquidite
"""
import math
from collections import deque
from dataclasses import dataclass

TAILLE_ZZ = 50


@dataclass
class Niveau:
    cote: str            # "achat" (buyside) ou "vente" (sellside)
    prix: float          # la ligne de liquidite
    zone_haut: float     # zone de detection autour du niveau
    zone_bas: float
    debut: int           # index de la bougie ou le niveau commence
    casse: bool = False  # le prix l'a deja balaye
    zone_active: bool = False  # le prix reste dans la zone apres le balayage
    balayage_haut: float = math.nan  # zone coloree apres le balayage
    balayage_bas: float = math.nan


class LiquiditeLuxAlgo:
    def __init__(self, longueur=7, marge=6.9, marge_achat=2.3, marge_vente=2.3,
                 niveaux_visibles=3, periode_atr=10):
        self.longueur = longueur
        self.liq_mar = 10 / marge
        self.marge_achat = marge_achat
        self.marge_vente = marge_vente
        self.visibles = niveaux_visibles
        self.periode_atr = periode_atr
        # zigzag : direction, index, prix (le plus recent en tete)
        self.zz_d = [0] * TAILLE_ZZ
        self.zz_x = [0] * TAILLE_ZZ
        self.zz_y = [math.nan] * TAILLE_ZZ
        self.niveaux_achat = []
        self.niveaux_vente = []
        self.hauts = deque(maxlen=longueur + 2)
        self.bas = deque(maxlen=longueur + 2)
        self.i = -1
        self.atr = math.nan
        self._tr_debut = []
        self._close_prec = math.nan

    # --------------------------------------------------------- outils
    def _maj_atr(self, h, l, c):
        if math.isnan(self._close_prec):
            tr = h - l
        else:
            tr = max(h - l, abs(h - self._close_prec), abs(l - self._close_prec))
        self._close_prec = c
        n = self.periode_atr
        if math.isnan(self.atr):
            self._tr_debut.append(tr)
            if len(self._tr_debut) == n:
                self.atr = sum(self._tr_debut) / n
        else:
            self.atr = (self.atr * (n - 1) + tr) / n

    def _pivot(self, serie, haut):
        """Pivot confirme par 1 bougie a droite (ta.pivothigh/low(longueur, 1))."""
        if len(serie) < self.longueur + 2:
            return None
        v = list(serie)
        cand, gauche, droite = v[-2], v[:-2], v[-1]
        if haut:
            ok = all(cand > x for x in gauche) and cand > droite
        else:
            ok = all(cand < x for x in gauche) and cand < droite
        return cand if ok else None

    def _empiler(self, d, x, y):
        self.zz_d.insert(0, d); self.zz_x.insert(0, x); self.zz_y.insert(0, y)
        self.zz_d.pop(); self.zz_x.pop(); self.zz_y.pop()

    def _chercher(self, piv, direction, cote, liste, calcul):
        m = self.atr / self.liq_mar
        compte, st_b, st_p, maxi, mini = 0, 0, 0.0, 0.0, 10e6
        for k in range(TAILLE_ZZ):
            if self.zz_d[k] != direction:
                continue
            y = self.zz_y[k]
            if direction == 1 and y > piv + m:
                break
            if direction == -1 and y < piv - m:
                break
            if piv - m < y < piv + m:
                compte += 1
                st_b, st_p = self.zz_x[k], y
                maxi, mini = max(maxi, y), min(mini, y)
        if compte <= 2 or not calcul:
            return None
        milieu = (maxi + mini) / 2
        if liste and liste[0].debut == st_b:
            liste[0].zone_haut, liste[0].zone_bas = milieu + m, milieu - m
            return None
        liste.insert(0, Niveau(cote, st_p, milieu + m, milieu - m, st_b))
        if len(liste) > self.visibles:
            liste.pop()
        return "niveau_" + cote

    # --------------------------------------------------------- une bougie
    def maj(self, o, h, l, c, calcul=True):
        """Ajoute une bougie fermee. Renvoie la liste des evenements.
        calcul=False reproduit le mode 'Present' (niveaux ignores hors des 500 dernieres bougies)."""
        self.i += 1
        self._maj_atr(h, l, c)
        self.hauts.append(h)
        self.bas.append(l)
        ev = []
        x2 = self.i - 1
        atr_ok = not math.isnan(self.atr)

        ph = self._pivot(self.hauts, True)
        if ph is not None:
            d, y1 = self.zz_d[0], self.zz_y[0]
            if d < 1:
                self._empiler(1, x2, ph)
            elif d == 1 and ph > y1:
                self.zz_x[0], self.zz_y[0] = x2, ph
            if atr_ok:
                e = self._chercher(ph, 1, "achat", self.niveaux_achat, calcul)
                if e:
                    ev.append(e)

        pl = self._pivot(self.bas, False)
        if pl is not None:
            d, y1 = self.zz_d[0], self.zz_y[0]
            if d > -1:
                self._empiler(-1, x2, pl)
            elif d == -1 and pl < y1:
                self.zz_x[0], self.zz_y[0] = x2, pl
            if atr_ok:
                e = self._chercher(pl, -1, "vente", self.niveaux_vente, calcul)
                if e:
                    ev.append(e)

        if atr_ok:
            for n in self.niveaux_achat:
                if not n.casse:
                    if h > n.zone_haut:
                        n.casse = n.zone_active = True
                        n.balayage_haut = min(n.prix + self.marge_achat * self.atr, h)
                        n.balayage_bas = n.prix
                        ev.append("casse_achat")
                elif n.zone_active:
                    ecart = self.marge_achat * self.atr
                    if n.prix - ecart < l and h < n.prix + ecart:
                        n.balayage_haut = max(h, n.balayage_haut)
                    else:
                        n.zone_active = False
            for n in self.niveaux_vente:
                if not n.casse:
                    if l < n.zone_bas:
                        n.casse = n.zone_active = True
                        n.balayage_haut = n.prix
                        n.balayage_bas = max(n.prix - self.marge_vente * self.atr, l)
                        ev.append("casse_vente")
                elif n.zone_active:
                    ecart = self.marge_vente * self.atr
                    if n.prix - ecart < l and h < n.prix + ecart:
                        n.balayage_bas = min(l, n.balayage_bas)
                    else:
                        n.zone_active = False
        return ev


def calculer(bougies, mode_present=True, **reglages):
    """bougies : liste de (open, high, low, close). Renvoie l'indicateur et les evenements par index."""
    ind = LiquiditeLuxAlgo(**reglages)
    total = len(bougies)
    evenements = {}
    for k, (o, h, l, c) in enumerate(bougies):
        calcul = (total - 1 - k) <= 500 if mode_present else True
        ev = ind.maj(o, h, l, c, calcul)
        if ev:
            evenements[k] = ev
    return ind, evenements


from gimaly.trading.symbole import symbole_or  # symbole de l'or du courtier

if __name__ == "__main__":
    from datetime import datetime, timezone
    import MetaTrader5 as mt5

    if not mt5.initialize():
        raise SystemExit(f"MT5 injoignable : {mt5.last_error()}")
    try:
        rates = mt5.copy_rates_from_pos(symbole_or(), mt5.TIMEFRAME_M1, 1, 1500)  # 1 = bougies fermees
        if rates is None:
            raise SystemExit(f"Pas de donnees XAUUSD : {mt5.last_error()}")
        bougies = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"])) for r in rates]
        ind, ev = calculer(bougies)
        heure = lambda k: datetime.fromtimestamp(int(rates[k]["time"]), tz=timezone.utc).strftime("%d/%m %H:%M")
        print(f"XAUUSD M1 - {len(bougies)} bougies - ATR {ind.atr:.2f} (heures serveur)\n")
        for titre, liste in (("LIQUIDITE ACHAT (buyside, au-dessus)", ind.niveaux_achat),
                             ("LIQUIDITE VENTE (sellside, en dessous)", ind.niveaux_vente)):
            print(titre)
            for n in liste:
                etat = "balayee" if n.casse else "intacte"
                print(f"  {n.prix:.2f}  depuis {heure(n.debut)}  zone {n.zone_bas:.2f}-{n.zone_haut:.2f}  {etat}")
        print("\nDerniers evenements :")
        for k in sorted(ev)[-10:]:
            print(f"  {heure(k)}  {', '.join(ev[k])}")
    finally:
        mt5.shutdown()
