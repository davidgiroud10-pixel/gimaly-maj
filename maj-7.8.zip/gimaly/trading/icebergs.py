﻿r"""
gimaly/trading/icebergs.py - G.I.M.A.L.Y
Detecteur d'icebergs sur le flux KMM (or GC), en MODE OBSERVATION :
aucun ordre n'est passe. Chaque iceberg repere est affiche, puis suivi
15 minutes pour mesurer ce que le prix a fait ensuite.

Iceberg VENDEUR : des acheteurs frappent sans arret le meme prix vendeur,
le volume echange depasse largement la quantite affichee, qui se recharge.
Iceberg ACHETEUR : l'inverse, sur le prix acheteur.

Commandes (depuis C:\Users\<toi>\gimaly, MT5 ouvert de preference) :
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs --fond      lancer en arriere-plan
                                                                    (PowerShell peut etre ferme)
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs --etat      voir ou il en est
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs --arreter   l'arreter
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs --bilan     statistiques
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs --rejouer   rejouer le flux du jour
      (options : --volume-min 10 --ratio-min 2 --recharges-min 1 --cache-min 4
       pour essayer d'autres seuils)
  .\.venv\Scripts\python.exe -m gimaly.trading.icebergs             lancer dans cette fenetre
  (ajouter --visible pour voir la page KMM)

Fichiers dans C:\Users\<toi>\GIMALY\trading :
  icebergs.csv (resultats), icebergs.log (journal), icebergs_etat.json (etat pour GIMALY)
Mouvements en $ : POSITIF = le prix est parti dans le sens de l'iceberg
(baisse apres un iceberg vendeur, hausse apres un iceberg acheteur).
"""
import argparse
import bisect
import csv
import gzip
import json
import math
import os
import statistics
import subprocess
import sys
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

DOSSIER = Path.home() / "GIMALY" / "trading"
FICHIER = DOSSIER / "icebergs.csv"
ETAT = DOSSIER / "icebergs_etat.json"
CARNET = DOSSIER / "carnet.json"          # carnet complet (DOM), pour la console GIMALY v2
CARNET_PROFONDEUR = 15                    # niveaux de chaque côté
CARNET_PERIODE_S = 0.5                    # au plus 2 écritures par seconde
CARTE = DOSSIER / "icebergs_carte.json"
DECALAGE = DOSSIER / "decalage_mt5.json"    # heure serveur MT5 - heure du PC (s)
# unites de temps des signaux valeur initiale et BOS proposes au bot. Bilan du
# 29/09 (528 retours) : M15 dans le sens de la tendance +0,41 R, M5 -0,30 R.
UNITES_SIGNAUX_ZONES = ("M15",)
FERME_APRES_S = 300          # plus de nouveau tick MT5 depuis 5 min = marche ferme     # carte du volume echange (heatmap du graphique)
JOURNAL = DOSSIER / "icebergs.log"
STOP = DOSSIER / "icebergs.stop"
FICHIER_FLUX = DOSSIER / "flux_session.json"
FICHIER_CYCLES = DOSSIER / "cycles.csv"
FICHIER_BALAYAGES = DOSSIER / "balayages.csv"
BALAYAGE_PAUSE_S = 900          # pas deux balayages du meme sens a moins de 15 min
COLONNES_BALAYAGES = ["date", "heure", "sens", "prix_gc", "prix_xau", "niveau", "extreme",
                      "profondeur", "delai_reprise_min", "liquidite_cassee", "keltner_casse",
                      "delta_5min", "vwap_sigma", "cote_vwap", "zone_valeur", "respiration",
                      "sens_tendance", "keltner_position", "keltner_zone", "keltner_extreme",
                      "mouv_1min", "mouv_5min", "mouv_15min", "mouv_30min", "mouv_60min",
                      "max_favorable", "max_contraire", "max_favorable_60", "max_contraire_60",
                      "reaction", "delai_reaction_s", "recul_apres_reaction", "gain_apres_reaction",
                      "R_max", "R_max_60", "resultat_test", "premier_evenement", "atteint_3R",
                      "test_sl20", "test_sl35", "test_sl50",
                      "session", "volatilite", "dollar", "dollar_favorable", "annonce_proche",
                   "tendance_score", "tendance_fond", "tendance_accord", "tendance_detail",
                   # activite du carnet sur 60 s (ActiviteCarnet) : enregistree seulement
                   "carnet_ajout_son_cote", "carnet_retrait_son_cote", "carnet_ajout_en_face",
                   "carnet_retrait_en_face", "carnet_son_cote", "carnet_en_face", "carnet_desequilibre",
                      # tape : gros ordres (« institutional flow ») et vitesse
                      "gros_son_sens", "gros_contre", "gros_ordres", "tape_1min", "tape_vitesse",
                      # zone d'origine d'une impulsion (valeurs_initiales.py)
                      "valeur_initiale", "tendance_h1", "tendance_h1_accord"]

COLONNES_CYCLES = ["date", "heure", "sens", "scenario", "prix_gc", "prix_xau", "couleur_serie",
                   "divergentes", "delta_serie", "delta_saine", "vwap_sigma", "cote_vwap",
                   "zone_valeur", "iceberg_recent", "iceberg_aligne", "mouv_1min", "mouv_5min",
                   "mouv_15min", "mouv_30min", "mouv_60min", "max_favorable", "max_contraire",
                   "max_favorable_60", "max_contraire_60", "respiration", "sens_tendance",
                   "keltner_position", "keltner_zone", "keltner_extreme",
                   "respiration_m15", "sens_tendance_m15",
                   "keltner_position_m15", "keltner_zone_m15", "keltner_extreme_m15",
                   "reaction", "delai_reaction_s", "recul_apres_reaction",
                   "gain_apres_reaction", "R_max", "R_max_60", "resultat_test",
                   "premier_evenement", "atteint_3R", "test_sl20", "test_sl35", "test_sl50",
                   "session", "volatilite", "dollar", "dollar_favorable", "annonce_proche",
                   "tendance_score", "tendance_fond", "tendance_accord", "tendance_detail"]
DOSSIER_BRUT = DOSSIER / "brut"
ENREGISTRER_BRUT = True     # garde le flux brut (compresse) pour rejouer et regler
JOURS_BRUT = 7              # jours de flux brut conserves
HORIZONS = (60, 300, 900, 1800, 3600)   # suivi a 1, 5, 15, 30 et 60 minutes
PROCHE_LIQUIDITE = 2.0          # $ : iceberg considere "sur une liquidite"
CASSE_MARGE = 1.0               # $ : un iceberg est "casse" si le prix le depasse de 1 $ (10 pips)

# Test de la methode "entree sur reaction" : on n'entre pas au moment du signal,
# on attend que la zone reagisse (le prix repart deja dans son sens), puis SL
# court et passage au point mort des que ca avance bien.
REACTION = 1.0                  # $ : la zone "reagit" quand le prix reprend 10 pips
# Fenetre de reaction pour proposer un signal au bot (bilan du 25/09) :
# moins de 1 min = negatif pour les deux familles (pic, entree mal placee) ;
# icebergs positifs de 1 a 15 min, balayages seulement de 1 a 5 min.
DIRECT_S = 1.0                  # s : rafraichissement du fichier d'etat (prix, flux, bougie en cours)
REACTION_BOT_MIN = 60           # s : plus rapide, le signal n'est pas propose
REACTION_BOT_MAX = {"iceberg": 900, "balayage": 300}   # s : plus lent, non plus
SL_TEST = 2.0                   # $ : stop de 20 pips a partir de l'entree sur reaction
# Plusieurs tailles de stop sont mesurees en parallele sur les memes signaux
# (objectif 2R a chaque fois) : les chiffres diront laquelle vaut le mieux.
SL_VARIANTES = (2.0, 3.5, 5.0)
BE_TEST = 5.0                   # $ : passage au point mort a +50 pips
EVENEMENT_S = 600               # un iceberg du meme cote a moins de 10 min...
EVENEMENT_DOLLARS = 10.0        # ... et 10 $ du precedent = renforcement du meme evenement

# Reglages de detection (a ajuster apres quelques jours d'observation)
# Regles sur le vrai flux KMM du 21/09 (11 min) : le carnet est mis a jour si
# souvent que la partie cachee et les recharges se voient rarement. Le signe
# fiable d'un iceberg est l'ABSORPTION : beaucoup plus de contrats echanges a
# un prix que ce qui y est affiche en moyenne, sans que le prix cede.
REGLAGES = dict(
    volume_min=15,      # contrats echanges au meme prix, au minimum
    ratio_min=8.0,      # volume echange >= 8 x la quantite affichee moyenne
    recharges_min=0,    # recharges visibles exigees (0 = pas exige)
    cache_min=0,        # contrats executes au-dela de l'affiche (0 = pas exige)
    affichages_min=10,  # le prix doit avoir ete vu au moins 10 fois au meilleur prix
)

COLONNES = ["date", "heure", "cote", "prix_gc", "prix_xau", "ecart_gc_xau", "volume",
            "affiche_max", "recharges", "duree_niveau_s", "atr_m1", "liq_cote", "liq_prix",
            "liq_distance", "mouv_1min", "mouv_5min", "mouv_15min", "mouv_30min", "mouv_60min",
            "max_favorable", "max_contraire", "max_favorable_60", "max_contraire_60",
            "casse", "casse_apres_s",
            # contexte du flux d'ordres au moment de l'iceberg (flux_ordres.py)
            "vwap_sigma", "cote_vwap", "zone_valeur", "dist_poc", "cvd", "delta_1min",
            "delta_5min", "pression_1min", "flux_dans_le_sens", "mur",
            # zone de respiration (respiration.py)
            "respiration", "sens_tendance",
            # regroupement par evenement
            "renforcements", "volume_total",
            # canal de Keltner (KSD)
            "keltner_position", "keltner_zone", "keltner_extreme",
            # les memes en M15
            "respiration_m15", "sens_tendance_m15",
            "keltner_position_m15", "keltner_zone_m15", "keltner_extreme_m15",
            # test de la methode "entree sur reaction"
            "reaction", "delai_reaction_s", "recul_apres_reaction",
            "gain_apres_reaction", "R_max", "R_max_60", "resultat_test",
            # ce qui arrive en premier : le stop ou l'objectif a 2R
            "premier_evenement", "atteint_3R", "test_sl20", "test_sl35", "test_sl50",
            # contexte marche (contexte_marche.py)
            "session", "volatilite", "dollar", "dollar_favorable", "annonce_proche",
            # tendance multi-echelle (M1, M5, M15, H1, H4)
            "tendance_score", "tendance_fond", "tendance_accord", "tendance_detail",
            # activite du carnet sur 60 s (ActiviteCarnet) : enregistree seulement
            "carnet_ajout_son_cote", "carnet_retrait_son_cote", "carnet_ajout_en_face",
            "carnet_retrait_en_face", "carnet_son_cote", "carnet_en_face", "carnet_desequilibre",
                      # tape : gros ordres (« institutional flow ») et vitesse
                      "gros_son_sens", "gros_contre", "gros_ordres", "tape_1min", "tape_vitesse",
                      # zone d'origine d'une impulsion (valeurs_initiales.py)
                      "valeur_initiale", "tendance_h1", "tendance_h1_accord"]


# ---------------------------------------------------------------- outils
class _Double:
    """Ecrit a la fois dans la console (si elle existe) et dans le journal."""
    def __init__(self, *flux):
        self.flux = [f for f in flux if f is not None]

    def write(self, texte):
        for f in self.flux:
            try:
                f.write(texte)
                f.flush()
            except Exception:
                pass

    def flush(self):
        pass


def _bip():
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
    except Exception:
        pass


def lire_etat():
    """Etat courant (pour GIMALY) : dict, ou None si jamais lance."""
    try:
        return json.loads(ETAT.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def en_cours():
    etat = lire_etat()
    return bool(etat and etat.get("actif") and time.time() - etat.get("maj_ts", 0) < 150)


def demarrer_en_fond():
    """Lance l'observation dans un processus invisible. Renvoie un message."""
    if en_cours():
        return "L'observation des icebergs tourne deja."
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    if not pythonw.exists():
        pythonw = Path(sys.executable)
    racine = Path(__file__).resolve().parents[2]
    options = 0
    if sys.platform == "win32":
        options = subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW
    subprocess.Popen([str(pythonw), "-m", "gimaly.trading.icebergs"], cwd=str(racine),
                     creationflags=options, close_fds=True)
    return "Observation des icebergs lancee en arriere-plan."


def arreter():
    DOSSIER.mkdir(parents=True, exist_ok=True)
    STOP.write_text("stop", encoding="utf-8")
    return "Arret demande (effectif sous quelques secondes)."


# ---------------------------------------------------------------- detection
@dataclass
class Niveau:
    """Ce qui s'est passe a UN prix, d'un cote du carnet.

    Le meilleur prix du carnet change plusieurs fois par seconde (il saute
    d'un tick et revient). La premiere version oubliait tout a chaque saut et
    ne trouvait donc rien. Maintenant un prix garde sa memoire tant que :
      - le marche ne l'a pas traverse (cote vendeur : le prix acheteur ne l'a
        pas atteint ; l'inverse cote acheteur),
      - il n'a pas disparu du carnet plus de ABSENCE_MAX_S secondes,
      - il y a eu de l'activite dans les MEMOIRE_S dernieres secondes.
    """
    cote: str                 # "vendeur" (prix vendeur / ask) ou "acheteur" (bid)
    prix: float
    debut_ms: float
    dernier_ms: float = 0
    volume: float = 0         # contrats echanges a ce prix contre ce cote
    recharges: int = 0
    vol_depuis_creux: float = 0
    derniere_taille: float = -1
    affiche_max: float = 0
    _somme_aff: float = 0
    _nb_aff: int = 0
    signale: bool = False
    absent_depuis: float = None
    restant: float = -1       # quantite affichee encore disponible (-1 : inconnue)
    cache: float = 0          # volume execute au-dela de l'affiche = partie cachee

    @property
    def affiche_moyen(self):
        return self._somme_aff / self._nb_aff if self._nb_aff else 0.0


MEMOIRE_S = 60        # un prix sans activite pendant 1 min est oublie
ABSENCE_MAX_S = 2.0   # un prix mange qui ne se recharge pas en 2 s est oublie


class ActiviteCarnet:
    """Ordres ajoutes et retires du carnet GC sur les 60 dernieres secondes
    (le « Book activity » de KMM), calcules sur le flux brut.

    Une baisse de taille a un prix, non expliquee par des transactions a ce
    prix, est un ordre retire ; une hausse est un ordre ajoute. ENREGISTRE
    seulement : n'entre ni dans la note ni dans les filtres, le bilan dira
    d'abord si ces donnees ameliorent les trades."""

    FENETRE_S = 60
    PROFONDEUR = 10
    GROS_ORDRE = 10          # contrats : au-dela, une transaction compte comme « grosse »
    FENETRE_TAPE_S = 300

    def __init__(self):
        self.precedent = {"acheteur": {}, "vendeur": {}}
        self.echanges = defaultdict(float)
        self.evenements = deque()           # (t, cote, "ajout" | "retrait", contrats)
        self.tape = deque()                 # (t, "achat" | "vente", contrats) sur 5 min
        self.derniere = None                # (prix GC, contrats, sens) de la derniere transaction
        self.bid = self.ask = math.nan

    def _transaction(self, m):
        try:
            prix, taille = float(m.get("price", 0)), float(m.get("size", 0))
        except (TypeError, ValueError):
            return
        if not prix or not taille:
            return
        self.echanges[round(prix, 2)] += taille
        # chez KMM « side » = cote du carnet touche : « sell » = acheteur agressif
        sens = {"sell": "achat", "buy": "vente"}.get(m.get("side"))
        if sens is None:
            if prix >= self.ask - 1e-9:
                sens = "achat"
            elif prix <= self.bid + 1e-9:
                sens = "vente"
            else:
                return
        t = time.time()
        self.derniere = (prix, taille, sens)
        self.tape.append((t, sens, taille))
        while self.tape and t - self.tape[0][0] > self.FENETRE_TAPE_S:
            self.tape.popleft()

    def message(self, m):
        genre = m.get("type")
        if genre == "trade":
            self._transaction(m)
            return
        if genre != "book":
            return
        t = time.time()
        for cote, cle in (("acheteur", "bids"), ("vendeur", "asks")):
            try:
                # un niveau peut porter plus que [prix, taille] (nombre d'ordres…) :
                # on lit par position, comme le detecteur, au lieu de deballer
                niveaux = {round(float(n[0]), 2): float(n[1])
                           for n in (m.get(cle) or [])[:self.PROFONDEUR]}
            except (TypeError, ValueError):
                continue
            if not niveaux:
                continue
            if cote == "acheteur":
                self.bid = max(niveaux)
            else:
                self.ask = min(niveaux)
            avant = self.precedent[cote]
            if avant:
                # seulement les prix visibles avant ET apres : un prix qui entre
                # ou sort de la fenetre parce que le marche bouge n'est ni un
                # ajout ni un retrait
                bas = max(min(niveaux), min(avant))
                haut = min(max(niveaux), max(avant))
                for prix in set(avant) | set(niveaux):
                    if not bas <= prix <= haut:
                        continue
                    ecart = niveaux.get(prix, 0.0) - avant.get(prix, 0.0)
                    if ecart > 0:
                        self.evenements.append((t, cote, "ajout", ecart))
                    elif ecart < 0:
                        execute = min(self.echanges.get(prix, 0.0), -ecart)
                        retrait = -ecart - execute
                        if retrait > 0:
                            self.evenements.append((t, cote, "retrait", retrait))
            self.precedent[cote] = niveaux
        self.echanges.clear()
        while self.evenements and t - self.evenements[0][0] > self.FENETRE_S:
            self.evenements.popleft()

    def resume(self):
        t = time.time()
        total = defaultdict(float)
        for quand, cote, genre, qte in self.evenements:
            if t - quand <= self.FENETRE_S:
                total[(cote, genre)] += qte
        resume = {f"{genre}_{cote}": round(total[(cote, genre)])
                  for cote in ("acheteur", "vendeur") for genre in ("ajout", "retrait")}
        resume.update(self.resume_tape())
        return resume

    def resume_tape(self):
        """Gros ordres sur 5 min (par sens) et vitesse du tape sur 1 min."""
        t = time.time()
        gros = {"achat": 0.0, "vente": 0.0}
        nb_1min = nb_5min = 0
        for quand, sens, taille in self.tape:
            if t - quand > self.FENETRE_TAPE_S:
                continue
            nb_5min += 1
            if t - quand <= 60:
                nb_1min += 1
            if taille >= self.GROS_ORDRE:
                gros[sens] += taille
        moyenne = nb_5min / 5
        if not nb_5min or t - self.tape[0][0] < 240:
            vitesse = ""                 # moins de 4 min de tape : pas de reference
        elif nb_1min >= 1.5 * moyenne:
            vitesse = "rapide"
        elif nb_1min <= 0.67 * moyenne:
            vitesse = "lente"
        else:
            vitesse = "normale"
        return {"gros_achat_5min": round(gros["achat"]), "gros_vente_5min": round(gros["vente"]),
                "tape_1min": nb_1min, "tape_vitesse": vitesse}

    def pour_signal(self, cote, desequilibre=None):
        """Colonnes d'un signal : son cote du carnet et celui d'en face."""
        r = self.resume()
        face = "vendeur" if cote == "acheteur" else "acheteur"
        son_net = r[f"ajout_{cote}"] - r[f"retrait_{cote}"]
        face_net = r[f"ajout_{face}"] - r[f"retrait_{face}"]
        ligne = {
            "carnet_ajout_son_cote": r[f"ajout_{cote}"], "carnet_retrait_son_cote": r[f"retrait_{cote}"],
            "carnet_ajout_en_face": r[f"ajout_{face}"], "carnet_retrait_en_face": r[f"retrait_{face}"],
            "carnet_son_cote": "" if not any(r[k] for k in r if k[:5] in ("ajout", "retra")) else ("renforce" if son_net >= 0 else "se retire"),
            "carnet_en_face": "" if not any(r[k] for k in r if k[:5] in ("ajout", "retra")) else ("renforce" if face_net >= 0 else "se retire"),
            "carnet_desequilibre": "",
        }
        # gros ordres : ceux qui poussent dans le sens du signal ou contre lui
        son_sens, contre = (("gros_achat_5min", "gros_vente_5min") if cote == "acheteur"
                            else ("gros_vente_5min", "gros_achat_5min"))
        pour, face = r.get(son_sens, 0), r.get(contre, 0)
        ligne.update({
            "gros_son_sens": pour, "gros_contre": face,
            "gros_ordres": ("aucun" if pour + face == 0
                            else "dans son sens" if pour >= 0.6 * (pour + face)
                            else "contre" if pour <= 0.4 * (pour + face) else "partages"),
            "tape_1min": r.get("tape_1min", ""), "tape_vitesse": r.get("tape_vitesse", ""),
        })
        if desequilibre is not None and not (isinstance(desequilibre, float) and math.isnan(desequilibre)):
            # desequilibre du carnet visible, rapporte au sens du signal
            d = float(desequilibre) * (1 if cote == "acheteur" else -1)
            seuil = 0.1 if abs(float(desequilibre)) <= 1 else 10
            ligne["carnet_desequilibre"] = ("dans son sens" if d >= seuil
                                            else "contre" if d <= -seuil else "equilibre")
        return ligne


class CarteVolume:
    """Volume echange par minute et par tranche de prix XAUUSD (0,5 $), achats et
    ventes separes : la « heatmap » du graphique, dans l'esprit de KMM. Faute de
    carnet en profondeur, elle montre ou le marche a reellement echange et qui
    attaquait, pas les ordres poses."""

    PAS = 0.5
    MINUTES = 480
    ECRITURE_S = 10

    def __init__(self):
        self.minutes = {}                   # minute (epoch) -> {prix: [achat, vente]}
        self._t_ecrit = 0.0
        # reprise apres redemarrage du detecteur : la carte ecrite reste valable
        try:
            donnees = json.loads(CARTE.read_text(encoding="utf-8"))
            limite = time.time() - self.MINUTES * 60
            for minute, cases in donnees.get("minutes", []):
                if minute >= limite:
                    self.minutes[int(minute)] = {float(p): [float(a), float(v)] for p, a, v in cases}
        except (OSError, ValueError, TypeError):
            pass

    def ajouter(self, t, prix_xau, taille, sens):
        minute = int(t // 60 * 60)
        tranche = round(round(prix_xau / self.PAS) * self.PAS, 2)
        case = self.minutes.setdefault(minute, {}).setdefault(tranche, [0.0, 0.0])
        case[0 if sens == "achat" else 1] += taille

    def ecrire(self, t):
        if t - self._t_ecrit < self.ECRITURE_S:
            return
        self._t_ecrit = t
        limite = t - self.MINUTES * 60
        for minute in [m for m in self.minutes if m < limite]:
            del self.minutes[minute]
        donnees = {"pas": self.PAS, "maj_ts": t, "minutes": [
            [minute, [[prix, round(a), round(v)] for prix, (a, v) in sorted(cases.items())]]
            for minute, cases in sorted(self.minutes.items())]}
        temp = CARTE.with_suffix(".tmp")
        try:
            temp.write_text(json.dumps(donnees, separators=(",", ":")), encoding="utf-8")
            os.replace(temp, CARTE)
        except OSError:
            pass


class DetecteurIcebergs:
    def __init__(self, sur_iceberg, volume_min=15, ratio_min=8.0, recharges_min=0, cache_min=0,
                 affichages_min=10):
        self.sur_iceberg = sur_iceberg
        self.affichages_min = affichages_min
        self.cache_min = cache_min
        self.volume_min = volume_min
        self.ratio_min = ratio_min
        self.recharges_min = recharges_min
        self.niveaux = {"vendeur": {}, "acheteur": {}}
        self.archive = []          # niveaux oublies avec du volume (pour le reglage)
        self.mid = math.nan
        self.bid = self.ask = math.nan
        self.t_ms = 0
        self._n = 0

    def message(self, m):
        genre = m.get("type")
        if genre == "book":
            self._carnet(m)
        elif genre == "trade":
            self._transaction(m)
        self._n += 1
        if self._n % 2000 == 0:
            self._oublier()

    def _niveau(self, cote, prix):
        cle = round(prix, 2)
        niv = self.niveaux[cote].get(cle)
        if niv is None:
            niv = self.niveaux[cote][cle] = Niveau(cote, cle, self.t_ms, self.t_ms)
        return niv

    def _retirer(self, cote, cle):
        niv = self.niveaux[cote].pop(cle)
        if niv.volume >= 5:
            self.archive.append(niv)
            if len(self.archive) > 1000:
                del self.archive[:-500]

    def _oublier(self):
        for cote in self.niveaux:
            for cle, niv in list(self.niveaux[cote].items()):
                if self.t_ms - niv.dernier_ms > MEMOIRE_S * 1000:
                    self._retirer(cote, cle)

    def _nettoyer(self):
        """Oublie les prix traverses par le marche ou manges sans recharge."""
        for cle, niv in list(self.niveaux["vendeur"].items()):
            if cle <= self.bid + 1e-9:                      # traverse vers le haut
                self._retirer("vendeur", cle)
            elif cle < self.ask - 1e-9:                     # plus au carnet : mange
                if niv.absent_depuis is None:
                    niv.absent_depuis = self.t_ms
                elif self.t_ms - niv.absent_depuis > ABSENCE_MAX_S * 1000:
                    self._retirer("vendeur", cle)
            else:
                niv.absent_depuis = None
        for cle, niv in list(self.niveaux["acheteur"].items()):
            if cle >= self.ask - 1e-9:                      # traverse vers le bas
                self._retirer("acheteur", cle)
            elif cle > self.bid + 1e-9:
                if niv.absent_depuis is None:
                    niv.absent_depuis = self.t_ms
                elif self.t_ms - niv.absent_depuis > ABSENCE_MAX_S * 1000:
                    self._retirer("acheteur", cle)
            else:
                niv.absent_depuis = None

    def _carnet(self, m):
        self.t_ms = m.get("timestamp", self.t_ms)
        bids, asks = m.get("bids") or [], m.get("asks") or []
        if not bids or not asks:
            return
        self.bid, bt = float(bids[0][0]), float(bids[0][1])
        self.ask, at = float(asks[0][0]), float(asks[0][1])
        self.mid = (self.bid + self.ask) / 2
        self._nettoyer()
        self._affiche(self._niveau("vendeur", self.ask), at)
        self._affiche(self._niveau("acheteur", self.bid), bt)

    def _affiche(self, niv, taille):
        # recharge : le prix avait ete vide par des transactions et il revient
        if niv.restant == 0 and niv.vol_depuis_creux > 0 and taille > 0:
            niv.recharges += 1
            niv.vol_depuis_creux = 0
        niv.restant = taille
        niv.derniere_taille = taille
        niv.affiche_max = max(niv.affiche_max, taille)
        niv._somme_aff += taille
        niv._nb_aff += 1
        niv.dernier_ms = self.t_ms

    def _transaction(self, m):
        self.t_ms = m.get("timestamp", self.t_ms)
        prix, taille = float(m.get("price", 0)), float(m.get("size", 0))
        if not prix or not taille:
            return
        # ATTENTION : chez KMM, "side" indique le cote du carnet qui a ete touche,
        # pas celui qui attaque (verifie sur le flux reel : les "sell" s'executent
        # au prix vendeur, les "buy" au prix acheteur). Donc "sell" = acheteur
        # agressif qui frappe le cote vendeur.
        cote = {"sell": "vendeur", "buy": "acheteur"}.get(m.get("side"))
        if cote is None:                      # "unknown" : on deduit du carnet
            if prix >= self.ask - 1e-9:
                cote = "vendeur"
            elif prix <= self.bid + 1e-9:
                cote = "acheteur"
            else:
                return
        niv = self._niveau(cote, prix)
        niv.volume += taille
        niv.vol_depuis_creux += taille
        niv.dernier_ms = self.t_ms
        if niv.restant >= 0:
            if taille > niv.restant:              # plus que ce qui etait affiche
                niv.cache += taille - niv.restant
                niv.restant = 0
            else:
                niv.restant -= taille
        if (not niv.signale and niv.volume >= self.volume_min
                and niv.cache >= self.cache_min
                and niv._nb_aff >= self.affichages_min
                and niv.volume >= self.ratio_min * max(niv.affiche_moyen, 1)
                and niv.recharges >= self.recharges_min):
            niv.signale = True
            self.sur_iceberg(niv, (self.t_ms - niv.debut_ms) / 1000)

    def candidats(self, n=15):
        """Les prix ou il s'est le plus echange (pour regler les seuils)."""
        tous = self.archive + [v for c in self.niveaux.values() for v in c.values()]
        return sorted(tous, key=lambda v: v.volume, reverse=True)[:n]


# ---------------------------------------------------------------- observation
@dataclass
class Observation:
    cote: str
    prix: float
    t0: float
    prix_ref: float
    ligne: dict
    suivis: dict = field(default_factory=dict)
    max_fav: float = 0.0
    max_contre: float = 0.0
    casse_apres: float = None
    genre: str = "iceberg"      # "iceberg" ou "cycle"
    dernier_t: float = 0.0      # dernier iceberg de l'evenement (renforcements)
    dernier_prix: float = 0.0
    renforcements: int = 0
    volume_total: float = 0.0
    # entree sur reaction
    reaction_dt: float = None   # secondes entre le signal et la reaction
    reaction_mouv: float = 0.0  # mouvement deja fait au moment de l'entree
    apres_fav: float = 0.0
    apres_contre: float = 0.0
    etat_test: str = ""
    premier: str = ""           # "stop" ou "2R" : ce qui est arrive en premier
    trois_r: bool = False
    variantes: dict = field(default_factory=lambda: {v: "" for v in SL_VARIANTES})
    # valeurs figees a 15 min (les colonnes sans suffixe gardent ce sens)
    fav15: float = None
    contre15: float = None
    apres_fav15: float = None


class Observateur:
    def __init__(self, avec_mt5=True):
        DOSSIER.mkdir(parents=True, exist_ok=True)
        _preparer_fichier()
        if not FICHIER.exists():
            with open(FICHIER, "w", newline="", encoding="utf-8-sig") as f:
                csv.writer(f, delimiter=";").writerow(COLONNES)
        from gimaly.trading.flux_ordres import FluxOrdres
        self.flux = FluxOrdres()
        self.flux.sur_cycle = self.nouveau_cycle
        self.derniers_cycles = deque(maxlen=10)
        self.derniers_balayages = deque(maxlen=10)
        self.nb_balayages = 0
        self._dernier_balayage = {}
        self.marche = {}
        self.tendances = {}
        self.tendance = None
        self._icebergs_recents = deque(maxlen=50)   # (heure, cote, prix) pour les cycles
        self.nb_cycles = 0
        if self.flux.charger(FICHIER_FLUX):
            print(f"Session reprise : CVD {self.flux.cvd:+.0f}, {self.flux.nb_trades} transactions deja comptees.")
        self.det = DetecteurIcebergs(self.nouvel_iceberg, **REGLAGES)
        self.activite = ActiviteCarnet()
        self.carte = CarteVolume()
        # Marche ferme (week-end, pause du soir) : le prix MT5 ne bouge plus.
        # Avant, le detecteur continuait a signaler des balayages sur les
        # bougies du vendredi, et l'heure des bougies partait de plusieurs jours.
        self._tick_mt5 = None             # dernier tick.time vu
        self._tick_change_t = 0.0         # heure du PC a laquelle il a change
        try:
            self._decalage = int(json.loads(DECALAGE.read_text(encoding="utf-8"))["s"])
        except (OSError, ValueError, KeyError, TypeError):
            self._decalage = None
        self.en_cours = []
        self.nb = 0
        self.ecart = math.nan
        self.atr = math.nan
        self.niveaux_liq = []
        self.respiration = None
        self.keltner = None
        self.respiration_m15 = None
        self.keltner_m15 = None
        self.respirations_affichage = {}   # M3, M5, M30 : affichage seulement
        # valeurs initiales : zones d'origine des impulsions (M1, M5, M15)
        self.vi_actives = []
        self._vi_proposees = set()        # zones deja proposees au bot (une fois par retour)
        self._vi_cache = {}               # unite -> (derniere bougie, zones calculees)
        self._vi_derniere = {}            # zone -> derniere proposition au bot
        self.bougies_ut = {}              # M5, M15, H1 pour le graphique
        self.tendance_h1 = ""             # haussiere / baissiere / mixte (EMA 20/50 H1)
        try:
            from gimaly.trading.valeurs_initiales import cles_existantes
            self._vi_cles = cles_existantes()
        except Exception:
            self._vi_cles = set()
        self._t_tick = 0
        self._t_liq = 0
        self._t_balayage = 0
        self._bougies_m1 = None
        self.nb_msg = 0
        self._nb_msg_prec = 0
        self._t_etat = time.time()
        self.derniers = deque(maxlen=20)
        self.bougies_graph = []         # bougies M1 pour le graphique du panneau
        self.xau_mt5 = None             # prix bid MT5, comme sur le graphique MT5
        self._t_direct = 0.0
        self._brut = None
        self._brut_jour = None
        self.mt5 = None
        if avec_mt5:
            try:
                import MetaTrader5 as mt5
                if mt5.initialize():
                    self.mt5 = mt5
                else:
                    print("MT5 injoignable : observation sans prix XAUUSD ni liquidites.")
            except ImportError:
                print("Module MetaTrader5 absent : observation sans MT5.")

    # -- donnees MT5 : ecart GC/XAUUSD et niveaux de liquidite
    def _maj_mt5(self, t):
        # 05/10 : seul l'ecart GC-XAUUSD a besoin du prix COMEX (KMM). Avant, sans
        # KMM, TOUTE la mise a jour MT5 etait sautee : plus de bougies, de
        # tendance H1, de zones ni de BOS, donc plus aucun signal pour le bot.
        if not self.mt5:
            return
        if t - self._t_tick >= 5 and not math.isnan(self.det.mid):
            self._t_tick = t
            tick = self.mt5.symbol_info_tick(symbole_or())
            if tick and tick.bid > 0:
                e = self.det.mid - (tick.bid + tick.ask) / 2
                self.ecart = e if math.isnan(self.ecart) else 0.8 * self.ecart + 0.2 * e
        if t - self._t_balayage >= 15 and self._bougies_m1:
            self._t_balayage = t
            try:
                self._verifier_balayage()
            except Exception as e:
                print(f"Balayage non verifie : {e!r}")
        if t - self._t_liq >= 60:
            self._t_liq = t
            try:
                from gimaly.trading.liquidite import calculer
                rates = self.mt5.copy_rates_from_pos(symbole_or(), self.mt5.TIMEFRAME_M1, 1, 1500)
                if rates is not None and len(rates) > 50:
                    bougies = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                               for r in rates]
                    ind, _ = calculer(bougies)
                    self._maj_bougies_graph(rates)
                    self.atr = ind.atr
                    self.niveaux_liq = ind.niveaux_achat + ind.niveaux_vente
                    from gimaly.trading.respiration import calculer as zone_respiration, keltner
                    self.respiration = zone_respiration(bougies)
                    self.keltner = keltner(bougies)
                rates15 = self.mt5.copy_rates_from_pos(symbole_or(), self.mt5.TIMEFRAME_M15, 1, 500)
                if rates15 is not None and len(rates15) > 50:
                    from gimaly.trading.respiration import calculer as zone_respiration, keltner, PIVOT_N_M15
                    b15 = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                           for r in rates15]
                    self.respiration_m15 = zone_respiration(b15, pivot_n=PIVOT_N_M15)
                    self.keltner_m15 = keltner(b15)
                # affichage M3 / M5 / M30 : toutes les 5 min suffisent (moins de
                # demandes a MT5, qui se figeait aux heures chargees)
                # chaque calcul dans son propre bloc : une erreur dans l'un ne
                # doit plus empecher le contexte de marche, les tendances et les
                # balayages (01/10 : « contexte marche non disponible »)
                if t - getattr(self, "_t_resp_affichage", 0) >= 300:
                    self._t_resp_affichage = t
                    try:
                        self._maj_respirations_affichage()
                    except Exception as e:
                        print(f"Respirations M3/M5/M30 non calculees : {e!r}")
                try:
                    self._maj_valeurs_initiales(rates, rates15)
                except Exception as e:
                    import traceback
                    lieu = " <- ".join(f"{f.name}:{f.lineno}" for f in reversed(traceback.extract_tb(e.__traceback__)[-4:]))
                    print(f"Valeurs initiales / BOS non calcules : {e!r} [{lieu}]")
                try:
                    # tableau macro (FRED) : telecharge en fond, au plus toutes les 6 h
                    from gimaly.trading import macro
                    macro.rafraichir_en_fond()
                except Exception:
                    pass
                self._maj_tendances(bougies)
                if rates is not None and len(rates) > 200:
                    from gimaly.trading import contexte_marche
                    self.marche = contexte_marche.resume(self.mt5, bougies)
                    self._bougies_m1 = bougies          # relues toutes les 15 s pour les balayages
                self._verifier_balayage(bougies)
            except Exception as e:
                print(f"Liquidite non calculee : {e!r}")

    def _maj_valeurs_initiales(self, rates1, rates15):
        """Zones d'origine des impulsions : recalculees chaque minute depuis les
        bougies ; chaque retour termine est ecrit une fois pour le bilan."""
        from gimaly.trading import valeurs_initiales as vi
        tick = self.mt5.symbol_info_tick(symbole_or())
        decalage = self._decalage_mt5(tick)
        # M5 : chaque minute (une nouvelle bougie toutes les 5 min) ; H1 : toutes les 10 min
        rates5 = self.mt5.copy_rates_from_pos(symbole_or(), self.mt5.TIMEFRAME_M5, 1, 500)
        maintenant = time.time()
        if maintenant - getattr(self, "_t_h1", 0) >= 600 or getattr(self, "_rates_h1", None) is None:
            self._t_h1 = maintenant
            self._rates_h1 = self.mt5.copy_rates_from_pos(symbole_or(), self.mt5.TIMEFRAME_H1, 1, 400)
        rates_h1 = self._rates_h1
        h1 = [] if rates_h1 is None else [(int(r["time"]) - decalage, float(r["open"]), float(r["high"]),
                                            float(r["low"]), float(r["close"])) for r in rates_h1]
        tendance = vi.tendance_h1(h1)
        self.tendance_h1 = tendance(time.time())
        # valeurs_initiales.py plus ancien qu'icebergs.py : on s'en passe
        definir = getattr(vi, "definir_dollar", None)
        if definir:
            try:
                definir(self._tendance_dollar(decalage))
            except Exception:
                definir(None)
        toutes = []
        for unite, rates in (("M1", rates1), ("M5", rates5), ("M15", rates15)):
            if rates is None or len(rates) < 40:
                continue
            bougies = [(int(r["time"]) - decalage, float(r["open"]), float(r["high"]),
                        float(r["low"]), float(r["close"])) for r in rates]
            # M5 / M15 : valeurs initiales + FVG, IFVG, BPR, OPR, recalcules
            # seulement a chaque nouvelle bougie (le calcul complet est plus long)
            if unite == "M1":
                toutes += vi.zones(bougies, unite, tendance)
            else:
                cache = self._vi_cache.get(unite)
                if not cache or cache[0] != bougies[-1][0]:
                    cache = (bougies[-1][0], vi.zones_toutes(bougies, unite, tendance))
                    self._vi_cache[unite] = cache
                toutes += cache[1]
            if unite != "M1":
                # bougies des autres unites pour le graphique (bouton M5 / M15 / H1)
                self.bougies_ut[unite] = [[t, round(o, 2), round(h, 2), round(b, 2), round(c, 2)]
                                          for t, o, h, b, c in bougies[-300:]]
        if h1:
            self.bougies_ut["H1"] = [[t, round(o, 2), round(h, 2), round(b, 2), round(c, 2)]
                                     for t, o, h, b, c in h1[-300:]]
        self.vi_actives = vi.actives(toutes, time.time())
        vi.enregistrer(toutes, self._vi_cles)
        try:
            self._proposer_valeurs_initiales(rates1, decalage, tendance(time.time()))
            self._proposer_scalps(rates1, tendance(time.time()))
        except Exception as exc:
            print(f"Valeur initiale non proposee : {exc!r}")
        try:
            self._proposer_bos(toutes, tendance(time.time()))
        except Exception as exc:
            print(f"BOS non propose : {exc!r}")

    def _proposer_bos(self, toutes, tendance):
        """Signal « BOS cassure » (bilan du 28/09, simule : +0,77 R en M15 et
        +0,55 R en M5 dans le sens de la tendance H1, sur 4 h) : quand la
        derniere bougie M5 ou M15 close casse la structure dans le sens de la
        tendance H1, entree au marche, stop derriere le dernier creux (ou
        sommet) + 0,50 $, objectif 2R, sortie au bout de 4 h. En exploration
        tant qu'il n'est pas dans trading_signaux."""
        if not self.marche_ouvert or tendance not in ("haussiere", "baissiere"):
            return
        pas = {"M5": 300, "M15": 900}
        for z in toutes:
            if z.type != "BOS cassure" or z.unite not in UNITES_SIGNAUX_ZONES or z.sens != tendance:
                continue
            # seulement la cassure de la bougie qui vient de se fermer
            if time.time() - (z.creee + pas[z.unite]) > pas[z.unite] + 90:
                continue
            cle = f"BOS|{z.unite}|{z.creee}"
            if cle in self._vi_proposees:
                continue
            self._vi_proposees.add(cle)
            achat = z.sens == "haussiere"
            if self._respiration_contraire(self.xau_mt5 or (z.haut if achat else z.bas), achat):
                print(f"   BOS {z.unite} ecarte : prix dans la respiration M15 contraire")
                continue
            sens = "achat" if achat else "vente"
            sl = round(z.bas - 0.5 if achat else z.haut + 0.5, 2)
            marche = dict(self.marche or {})
            if self.tendance:
                marche["tendance_fond"] = self.tendance["fond"]
                from gimaly.trading.respiration import accord_tendance
                marche["tendance_accord"] = accord_tendance(self.tendance, "acheteur" if achat else "vendeur")
            contexte = {"tp_r": 2, "duree_max_min": 240, "sl_max_pips": 250,
                        "tendance_h1": tendance, "tendance_h1_accord": "avec",
                        "structure": f"BOS {z.unite}",
                        # le niveau reellement casse (sommet / creux), pas la cloture
                        "niveau_casse": getattr(z, "niveau", 0) or (z.haut if achat else z.bas),
                        "unite_casse": z.unite}
            raison = (f"BOS cassure {z.unite} {z.sens}, cloture {z.haut if achat else z.bas}, "
                      f"stop derriere {z.bas if achat else z.haut}, tendance H1 {tendance}")
            from gimaly.trading.trading import proposer
            proposer(sens, sl=sl, genre="bos_cassure", raison=raison, marche=marche, contexte=contexte)
            print(f"   signal BOS propose au bot : {sens}, {raison}")

    def _tendance_dollar(self, decalage):
        """Tendance H1 du dollar (DXY si le courtier le propose, sinon EURUSD
        inverse), relue toutes les 10 min, pour mesurer au bilan si elle aide."""
        maintenant = time.time()
        if maintenant - getattr(self, "_t_dollar", 0) < 600 and getattr(self, "_fn_dollar", None):
            return self._fn_dollar
        self._t_dollar = maintenant
        from gimaly.trading.contexte_marche import SYMBOLES_DOLLAR
        from gimaly.trading import valeurs_initiales as vi
        symbole, inverse = None, False
        for s_ in SYMBOLES_DOLLAR:
            if self.mt5.symbol_info(s_) is not None:
                symbole = s_
                break
        if symbole is None and self.mt5.symbol_info("EURUSD") is not None:
            symbole, inverse = "EURUSD", True
        if symbole is None:
            self._fn_dollar = None
            return None
        self.mt5.symbol_select(symbole, True)
        rates = self.mt5.copy_rates_from_pos(symbole, self.mt5.TIMEFRAME_H1, 1, 400)
        if rates is None or len(rates) < 60:
            self._fn_dollar = None
            return None
        signe = -1.0 if inverse else 1.0      # EURUSD qui baisse = dollar qui monte
        h1 = [(int(r["time"]) - decalage, signe * float(r["open"]), signe * float(r["high"]),
               signe * float(r["low"]), signe * float(r["close"])) for r in rates]
        self._fn_dollar = vi.tendance_h1(h1)
        self.tendance_dollar = self._fn_dollar(maintenant)
        return self._fn_dollar

    def _respiration_contraire(self, prix, achat) -> bool:
        """Vrai si le prix est dans la zone de retracement (respiration, ~Fibo
        50-78,6 %) d'une impulsion M15 de sens CONTRAIRE au trade.
        01/10 : deux ventes prises a 4160-4162, en plein dans la respiration
        d'une impulsion M15 haussiere 4150 -> 4176 (zone 4160-4166) : c'est la
        ou les acheteurs reviennent, le prix est reparti a la hausse."""
        try:
            from gimaly.trading.respiration import evaluer
            dans, sens = evaluer(self.respiration_m15, prix, "acheteur" if achat else "vendeur")
        except Exception:
            return False
        return str(dans).startswith("dans") and "contre" in str(sens)

    def _proposer_scalps(self, rates1, tendance):
        """06/10 : mode SCALPING EN TEST. Ces signaux (genre « scalp_… ») ne sont
        JAMAIS trades ni publies : le bot les suit en fantomes (trades_refuses.csv,
        bilan --refuses) pour mesurer en direct ce qu'ils auraient donne."""
        try:
            if not self.marche_ouvert or rates1 is None or len(rates1) < 2:
                return
            from gimaly.trading.trading import proposer
            derniere, avant = rates1[-1], rates1[-2]
            vues = self.__dict__.setdefault("_scalp_derniere", {})
            prix = self.xau_mt5 or float(derniere["close"])
            # 1. zones VI : M5 contre la tendance H1, M15 quand la tendance H1 est mixte
            for z in self.vi_actives:
                if z.unite == "M5" and tendance in ("haussiere", "baissiere") and z.sens != tendance:
                    genre = "scalp_vi_m5"
                elif z.unite == "M15" and tendance == "mixte":
                    genre = "scalp_vi_mixte"
                else:
                    continue
                dedans = float(derniere["low"]) <= z.haut and float(derniere["high"]) >= z.bas
                deja = float(avant["low"]) <= z.haut and float(avant["high"]) >= z.bas
                cle = f"{genre}|{z.unite}|{z.debut}"
                if not dedans or deja or len(z.retours) > 1 or time.time() - vues.get(cle, 0) < 3600:
                    continue
                if (z.sens == "haussiere" and prix <= z.bas) or (z.sens == "baissiere" and prix >= z.haut):
                    continue
                vues[cle] = time.time()
                achat = z.sens == "haussiere"
                sl = round(z.bas - 0.5 if achat else z.haut + 0.5, 2)
                proposer("achat" if achat else "vente", sl=sl, genre=genre,
                         raison=(f"TEST {genre} : zone {z.unite} {z.sens} {z.bas}-{z.haut}, "
                                 f"tendance H1 {tendance}, retour n{len(z.retours)}"),
                         marche=dict(self.marche or {}),
                         contexte={"tp_r": 2, "duree_max_min": 240, "sl_max_pips": 250,
                                   "retour_n": len(z.retours), "tendance_h1": tendance,
                                   "zone": f"{z.bas}-{z.haut}"})
            # 2. rebond sur une bande de Keltner M1 : meche dehors, cloture dedans
            k = self.keltner
            if k:
                bas, haut = float(derniere["low"]), float(derniere["high"])
                cloture = float(derniere["close"])
                for achat, touche in ((True, bas <= k["bas"] < cloture),
                                      (False, haut >= k["haut"] > cloture)):
                    cle = f"scalp_keltner|{achat}"
                    if not touche or time.time() - vues.get(cle, 0) < 900:
                        continue
                    vues[cle] = time.time()
                    sl = round(bas - 0.3 if achat else haut + 0.3, 2)
                    proposer("achat" if achat else "vente", sl=sl, genre="scalp_keltner",
                             raison=(f"TEST scalp_keltner : rebond bande {'basse' if achat else 'haute'} "
                                     f"Keltner M1, tendance H1 {tendance}"),
                             marche=dict(self.marche or {}),
                             contexte={"tp_r": 1.5, "duree_max_min": 60, "sl_max_pips": 150,
                                       "tendance_h1": tendance, **self._contexte_scalp(achat)})
                    # 20/10 : variante a stop DEUX FOIS plus loin (objectif 1,5R du nouveau risque)
                    distance_large = abs(cloture - sl) * 2
                    sl_large = round(cloture - distance_large if achat else cloture + distance_large, 2)
                    proposer("achat" if achat else "vente", sl=sl_large, genre="scalp_keltner_large",
                             raison=(f"scalp_keltner_large : rebond bande {'basse' if achat else 'haute'} "
                                     f"Keltner M1, stop double, tendance H1 {tendance}"),
                             marche=dict(self.marche or {}),
                             contexte={"tp_r": 1.5, "duree_max_min": 60, "sl_max_pips": 400,
                                       "tendance_h1": tendance, **self._contexte_scalp(achat)})
        except Exception as exc:          # un test ne doit jamais gener le detecteur
            print(f"   scalps (test) : erreur ignoree {exc!r}")

    def _contexte_scalp(self, achat):
        """Carnet, gros ordres et tape au moment d'un signal scalp : ENREGISTREMENT SEUL (colonnes de
        trades_bot.csv), aucune decision n'en depend. Le desequilibre du carnet est calcule ICI a partir
        de la part des tailles au bid (50 % = equilibre), pour qu'il soit bien signe."""
        try:
            cote = "acheteur" if achat else "vendeur"
            ligne = dict(self.activite.pour_signal(cote, None))
            f = self.flux.instantane()
            part_bid = f.get("desequilibre")
            if part_bid is not None and not (isinstance(part_bid, float) and math.isnan(part_bid)):
                ecart = (float(part_bid) - 50.0) * (1 if achat else -1)
                ligne["carnet_desequilibre"] = ("dans son sens" if ecart >= 10
                                                else "contre" if ecart <= -10 else "equilibre")
            d5 = f.get("delta_5min")
            if d5 is not None and not (isinstance(d5, float) and math.isnan(d5)):
                ligne["delta_5min"] = round(float(d5))
            return ligne
        except Exception:
            return {}

    def _proposer_valeurs_initiales(self, rates1, decalage, tendance):
        """Signal « valeur initiale » (bilan du 28/09 : +0,57 R en M15 dans le sens
        de la tendance H1, simule) : quand la derniere bougie M1 close entre dans
        une zone M5 ou M15 qui va dans le sens de la tendance H1, on propose au
        bot un trade : entree au marche, stop de l'autre cote de la zone + 0,50 $,
        objectif 2R, sortie au bout de 4 h. En exploration tant qu'il n'est pas
        dans trading_signaux."""
        if not self.marche_ouvert or tendance not in ("haussiere", "baissiere") or rates1 is None or len(rates1) < 2:
            return
        derniere, avant = rates1[-1], rates1[-2]
        for z in self.vi_actives:
            if z.unite not in UNITES_SIGNAUX_ZONES:
                continue
            # 02/10 : la valeur initiale M15 CONTRE la tendance H1 est positive
            # dans les deux regimes (tendance et range) : proposee comme
            # « vi_contre » ; celle dans le sens de la tendance reste proposee
            # comme avant (le bot ne la prend que si elle est dans ses signaux)
            contre = z.sens != tendance
            dedans = float(derniere["low"]) <= z.haut and float(derniere["high"]) >= z.bas
            deja_dedans = float(avant["low"]) <= z.haut and float(avant["high"]) >= z.bas
            # une seule proposition par zone et par heure : le 29/09, la meme
            # zone etait reproposee a chaque bougie M1 qui y rentrait
            cle = f"{z.unite}|{z.debut}"
            if not dedans or deja_dedans or time.time() - self._vi_derniere.get(cle, 0) < 3600:
                continue
            # le prix ne doit pas etre deja de l'autre cote de la zone (stop depasse)
            prix = self.xau_mt5 or float(derniere["close"])
            if (z.sens == "haussiere" and prix <= z.bas) or (z.sens == "baissiere" and prix >= z.haut):
                continue
            if self._respiration_contraire(prix, z.sens == "haussiere"):
                self._vi_derniere[cle] = time.time()
                print(f"   valeur initiale {z.unite} ecartee : prix dans la respiration M15 contraire")
                continue
            self._vi_derniere[cle] = time.time()
            achat = z.sens == "haussiere"
            sens = "achat" if achat else "vente"
            sl = round(z.bas - 0.5 if achat else z.haut + 0.5, 2)
            retour = len(z.retours)
            # 05/10 : simule, valeur initiale M15 = +0,31 R au 1er retour, +0,15 R au 2e, ~0 ensuite
            # (retour = retours deja termines : 0 = 1er retour, 1 = 2e)
            if retour > 1:
                print(f'   valeur initiale {z.unite} ecartee : retour n{retour}, zone deja trop testee')
                continue
            marche = dict(self.marche or {})
            if self.tendance:
                marche["tendance_fond"] = self.tendance["fond"]
                from gimaly.trading.respiration import accord_tendance
                marche["tendance_accord"] = accord_tendance(self.tendance, "acheteur" if achat else "vendeur")
            contexte = {"valeur_initiale": f"{'contre' if contre else 'soutien'} {z.unite}", "tp_r": 2,
                        "duree_max_min": 240,
                        "sl_max_pips": 250, "retour_n": retour, "tendance_h1": tendance,
                        "tendance_h1_accord": "contre" if contre else "avec",
                        "zone": f"{z.bas}-{z.haut}", "impulsion_atr": z.impulsion_atr}
            raison = (f"valeur initiale {z.unite} {z.sens} {z.bas}-{z.haut}"
                      f"{' (contre la tendance)' if contre else ''}, tendance H1 {tendance}, "
                      f"retour n{retour}")
            from gimaly.trading.trading import proposer
            # 06/10 : 2e retour dont le 1er retour a DEJA touche son stop = -0,54 R par trade
            # (simule, 10 cas) : suivi en fantome au lieu d'etre trade
            genre_vi = "vi_contre" if contre else "valeur_initiale"
            try:
                if contre and retour >= 1 and z.retours[0][5][1] == "stop":
                    genre_vi = "scalp_vi_apres_echec"
                    print(f"   valeur initiale {z.unite} : 1er retour deja stoppe, suivi en fantome")
            except Exception:
                pass
            proposer(sens, sl=sl, genre=genre_vi,
                     raison=raison, marche=marche, contexte=contexte)
            print(f"   signal valeur initiale propose au bot : {sens}, {raison}")

    def _ajouter_valeur_initiale(self, ligne, prix_xau, cote):
        try:
            from gimaly.trading.valeurs_initiales import position
            ligne["valeur_initiale"] = position(prix_xau, cote, self.vi_actives) if self.vi_actives else ""
        except Exception:
            ligne["valeur_initiale"] = ""
        # tendance H1 et accord avec le signal (bilan du 28/09 : c'est ce qui separe
        # les valeurs initiales gagnantes des perdantes)
        t = getattr(self, "tendance_h1", "")
        ligne["tendance_h1"] = t
        ligne["tendance_h1_accord"] = ("" if not t else "mixte" if t == "mixte" else
                                       "avec" if (t == "haussiere") == (cote == "acheteur") else "contre")

    UNITES_AFFICHAGE = (("m3", "TIMEFRAME_M3", 500, False), ("m5", "TIMEFRAME_M5", 500, False),
                        ("m30", "TIMEFRAME_M30", 400, True))

    def _maj_respirations_affichage(self):
        """Respiration M3, M5 et M30 pour le panneau. Affichage seulement :
        elles n'entrent ni dans la note ni dans les filtres du bot."""
        from gimaly.trading.respiration import calculer as zone_respiration, PIVOT_N_M15
        for nom, unite, nombre, lent in self.UNITES_AFFICHAGE:
            try:
                rates = self.mt5.copy_rates_from_pos(symbole_or(), getattr(self.mt5, unite), 1, nombre)
                if rates is None or len(rates) <= 50:
                    continue
                b = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                     for r in rates]
                zone = zone_respiration(b, pivot_n=PIVOT_N_M15) if lent else zone_respiration(b)
                self.respirations_affichage[nom] = (
                    {k: (_r(v) if isinstance(v, float) else v) for k, v in zone.items()}
                    if zone else None)
            except Exception as e:
                print(f"Respiration {nom.upper()} non calculee : {e!r}")

    @property
    def marche_ouvert(self):
        return time.time() - self._tick_change_t < FERME_APRES_S

    def _noter_tick(self, tick):
        if tick is None or not tick.time:
            return
        if self._tick_mt5 is not None and tick.time != self._tick_mt5:
            self._tick_change_t = time.time()
        self._tick_mt5 = tick.time

    def _decalage_mt5(self, tick):
        """Ecart d'heure entre le serveur MT5 et le PC, arrondi a 30 min.
        Mesure seulement quand le marche vit : marche ferme, le dernier tick
        date de vendredi et donnerait un ecart de plusieurs jours."""
        if tick is not None and tick.time and self.marche_ouvert:
            d = round((tick.time - time.time()) / 1800) * 1800
            if d != self._decalage:
                self._decalage = d
                try:
                    DECALAGE.write_text(json.dumps({"s": d}), encoding="utf-8")
                except OSError:
                    pass
            return d
        if self._decalage is not None:
            return self._decalage
        return round((tick.time - time.time()) / 1800) * 1800 if tick is not None and tick.time else 0

    def _maj_bougies_graph(self, rates):
        """Les 480 dernieres bougies M1 (8 h), a l'heure du PC (MT5 donne l'heure de
        son serveur), pour le graphique du panneau."""
        tick = self.mt5.symbol_info_tick(symbole_or())
        self._noter_tick(tick)
        decalage = self._decalage_mt5(tick)
        self.bougies_graph = [[int(r["time"]) - decalage, round(float(r["open"]), 2),
                               round(float(r["high"]), 2), round(float(r["low"]), 2),
                               round(float(r["close"]), 2)] for r in rates[-480:]]

    def _maj_direct(self):
        """Prix MT5 et bougie M1 en cours, pour un graphique en temps reel."""
        if not self.mt5:
            return
        try:
            tick = self.mt5.symbol_info_tick(symbole_or())
            rates = self.mt5.copy_rates_from_pos(symbole_or(), self.mt5.TIMEFRAME_M1, 0, 2)
        except Exception:
            return
        if tick is None or not tick.bid:
            return
        self.xau_mt5 = round(float(tick.bid), 2)
        self._noter_tick(tick)
        if rates is None or not len(rates) or not self.bougies_graph:
            return
        decalage = self._decalage_mt5(tick)
        for r in rates:
            b = [int(r["time"]) - decalage, round(float(r["open"]), 2), round(float(r["high"]), 2),
                 round(float(r["low"]), 2), round(float(r["close"]), 2)]
            if b[0] == self.bougies_graph[-1][0]:
                self.bougies_graph[-1] = b
            elif b[0] > self.bougies_graph[-1][0]:
                self.bougies_graph.append(b)
        del self.bougies_graph[:-480]

    def _enregistrer_brut(self, m):
        if not ENREGISTRER_BRUT or m.get("type") not in ("book", "trade"):
            return
        jour = datetime.now().strftime("%Y%m%d")
        if jour != self._brut_jour:
            self._fermer_brut()
            DOSSIER_BRUT.mkdir(parents=True, exist_ok=True)
            self._brut = gzip.open(DOSSIER_BRUT / f"kmm_{jour}.jsonl.gz", "at", encoding="utf-8")
            self._brut_jour = jour
            for vieux in sorted(DOSSIER_BRUT.glob("kmm_*.jsonl.gz"))[:-JOURS_BRUT]:
                try:
                    vieux.unlink()
                except OSError:
                    pass
        self._brut.write(json.dumps(m, separators=(",", ":")) + "\n")

    def _fermer_brut(self):
        if self._brut:
            try:
                self._brut.close()
            except OSError:
                pass
            self._brut = None

    _verrou_travail = threading.RLock()     # un seul observateur par processus

    def message(self, m):
        # le fil de l'horloge (flux KMM coupe) et celui des messages ne doivent
        # pas travailler en meme temps sur les memes donnees
        with self._verrou_travail:
            self._dernier_message = time.time()
            self._message(m)
            if m.get("type") == "book":
                self._exporter_carnet(m)

    def _exporter_carnet(self, m):
        """Écrit les niveaux du carnet, convertis en prix XAUUSD, dans carnet.json
        (au plus 2 fois par seconde, écriture atomique). Ne doit JAMAIS gêner la
        détection : toute erreur est ignorée."""
        maintenant = time.time()
        if maintenant - getattr(self, "_t_carnet", 0.0) < CARNET_PERIODE_S:
            return
        self._t_carnet = maintenant
        try:
            ecart = self.ecart if not math.isnan(self.ecart) else 0.0

            def niveaux(cle):
                sortie = []
                for n in (m.get(cle) or [])[:CARNET_PROFONDEUR]:
                    try:
                        sortie.append([round(float(n[0]) - ecart, 2), round(float(n[1]), 1)])
                    except (TypeError, ValueError, IndexError):
                        continue
                return sortie

            contenu = {"t": round(maintenant, 3), "ecart": _r(self.ecart), "converti": not math.isnan(self.ecart),
                       "bids": niveaux("bids"), "asks": niveaux("asks")}
            temp = CARNET.with_suffix(".tmp")
            temp.write_text(json.dumps(contenu, separators=(",", ":")), encoding="utf-8")
            os.replace(temp, CARNET)
        except Exception:
            pass

    def tic_sans_flux(self):
        """30/09 : KMM a plante et, sans message, plus rien ne se mettait a
        jour cote MT5 (bougies, tendance H1, valeurs initiales, BOS) : le bot
        restait aveugle alors que ces signaux ne dependent pas de KMM. Appele
        chaque seconde par l'horloge quand aucun message n'est arrive depuis 5 s."""
        with self._verrou_travail:
            if time.time() - getattr(self, "_dernier_message", 0) < 5:
                return
            t = time.time()
            try:
                self._maj_mt5(t)
            except Exception as exc:
                print(f"horloge : mise a jour MT5 impossible ({exc!r})")
            if t - self._t_etat >= 60:
                self.pouls(t)
            elif t - self._t_direct >= DIRECT_S:
                self._t_direct = t
                try:
                    self._maj_direct()
                except Exception:
                    pass
                self._ecrire_etat()

    def _message(self, m):
        self.nb_msg += 1
        try:
            self._enregistrer_brut(m)
        except OSError:
            pass
        self.flux.message(m)
        self.det.message(m)
        try:
            self.activite.derniere = None
            self.activite.message(m)
            # marche ferme : les quelques echanges residuels ne vont pas sur la carte
            if self.activite.derniere and not math.isnan(self.ecart) and self.marche_ouvert:
                prix, taille, sens = self.activite.derniere
                self.carte.ajouter(time.time(), prix - self.ecart, taille, sens)
        except Exception:
            pass
        t = time.time()
        self._maj_mt5(t)
        if not math.isnan(self.det.mid):
            self._suivre(self.det.mid, t)
        if t - self._t_etat >= 60:
            self.pouls(t)
        elif t - self._t_direct >= DIRECT_S:
            self.carte.ecrire(t)
            # Avant, l'etat n'etait ecrit qu'une fois par minute : le panneau
            # (prix, flux KMM, graphique) avait jusqu'a 60 s de retard.
            self._t_direct = t
            self._maj_direct()
            self._ecrire_etat()

    def pouls(self, t=None, actif=True):
        """Ligne d'etat chaque minute + fichier icebergs_etat.json pour GIMALY."""
        t = t or time.time()
        par_min = round((self.nb_msg - self._nb_msg_prec) * 60 / max(t - self._t_etat, 1))
        self._nb_msg_prec, self._t_etat = self.nb_msg, t
        self._par_min = par_min
        if self._brut:
            try:
                self._brut.flush()
            except OSError:
                pass
        try:
            self.flux.sauvegarder(FICHIER_FLUX)
        except OSError as e:
            print(f"Sauvegarde du flux impossible : {e!r}")
        mid = self.det.mid
        xau = mid - self.ecart if not (math.isnan(mid) or math.isnan(self.ecart)) else math.nan
        if actif:
            morceaux = [f"{datetime.now():%H:%M} flux OK : {par_min} messages/min"]
            if not math.isnan(mid):
                morceaux.append(f"GC {mid:.1f}")
            if not math.isnan(self.ecart):
                morceaux.append(f"ecart GC-XAUUSD {self.ecart:.2f} $ (XAUUSD ~ {xau:.2f})")
            morceaux.append(f"{len(self.en_cours)} iceberg(s) en suivi, {self.nb} enregistre(s)")
            f = self.flux.instantane()
            if not math.isnan(f["vwap"]):
                morceaux.append(f"VWAP {f['vwap']:.1f} ({f['position_sigma']:+.1f} sigma) | "
                                f"CVD {f['cvd']:+.0f} (5 min {f['delta_5min']:+.0f})")
            print(" | ".join(morceaux))
        self._ecrire_etat(actif, t)

    def _ecrire_etat(self, actif=True, t=None):
        """Fichier lu par GIMALY (HUD et telephone). Ecrit chaque minute et a chaque iceberg."""
        t = t or time.time()
        mid = self.det.mid
        xau = mid - self.ecart if not (math.isnan(mid) or math.isnan(self.ecart)) else math.nan
        etat = {
            "actif": actif, "maj": datetime.now().strftime("%d/%m/%Y %H:%M:%S"), "maj_ts": t,
            "sans_kmm": bool(getattr(self, "sans_kmm", False)),
            "messages_min": getattr(self, "_par_min", 0), "gc": _r(mid), "xauusd": _r(xau), "ecart": _r(self.ecart),
            "en_suivi": len(self.en_cours), "enregistres": self.nb, "reglages": REGLAGES,
            "derniers": list(self.derniers)[::-1],
            "flux": self._flux_pour_affichage(),
            "cycles": list(self.derniers_cycles)[::-1], "cycles_enregistres": self.nb_cycles,
            "balayages": list(self.derniers_balayages)[::-1], "balayages_enregistres": self.nb_balayages,
            "marche": self.marche,
            "niveaux_xau": self._niveaux_marche(),
            "tendance": self.tendance,
            "respiration": ({k: (_r(v) if isinstance(v, float) else v) for k, v in self.respiration.items()}
                            if self.respiration else None),
            "keltner": self._keltner_affichage(self.keltner),
            "respiration_m15": ({k: (_r(v) if isinstance(v, float) else v)
                                 for k, v in self.respiration_m15.items()} if self.respiration_m15 else None),
            "keltner_m15": self._keltner_affichage(self.keltner_m15),
            **{f"respiration_{nom}": zone for nom, zone in self.respirations_affichage.items()},
            "bougies": self.bougies_graph,
            "bougies_ut": self.bougies_ut,
            "tendance_h1": getattr(self, "tendance_h1", ""),
            "valeurs_initiales": [{"unite": z.unite, "sens": z.sens, "bas": z.bas, "haut": z.haut,
                                   "debut": z.debut} for z in self.vi_actives],
            "xau_mt5": self.xau_mt5,
        }
        # Ecriture dans un fichier temporaire puis remplacement : le panneau lit
        # chaque seconde et ne doit jamais tomber sur un fichier a moitie ecrit.
        temp = ETAT.with_suffix(".tmp")
        try:
            temp.write_text(json.dumps(etat, ensure_ascii=False), encoding="utf-8")
            os.replace(temp, ETAT)
        except OSError:
            pass          # fichier ouvert au meme moment par le panneau : prochain passage

    # -- nouvel iceberg
    def nouvel_iceberg(self, niv, duree_s):
        if not self.marche_ouvert:
            return                        # marche ferme : flux residuel, pas un signal
        maintenant_s = time.time()
        for o in self.en_cours:
            if o.genre != "iceberg" or o.cote != niv.cote:
                continue
            if abs(o.prix - niv.prix) < 1e-9:
                return  # deja suivi
            if (maintenant_s - o.dernier_t <= EVENEMENT_S
                    and abs(niv.prix - o.dernier_prix) < EVENEMENT_DOLLARS):
                self._renforcer(o, niv)
                return
        self._icebergs_recents.append((maintenant_s, niv.cote, niv.prix))
        prix_xau = niv.prix - self.ecart if not math.isnan(self.ecart) else math.nan
        liq = None
        if not math.isnan(prix_xau) and self.niveaux_liq:
            liq = min(self.niveaux_liq, key=lambda n: abs(n.prix - prix_xau))
        maintenant = datetime.now()
        ligne = {
            "date": maintenant.strftime("%d/%m/%Y"), "heure": maintenant.strftime("%H:%M:%S"),
            "cote": niv.cote, "prix_gc": niv.prix, "prix_xau": _r(prix_xau), "ecart_gc_xau": _r(self.ecart),
            "volume": niv.volume, "affiche_max": niv.affiche_max, "recharges": niv.recharges,
            "duree_niveau_s": round(duree_s, 1), "atr_m1": _r(self.atr),
            "liq_cote": liq.cote if liq else "", "liq_prix": _r(liq.prix) if liq else "",
            "liq_distance": _r(abs(liq.prix - prix_xau)) if liq else "",
        }
        ctx = self.flux.contexte(niv.prix, niv.cote)
        ligne.update({k: (_r(v) if isinstance(v, float) else v) for k, v in ctx.items()})
        from gimaly.trading.respiration import evaluer
        ligne["respiration"], ligne["sens_tendance"] = evaluer(self.respiration, prix_xau, niv.cote)
        ligne["respiration_m15"], ligne["sens_tendance_m15"] = evaluer(self.respiration_m15, prix_xau, niv.cote)
        ctx["respiration"] = ligne["respiration"]
        ctx["respiration_m15"] = ligne["respiration_m15"]
        self._ajouter_keltner(ligne, prix_xau, niv.cote)
        self._ajouter_carnet(ligne, niv.cote)
        self._ajouter_valeur_initiale(ligne, prix_xau, niv.cote)
        self._ajouter_marche(ligne, niv.cote)
        self._ajouter_tendance(ligne, niv.cote)
        ctx["keltner_extreme"] = ligne["keltner_extreme"]
        ctx["keltner_extreme_m15"] = ligne["keltner_extreme_m15"]
        obs = Observation(niv.cote, niv.prix, time.time(), self.det.mid, ligne)
        obs.dernier_t, obs.dernier_prix, obs.volume_total = time.time(), niv.prix, niv.volume
        self.en_cours.append(obs)
        self.derniers.append({"date": ligne["date"], "ts": round(time.time()), "bot": "",
                              "heure": ligne["heure"], "cote": niv.cote, "prix_gc": niv.prix,
                              "prix_xau": ligne["prix_xau"], "volume": niv.volume,
                              "recharges": niv.recharges, "statut": "en suivi", "mouv_15min": "",
                              "liquidite": (f"{liq.cote} {liq.prix:.2f} a {abs(liq.prix - prix_xau):.2f} $"
                                            if liq else ""),
                              "contexte": _resume_contexte(ctx)})
        self._ecrire_etat()
        _bip()
        xau = f" (~ XAUUSD {prix_xau:.2f})" if not math.isnan(prix_xau) else ""
        info_liq = f" | liquidite {liq.cote} {liq.prix:.2f} a {abs(liq.prix - prix_xau):.2f} $" if liq else ""
        print(f"{ligne['heure']}  ICEBERG {niv.cote.upper():<8} GC {niv.prix:.1f}{xau}  "
              f"{niv.volume:.0f} contrats absorbes dont {niv.cache:.0f} caches, {niv.recharges} recharges{info_liq}")

    UNITES = (("M1", "TIMEFRAME_M1", 600, 10), ("M5", "TIMEFRAME_M5", 400, 8),
              ("M15", "TIMEFRAME_M15", 400, 5), ("H1", "TIMEFRAME_H1", 300, 5),
              ("H4", "TIMEFRAME_H4", 300, 5))

    def _maj_tendances(self, bougies_m1):
        """Tendance sur M1, M5, M15, H1 et H4 (structure + EMA 50)."""
        from gimaly.trading.respiration import tendance_unite, tendance_globale
        unites = {}
        for nom, attribut, nb, pivot in self.UNITES:
            try:
                if nom == "M1":
                    b = bougies_m1[-nb:]
                else:
                    rates = self.mt5.copy_rates_from_pos(
                        symbole_or(), getattr(self.mt5, attribut), 1, nb)
                    if rates is None:
                        continue
                    b = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                         for r in rates]
                unites[nom] = tendance_unite(b, pivot_n=pivot)
            except Exception as e:
                print(f"Tendance {nom} non calculee : {e!r}")
        self.tendances = unites
        self.tendance = tendance_globale(unites)

    def _ajouter_tendance(self, ligne, cote):
        from gimaly.trading.respiration import accord_tendance
        t = self.tendance
        ligne.update({
            "tendance_score": t["score"] if t else "",
            "tendance_fond": t["fond"] if t else "",
            "tendance_accord": accord_tendance(t, cote),
            "tendance_detail": " ".join(f"{k}:{v}" for k, v in t["detail"].items()) if t else "",
        })

    def _verifier_balayage(self, bougies=None):
        """Verifie plus souvent qu'une fois par minute : un creux en V se
        retourne en quelques secondes, pas a la fermeture de la bougie."""
        bougies = bougies if bougies is not None else getattr(self, "_bougies_m1", None)
        if not bougies:
            return
        from gimaly.trading.balayage import detecter
        prix = self.det.mid - self.ecart if not (math.isnan(self.det.mid)
                                                 or math.isnan(self.ecart)) else None
        sig = detecter(bougies, self.atr, self.flux.instantane()["delta_5min"],
                       self.niveaux_liq, self.keltner, prix_actuel=prix)
        if not sig:
            return
        t = time.time()
        if t - self._dernier_balayage.get(sig["sens"], 0) < BALAYAGE_PAUSE_S:
            return
        self._dernier_balayage[sig["sens"]] = t
        self.nouveau_balayage(sig)

    def nouveau_balayage(self, sig):
        """Balayage de liquidite suivi d'une reprise (observation, sans annonce vocale)."""
        if not self.marche_ouvert:
            return                        # bougies figees du vendredi : pas un balayage
        maintenant = datetime.now()
        cote = "acheteur" if sig["sens"] == "achat" else "vendeur"
        prix_xau = sig["prix"]
        prix_gc = prix_xau + self.ecart if not math.isnan(self.ecart) else prix_xau
        from gimaly.trading.respiration import evaluer, evaluer_keltner
        ctx = self.flux.contexte(prix_gc, cote)
        resp, sens_tend = evaluer(self.respiration, prix_xau, cote)
        pos, zone, extreme = evaluer_keltner(self.keltner, prix_xau, cote)
        ligne = {
            "date": maintenant.strftime("%d/%m/%Y"), "heure": maintenant.strftime("%H:%M:%S"),
            "sens": sig["sens"], "prix_gc": _r(prix_gc), "prix_xau": _r(prix_xau),
            "niveau": sig["niveau"], "extreme": sig["extreme"], "profondeur": sig["profondeur"],
            "delai_reprise_min": sig["delai_reprise_min"], "liquidite_cassee": sig["liquidite_cassee"],
            "keltner_casse": sig["keltner_casse"], "delta_5min": _r(sig["delta_5min"]),
            "vwap_sigma": _r(ctx["vwap_sigma"]), "cote_vwap": ctx["cote_vwap"],
            "zone_valeur": ctx["zone_valeur"], "respiration": resp, "sens_tendance": sens_tend,
            "keltner_position": _r(pos), "keltner_zone": zone, "keltner_extreme": extreme,
        }
        self._ajouter_carnet(ligne, cote)
        self._ajouter_valeur_initiale(ligne, prix_xau, cote)
        self._ajouter_marche(ligne, cote)
        self._ajouter_tendance(ligne, cote)
        reference = self.det.mid if not math.isnan(self.det.mid) else prix_gc
        self.en_cours.append(Observation(cote, prix_gc, time.time(), reference, ligne,
                                         genre="balayage"))
        self.derniers_balayages.append({"date": ligne["date"], "ts": round(time.time()), "bot": "",
                                        "heure": ligne["heure"], "sens": sig["sens"],
                                        "prix_xau": _r(prix_xau), "niveau": sig["niveau"],
                                        "profondeur": sig["profondeur"],
                                        "liquidite": sig["liquidite_cassee"],
                                        "keltner": sig["keltner_casse"], "mouv_15min": ""})
        self._ecrire_etat()
        print(f"{ligne['heure']}  BALAYAGE {sig['sens'].upper()} XAUUSD {prix_xau:.2f} | niveau "
              f"{sig['niveau']} balaye de {sig['profondeur']:.2f} $, reprise en "
              f"{sig['delai_reprise_min']} min | liquidite {sig['liquidite_cassee']}, "
              f"keltner {sig['keltner_casse']}")

    def _enregistrer_balayage(self, o):
        l = dict(o.ligne)
        l.update(_mouvements(o))
        l.update(_lignes_test(o))
        _preparer_fichier(FICHIER_BALAYAGES, COLONNES_BALAYAGES)
        with open(FICHIER_BALAYAGES, "a", newline="", encoding="utf-8-sig") as f:
            csv.DictWriter(f, fieldnames=COLONNES_BALAYAGES, delimiter=";").writerow(l)
        self.nb_balayages += 1
        for d in self.derniers_balayages:
            if d["heure"] == l["heure"]:
                d["mouv_15min"] = l["mouv_15min"]
        self._ecrire_etat()
        print(f"   bilan balayage {l['sens']} {l['prix_xau']} ({l['heure']}) : 15 min "
              f"{l['mouv_15min']:+} $, 60 min {l['mouv_60min']:+} $, max favorable {o.max_fav:+.2f}")

    def _ajouter_carnet(self, ligne, cote):
        try:
            desequilibre = self.flux.instantane().get("desequilibre")
            ligne.update(self.activite.pour_signal(cote, desequilibre))
        except Exception as e:
            print(f"Activite du carnet non enregistree : {e!r}")

    def _ajouter_marche(self, ligne, cote):
        from gimaly.trading.contexte_marche import dollar_contre_or
        m = self.marche or {}
        favorable = ""
        if m.get("dollar"):
            favorable = dollar_contre_or({"sens": m["dollar"]}, cote)
        ligne.update({"session": m.get("session", ""), "volatilite": m.get("volatilite", ""),
                      "dollar": m.get("dollar", ""), "dollar_favorable": favorable,
                      "annonce_proche": m.get("annonce_proche", "")})

    def _ajouter_keltner(self, ligne, prix_xau, cote):
        from gimaly.trading.respiration import evaluer_keltner
        pos, zone, extreme = evaluer_keltner(self.keltner, prix_xau, cote)
        ligne.update({"keltner_position": _r(pos), "keltner_zone": zone, "keltner_extreme": extreme})
        pos, zone, extreme = evaluer_keltner(self.keltner_m15, prix_xau, cote)
        ligne.update({"keltner_position_m15": _r(pos), "keltner_zone_m15": zone,
                      "keltner_extreme_m15": extreme})

    def _renforcer(self, o, niv):
        """Nouvel iceberg du meme evenement : on l'ajoute au premier, sans
        nouvelle observation ni nouvelle annonce."""
        o.renforcements += 1
        o.volume_total += niv.volume
        o.dernier_t, o.dernier_prix = time.time(), niv.prix
        self._icebergs_recents.append((time.time(), niv.cote, niv.prix))
        for d in self.derniers:
            if d["heure"] == o.ligne["heure"] and d["prix_gc"] == o.prix:
                d["volume"] = o.volume_total
                d["renforcements"] = o.renforcements
        self._ecrire_etat()
        prix_xau = niv.prix - self.ecart if not math.isnan(self.ecart) else math.nan
        xau = f" (~ XAUUSD {prix_xau:.2f})" if not math.isnan(prix_xau) else ""
        print(f"{datetime.now():%H:%M:%S}  renforcement de l'iceberg {o.cote} de {o.ligne['heure']} : "
              f"GC {niv.prix:.1f}{xau}, {niv.volume:.0f} contrats (total {o.volume_total:.0f}, "
              f"{o.renforcements} renforcement(s))")

    def _proposer_au_bot(self, o):
        """Reaction rapide sur un signal retenu : on le propose au bot, qui
        decidera (compte demo, session, annonce, limites du jour...).

        Regle retenue d'apres les bilans : les balayages de liquidite, et les
        icebergs qui defendent un extreme du canal de Keltner M1. Les autres
        n'ont pas montre d'avantage. Depuis le 25/09 : seulement les reactions
        entre 1 et 15 min (icebergs) ou 1 et 5 min (balayages)."""
        if o.reaction_dt is None or o.genre not in ("iceberg", "balayage"):
            return
        # Tous les signaux sont proposes, avec la liste des filtres qu'ils ratent.
        # Le bot ne prend les "hors filtre" qu'en mode exploration.
        ligne = o.ligne
        ecarts = []
        if o.reaction_dt < REACTION_BOT_MIN:
            ecarts.append("reaction trop rapide")
        elif o.reaction_dt > REACTION_BOT_MAX.get(o.genre, 0):
            ecarts.append("reaction trop lente")
        if o.genre == "iceberg" and ligne.get("keltner_extreme") != "oui":
            ecarts.append("pas sur extreme Keltner M1")
        sens = "achat" if o.cote == "acheteur" else "vente"
        sl = None
        extreme = ligne.get("extreme")
        if o.genre == "balayage" and extreme not in ("", None):
            try:
                extreme = float(extreme)
                sl = extreme - 0.3 if sens == "achat" else extreme + 0.3
            except (TypeError, ValueError):
                sl = None
        raison = f"{o.genre} {o.cote} {ligne.get('prix_xau', '')} · {ligne.get('contexte', '')}"
        marche = dict(self.marche or {})
        if self.tendance:
            marche["tendance_fond"] = self.tendance["fond"]
            from gimaly.trading.respiration import accord_tendance
            marche["tendance_accord"] = accord_tendance(self.tendance, o.cote)
        try:
            from gimaly.trading.trading import proposer
            contexte = {k: v for k, v in ligne.items() if v not in ("", None)}
            contexte["reaction_s"] = o.reaction_dt
            proposer(sens, sl=sl, genre=o.genre, raison=raison[:200], marche=marche,
                     contexte=contexte, ecarts=ecarts)
            if ecarts:
                print(f"   signal hors filtre propose au bot : {sens} ({o.genre}), {', '.join(ecarts)}")
                self._statut_bot(o, f"hors filtre : {', '.join(ecarts)} "
                                    f"(réaction en {o.reaction_dt} s) — pris seulement en exploration")
            else:
                print(f"   signal propose au bot : {sens} ({o.genre}), reaction en {o.reaction_dt} s")
                self._statut_bot(o, f"proposé au bot (réaction en {o.reaction_dt} s)")
        except Exception as exc:
            print(f"   signal non propose : {exc!r}")

    def _statut_bot(self, o, statut):
        """Indique sur le graphique si le signal a ete propose au bot ou ecarte."""
        liste = self.derniers if o.genre == "iceberg" else self.derniers_balayages
        for d in liste:
            if d.get("heure") == o.ligne.get("heure") and (
                    d.get("prix_gc") == o.prix or d.get("prix_xau") == o.ligne.get("prix_xau")):
                d["bot"] = statut
        self._ecrire_etat()

    # -- suivi 15 minutes
    def _suivre(self, mid, t):
        restants = []
        for o in self.en_cours:
            sens = -1 if o.cote == "vendeur" else 1
            mouv = (mid - o.prix_ref) * sens
            o.max_fav = max(o.max_fav, mouv)
            o.max_contre = min(o.max_contre, mouv)
            dt = t - o.t0
            if o.genre == "iceberg" and o.casse_apres is None and (
                    (o.cote == "vendeur" and mid > o.prix + CASSE_MARGE) or
                    (o.cote == "acheteur" and mid < o.prix - CASSE_MARGE)):
                o.casse_apres = round(dt)
            if o.reaction_dt is None:
                if mouv >= REACTION:
                    o.reaction_dt, o.reaction_mouv = round(dt), mouv
                    self._proposer_au_bot(o)
            else:
                depuis = mouv - o.reaction_mouv          # gain depuis l'entree sur reaction
                o.apres_fav = max(o.apres_fav, depuis)
                o.apres_contre = min(o.apres_contre, depuis)
                for taille in SL_VARIANTES:
                    if o.variantes.get(taille):
                        continue
                    if depuis <= -taille:
                        o.variantes[taille] = "stop"
                    elif depuis >= 2 * taille:
                        o.variantes[taille] = "2R"
                if o.premier == "":
                    if depuis <= -SL_TEST:
                        o.premier = "stop"
                    elif depuis >= 2 * SL_TEST:
                        o.premier = "2R"
                elif o.premier == "2R" and depuis >= 3 * SL_TEST:
                    o.trois_r = True
                if o.etat_test == "" and depuis <= -SL_TEST:
                    o.etat_test = "stoppe"
                elif o.etat_test == "" and depuis >= BE_TEST:
                    o.etat_test = "point mort atteint"
                elif o.etat_test == "point mort atteint" and depuis <= 0:
                    o.etat_test = "sorti au point mort"
            if o.fav15 is None and dt >= 900:
                o.fav15, o.contre15, o.apres_fav15 = o.max_fav, o.max_contre, o.apres_fav
            for h in HORIZONS:
                if h not in o.suivis and dt >= h:
                    o.suivis[h] = round(mouv, 2)
            if dt >= HORIZONS[-1]:
                self._enregistrer(o)
            else:
                restants.append(o)
        self.en_cours = restants

    # -- cycle des 5 bougies (observation silencieuse, sans bip)
    def nouveau_cycle(self, sig):
        if not self.marche_ouvert:
            return
        maintenant = datetime.now()
        prix_xau = sig["prix"] - self.ecart if not math.isnan(self.ecart) else math.nan
        cote = "acheteur" if sig["sens"] == "achat" else "vendeur"    # sens favorable du suivi
        recents = [(t, c, p) for t, c, p in self._icebergs_recents if time.time() - t <= 300]
        if recents:
            t, c, p = recents[-1]
            iceberg = f"{c} {p:.1f} il y a {int((time.time() - t) // 60)} min"
            aligne = "oui" if c == cote else "non"
        else:
            iceberg, aligne = "", ""
        ctx = self.flux.contexte(sig["prix"], cote)
        ligne = {
            "date": maintenant.strftime("%d/%m/%Y"), "heure": maintenant.strftime("%H:%M:%S"),
            "sens": sig["sens"], "scenario": sig["scenario"], "prix_gc": sig["prix"],
            "prix_xau": _r(prix_xau), "couleur_serie": sig["couleur_serie"],
            "divergentes": sig["divergentes"], "delta_serie": _r(sig["delta_serie"]),
            "delta_saine": _r(sig["delta_saine"]), "vwap_sigma": _r(ctx["vwap_sigma"]),
            "cote_vwap": ctx["cote_vwap"], "zone_valeur": ctx["zone_valeur"],
            "iceberg_recent": iceberg, "iceberg_aligne": aligne,
        }
        from gimaly.trading.respiration import evaluer
        ligne["respiration"], ligne["sens_tendance"] = evaluer(self.respiration, prix_xau, cote)
        ligne["respiration_m15"], ligne["sens_tendance_m15"] = evaluer(self.respiration_m15, prix_xau, cote)
        self._ajouter_keltner(ligne, prix_xau, cote)
        self._ajouter_marche(ligne, cote)
        self._ajouter_tendance(ligne, cote)
        reference = self.det.mid if not math.isnan(self.det.mid) else sig["prix"]
        self.en_cours.append(Observation(cote, sig["prix"], time.time(), reference, ligne,
                                         genre="cycle"))
        self.derniers_cycles.append({"heure": ligne["heure"], "sens": sig["sens"],
                                     "scenario": sig["scenario"], "prix_xau": ligne["prix_xau"],
                                     "prix_gc": sig["prix"], "serie": f"{sig['divergentes']} "
                                     f"{sig['couleur_serie']}s delta {sig['delta_serie']:+.0f}",
                                     "saine": f"{sig['delta_saine']:+.0f}", "iceberg": iceberg,
                                     "mouv_15min": ""})
        self._ecrire_etat()
        xau = f" (~ XAUUSD {prix_xau:.2f})" if not math.isnan(prix_xau) else ""
        print(f"{ligne['heure']}  CYCLE {sig['sens'].upper()} ({sig['scenario']}) GC {sig['prix']:.1f}{xau}"
              f" | {sig['divergentes']} bougies {sig['couleur_serie']}s a delta {sig['delta_serie']:+.0f},"
              f" bougie saine delta {sig['delta_saine']:+.0f}" + (f" | iceberg {iceberg}" if iceberg else ""))

    def _enregistrer_cycle(self, o):
        l = dict(o.ligne)
        l.update(_mouvements(o))
        l.update(_lignes_test(o))
        _preparer_fichier(FICHIER_CYCLES, COLONNES_CYCLES)
        with open(FICHIER_CYCLES, "a", newline="", encoding="utf-8-sig") as f:
            csv.DictWriter(f, fieldnames=COLONNES_CYCLES, delimiter=";").writerow(l)
        self.nb_cycles += 1
        for d in self.derniers_cycles:
            if d["heure"] == l["heure"] and d["prix_gc"] == o.prix:
                d["mouv_15min"] = l["mouv_15min"]
        self._ecrire_etat()
        print(f"   bilan cycle {l['sens']} {o.prix:.1f} ({l['heure']}) : 15 min {l['mouv_15min']:+} $, "
              f"max favorable {o.max_fav:+.2f}, max contraire {o.max_contre:+.2f}")

    def _enregistrer(self, o):
        if o.genre == "cycle":
            self._enregistrer_cycle(o)
            return
        if o.genre == "balayage":
            self._enregistrer_balayage(o)
            return
        l = dict(o.ligne)
        l.update({**_mouvements(o),
                  "renforcements": o.renforcements, "volume_total": o.volume_total,
                  **_lignes_test(o),
                  "casse": "oui" if o.casse_apres is not None else "non",
                  "casse_apres_s": o.casse_apres if o.casse_apres is not None else ""})
        with open(FICHIER, "a", newline="", encoding="utf-8-sig") as f:
            csv.DictWriter(f, fieldnames=COLONNES, delimiter=";").writerow(l)
        self.nb += 1
        for d in self.derniers:
            if d["heure"] == l["heure"] and d["prix_gc"] == o.prix:
                d["statut"] = "casse" if o.casse_apres is not None else "tenu"
                d["mouv_15min"] = l["mouv_15min"]
        self._ecrire_etat()
        etat = f"CASSE apres {o.casse_apres} s" if o.casse_apres is not None else "a TENU"
        print(f"   bilan iceberg {o.cote} {o.prix:.1f} ({l['heure']}) : {etat}, "
              f"15 min {l['mouv_15min']:+} $, max favorable {o.max_fav:+.2f}, max contraire {o.max_contre:+.2f}")

    def _niveaux_marche(self):
        """Les niveaux du marche en prix XAUUSD, pour que le bot y place ses TP :
        liquidites LuxAlgo, VWAP, POC, bords de la zone de valeur, bandes de
        Keltner M1 et M15, bornes de la zone de respiration."""
        niveaux = []

        def ajouter(prix, nom):
            if prix is None or (isinstance(prix, float) and math.isnan(prix)):
                return
            niveaux.append({"prix": round(float(prix), 2), "nom": nom})

        for n in self.niveaux_liq:
            if not n.casse:
                ajouter(n.prix, f"liquidite {n.cote}")
        f = self.flux.instantane()
        ecart = self.ecart if not math.isnan(self.ecart) else 0.0
        for cle, nom in (("vwap", "VWAP"), ("poc", "POC"),
                         ("vah", "haut zone de valeur"), ("val", "bas zone de valeur")):
            valeur = f.get(cle)
            if valeur is not None and not math.isnan(valeur):
                ajouter(valeur - ecart, nom)
        for canal, nom in ((self.keltner, "Keltner M1"), (self.keltner_m15, "Keltner M15")):
            if canal:
                ajouter(canal["haut"], f"{nom} haut")
                ajouter(canal["bas"], f"{nom} bas")
                ajouter(canal["milieu"], f"{nom} milieu")
        for zone, nom in ((self.respiration, "respiration M1"), (self.respiration_m15, "respiration M15")):
            if zone and zone.get("valide"):
                ajouter(zone["extreme"], f"{nom} extreme")
                ajouter(zone["zone_haut"], f"{nom} haut de zone")
                ajouter(zone["zone_bas"], f"{nom} bas de zone")
        return niveaux

    def _keltner_affichage(self, canal):
        if not canal:
            return None
        from gimaly.trading.respiration import position_keltner, zone_keltner
        mid = self.det.mid
        prix = mid - self.ecart if not (math.isnan(mid) or math.isnan(self.ecart)) else math.nan
        pos = position_keltner(canal, prix)
        return {"bas": _r(canal["bas"]), "milieu": _r(canal["milieu"]),
                "haut": _r(canal["haut"]), "position": _r(pos), "zone": zone_keltner(pos)}

    def _flux_pour_affichage(self):
        """Flux d'ordres avec les niveaux convertis en prix XAUUSD."""
        f = self.flux.instantane()
        xau = (lambda v: _r(v - self.ecart)) if not math.isnan(self.ecart) else (lambda v: "")
        mur_a, mur_v = f["mur_acheteur"], f["mur_vendeur"]
        try:
            _p60 = self.flux.profil_fenetre(60)[0]
        except Exception:
            _p60 = math.nan
        poc60_xau = xau(_p60) if not math.isnan(_p60) else ""
        return {
            "cvd": _r(f["cvd"]), "delta_1min": _r(f["delta_1min"]), "delta_5min": _r(f["delta_5min"]),
            "pression_1min": _r(f["pression_1min"]), "pression_5min": _r(f["pression_5min"]),
            "pression_session": _r(f["pression_session"]),
            "vwap": _r(f["vwap"]), "vwap_xau": xau(f["vwap"]) if not math.isnan(f["vwap"]) else "",
            "position_sigma": _r(f["position_sigma"]),
            "poc": _r(f["poc"]), "poc_xau": xau(f["poc"]) if not math.isnan(f["poc"]) else "",
            "vah": _r(f["vah"]), "val": _r(f["val"]),
            "poc60_xau": poc60_xau,      # affichage seul (le bot ne lit pas "flux")
            "desequilibre": _r(f["desequilibre"]), "volume": _r(f["volume"]),
            "mur_acheteur": f"{mur_a[1]:.0f} a {mur_a[0]:.1f}" if mur_a else "",
            "mur_vendeur": f"{mur_v[1]:.0f} a {mur_v[0]:.1f}" if mur_v else "",
            "carnet_60s": self.activite.resume(),
        }

    def fermer(self):
        self._fermer_brut()
        self.pouls(actif=False)
        if self.mt5:
            self.mt5.shutdown()


def _mouvements(o):
    """Mouvements aux differents horizons. Les colonnes 'max' sans suffixe gardent
    leur sens d'origine : le maximum atteint dans les 15 premieres minutes."""
    fav15 = o.fav15 if o.fav15 is not None else o.max_fav
    contre15 = o.contre15 if o.contre15 is not None else o.max_contre
    return {"mouv_1min": o.suivis.get(60, ""), "mouv_5min": o.suivis.get(300, ""),
            "mouv_15min": o.suivis.get(900, ""), "mouv_30min": o.suivis.get(1800, ""),
            "mouv_60min": o.suivis.get(3600, ""),
            "max_favorable": round(fav15, 2), "max_contraire": round(contre15, 2),
            "max_favorable_60": round(o.max_fav, 2), "max_contraire_60": round(o.max_contre, 2)}


def _lignes_test(o):
    """Resultat de la methode 'entree sur reaction' pour une observation."""
    if o.reaction_dt is None:
        return {"reaction": "non", "delai_reaction_s": "", "recul_apres_reaction": "",
                "gain_apres_reaction": "", "R_max": "", "R_max_60": "",
                "resultat_test": "pas de reaction", "premier_evenement": "", "atteint_3R": "",
                **{f"test_sl{int(t * 10)}": "" for t in SL_VARIANTES}}
    etat = o.etat_test or ("en cours" if o.apres_fav < BE_TEST else "point mort atteint")
    fav15 = o.apres_fav15 if o.apres_fav15 is not None else o.apres_fav
    return {"reaction": "oui", "delai_reaction_s": o.reaction_dt,
            "recul_apres_reaction": round(o.apres_contre, 2),
            "gain_apres_reaction": round(o.apres_fav, 2),
            "R_max": round(fav15 / SL_TEST, 2),
            "R_max_60": round(o.apres_fav / SL_TEST, 2), "resultat_test": etat,
            "premier_evenement": o.premier or "ni l'un ni l'autre",
            "atteint_3R": "oui" if o.trois_r else "non",
            **{f"test_sl{int(t * 10)}": (e or "aucun") for t, e in o.variantes.items()}}


def _r(x):
    return "" if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, 2)


def _resume_contexte(ctx):
    morceaux = []
    if ctx.get("cote_vwap"):
        morceaux.append(f"{'sur' if ctx['cote_vwap'] == 'dessus' else 'sous'} VWAP "
                        f"{ctx['vwap_sigma']:+.1f}σ")
    if ctx.get("zone_valeur"):
        morceaux.append(ctx["zone_valeur"])
    if not math.isnan(ctx.get("delta_5min", math.nan)):
        morceaux.append(f"delta 5 min {ctx['delta_5min']:+.0f}")
    if ctx.get("mur") == "oui":
        morceaux.append("mur visible")
    if ctx.get("respiration") == "oui":
        morceaux.append("zone de respiration M1")
    if ctx.get("respiration_m15") == "oui":
        morceaux.append("zone de respiration M15")
    if ctx.get("keltner_extreme") == "oui":
        morceaux.append("extreme Keltner M1")
    if ctx.get("keltner_extreme_m15") == "oui":
        morceaux.append("extreme Keltner M15")
    return " · ".join(morceaux)


def _regrouper_anciens(lignes):
    """Les icebergs enregistres avant le regroupement par evenement sont
    regroupes ici : meme cote, moins de 10 min et 10 $ du precedent."""
    resultat, derniers = [], {}
    for l in lignes:
        if l.get("renforcements") not in ("", None):
            resultat.append(l)
            continue
        try:
            t = datetime.strptime(f"{l['date']} {l['heure']}", "%d/%m/%Y %H:%M:%S").timestamp()
            prix = float(l["prix_gc"])
        except (KeyError, ValueError):
            resultat.append(l)
            continue
        prec = derniers.get(l["cote"])
        if prec and t - prec[0] <= EVENEMENT_S and abs(prix - prec[1]) < EVENEMENT_DOLLARS:
            derniers[l["cote"]] = (t, prix)
            continue
        derniers[l["cote"]] = (t, prix)
        resultat.append(l)
    return resultat


def _groupe_respiration(l, suffixe=""):
    zone = "dans la zone" if l["respiration" + suffixe] == "oui" else "hors zone"
    sens = "sens tendance" if l.get("sens_tendance" + suffixe) == "oui" else "contre tendance"
    return f"respiration{suffixe.replace('_', ' ').upper()} : {zone}, {sens}"


def _groupes_marche(l, groupes):
    """Regroupements par contexte marche (session, volatilite, dollar, annonces, tendance)."""
    # activite du carnet sur 60 s au moment du signal
    for cle, prefixe in (("carnet_son_cote", "carnet : son cote"),
                         ("carnet_en_face", "carnet : en face"),
                         ("carnet_desequilibre", "carnet : desequilibre"),
                         ("gros_ordres", "gros ordres 5 min :"), ("tape_vitesse", "tape :"),
                         ("valeur_initiale", "valeur initiale :"),
                         ("tendance_h1_accord", "tendance H1 :")):
        if l.get(cle):
            groupes[f"{prefixe} {l[cle]}"].append(l)
    if l.get("tendance_fond"):
        groupes["tendance de fond (H1+H4) : " + l["tendance_fond"]].append(l)
    if l.get("tendance_accord"):
        groupes["signal dans le sens du fond : " + l["tendance_accord"]].append(l)
    if l.get("tendance_score"):
        groupes["tendance multi : " + l["tendance_score"]].append(l)
    for cle, prefixe in (("session", "session"), ("volatilite", "volatilite"),
                         ("dollar", "dollar en"), ("dollar_favorable", "dollar favorable"),
                         ("annonce_proche", "annonce a moins de 30 min")):
        if l.get(cle):
            groupes[f"{prefixe} : {l[cle]}"].append(l)


def _groupes_m1_m15(l, groupes):
    """Regroupements respiration / Keltner, en M1 puis en M15."""
    for suffixe, nom in (("", "M1"), ("_m15", "M15")):
        if l.get("respiration" + suffixe):
            zone = "dans la zone" if l["respiration" + suffixe] == "oui" else "hors zone"
            sens = "sens tendance" if l.get("sens_tendance" + suffixe) == "oui" else "contre tendance"
            groupes[f"respiration {nom} : {zone}, {sens}"].append(l)
        if l.get("keltner_zone" + suffixe):
            groupes[f"keltner {nom} : " + l["keltner_zone" + suffixe]].append(l)
            groupes[f"keltner {nom} : extreme cote rebond " + l["keltner_extreme" + suffixe]].append(l)


def _preparer_fichier(fichier=None, colonnes=None):
    """Cree le fichier de resultats ; s'il date d'une version aux colonnes
    differentes, il est mis de cote."""
    fichier = fichier or FICHIER
    colonnes = colonnes or COLONNES
    if fichier.exists():
        with open(fichier, encoding="utf-8-sig") as f:
            entete = f.readline().strip().split(";")
        if entete == colonnes:
            return
        if set(entete) <= set(colonnes):
            # colonnes ajoutees par une mise a jour : on garde les resultats
            with open(fichier, encoding="utf-8-sig") as f:
                lignes = list(csv.DictReader(f, delimiter=";"))
            with open(fichier, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=colonnes, delimiter=";")
                w.writeheader()
                w.writerows(lignes)
            print(f"{fichier.name} : nouvelles colonnes ajoutees, {len(lignes)} resultats conserves.")
            return
        ancien = fichier.with_name(f"{fichier.stem}_ancien_{datetime.now():%Y%m%d_%H%M%S}.csv")
        fichier.rename(ancien)
        print(f"Ancien fichier de resultats mis de cote : {ancien.name}")
    with open(fichier, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f, delimiter=";").writerow(colonnes)


# ---------------------------------------------------------------- bilan
def texte_bilan():
    """Le bilan sous forme de texte (pour GIMALY)."""
    import contextlib
    import io
    tampon = io.StringIO()
    with contextlib.redirect_stdout(tampon):
        bilan()
        bilan_reaction()
        bilan_stops()
        print("\n")
        bilan_cycles()
        bilan_reaction(FICHIER_CYCLES, "CYCLES")
        print("\n")
        bilan_balayages()
        bilan_reaction(FICHIER_BALAYAGES, "BALAYAGES")
        bilan_stops(FICHIER_BALAYAGES, "BALAYAGES")
        print("\n")
        try:
            from gimaly.trading.valeurs_initiales import bilan as bilan_vi
            bilan_vi()
            print("\n")
        except Exception as exc:
            print(f"valeurs initiales : {exc!r}")
        try:
            from gimaly.trading.trading import bilan as bilan_bot
            bilan_bot()
        except Exception as exc:
            print(f"Bilan du bot indisponible : {exc!r}")
    return tampon.getvalue()


def bilan_reaction(fichier=None, titre="ICEBERGS"):
    """Ce que donnerait la methode 'entree sur reaction' : on attend que la zone
    reagisse (+1 $), on entre, SL 2 $ (20 pips), point mort a +5 $ (50 pips)."""
    fichier = fichier or FICHIER
    if not fichier.exists():
        return
    with open(fichier, encoding="utf-8-sig") as f:
        lignes = [l for l in csv.DictReader(f, delimiter=";") if l.get("resultat_test")]
    if fichier == FICHIER:
        lignes = _regrouper_anciens(lignes)
    if not lignes:
        print(f"ENTREE SUR REACTION ({titre}) : pas encore de signal suivi avec cette mesure.")
        return

    def nombre(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    def bloc(nom, groupe):
        n = len(groupe)
        if not n:
            return
        reagi = [l for l in groupe if l["reaction"] == "oui"]
        if not reagi:
            print(f"  {nom:<42} {n:>4} | aucune reaction")
            return
        stoppes = sum(1 for l in reagi if l["resultat_test"] == "stoppe")
        be = sum(1 for l in reagi if "point mort" in l["resultat_test"])
        r = [v for v in (nombre(l["R_max"]) for l in reagi) if v is not None]
        r60 = [v for v in (nombre(l.get("R_max_60")) for l in reagi) if v is not None]
        recul = [v for v in (nombre(l["recul_apres_reaction"]) for l in reagi) if v is not None]
        delai = [v for v in (nombre(l["delai_reaction_s"]) for l in reagi) if v is not None]
        deux_r = sum(1 for v in r if v >= 2)
        avec = [l for l in reagi if l.get("premier_evenement") in ("stop", "2R")]
        gagne = sum(1 for l in avec if l["premier_evenement"] == "2R")
        perdu = sum(1 for l in avec if l["premier_evenement"] == "stop")
        if avec:
            esperance = (2 * gagne - perdu) / len(avec)
            resume = (f"2R avant stop {100 * gagne / len(avec):5.1f} % sur {len(avec):>2} | "
                      f"esperance {esperance:+4.2f} R | ")
        else:
            resume = "2R avant stop      — | "
        print(f"  {nom:<42} {n:>4} | reaction {100 * len(reagi) / n:5.1f} % | "
              + resume + f"R max med {statistics.median(r):+4.2f} "
              f"(60 min {statistics.median(r60) if r60 else 0:+4.2f}) | "
              f"recul med {statistics.median(recul):+5.2f} $ | reaction en {statistics.median(delai):4.0f} s")

    print(f"\nENTREE SUR REACTION ({titre}) - {len(lignes)} signaux")
    print(f"(on attend que le prix reprenne {REACTION:.0f} $ dans le sens du signal, puis entree,")
    print(f" SL {SL_TEST:.0f} $ = 20 pips, point mort a +{BE_TEST:.0f} $ = 50 pips ; suivi jusqu'a 60 min)\n")
    bloc("Tous", lignes)
    groupes = defaultdict(list)
    for l in lignes:
        if l.get("cote"):
            groupes["cote : " + l["cote"]].append(l)
        if l.get("sens"):
            groupes["sens : " + l["sens"]].append(l)
        if l.get("keltner_extreme"):
            groupes["keltner M1 extreme : " + l["keltner_extreme"]].append(l)
        if l.get("flux_dans_le_sens"):
            groupes["delta dans son sens : " + l["flux_dans_le_sens"]].append(l)
        if l.get("zone_valeur"):
            groupes["zone : " + l["zone_valeur"]].append(l)
        _groupes_marche(l, groupes)
        try:
            d = float(l.get("delai_reaction_s") or -1)
        except ValueError:
            d = -1
        if d >= 0:
            tranche = "moins de 1 min" if d < 60 else "1 a 5 min" if d < 300 else "plus de 5 min"
            groupes["reaction en " + tranche].append(l)
    for cle in sorted(groupes):
        bloc(cle, groupes[cle])


def bilan_balayages():
    if not FICHIER_BALAYAGES.exists():
        print("BALAYAGES : pas encore de signal enregistre.")
        return
    with open(FICHIER_BALAYAGES, encoding="utf-8-sig") as f:
        lignes = [l for l in csv.DictReader(f, delimiter=";") if l.get("mouv_15min") not in ("", None)]
    if not lignes:
        print("BALAYAGES : pas encore de signal termine (60 min de suivi).")
        return

    def nombre(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    def bloc(titre, groupe):
        n = len(groupe)
        m15 = [v for v in (nombre(l["mouv_15min"]) for l in groupe) if v is not None]
        m60 = [v for v in (nombre(l.get("mouv_60min")) for l in groupe) if v is not None]
        fav = [v for v in (nombre(l["max_favorable"]) for l in groupe) if v is not None]
        con = [v for v in (nombre(l["max_contraire"]) for l in groupe) if v is not None]
        moy = lambda v: statistics.mean(v) if v else 0
        med = lambda v: statistics.median(v) if v else 0
        txt = lambda v: f"{med(v):+6.2f} $" if v else "     —"
        bons = 100 * sum(1 for v in m15 if v > 0) / max(len(m15), 1)
        print(f"  {titre:<42} {n:>4} | bon sens 15 min {bons:5.1f} % | 15 min med {med(m15):+6.2f} $ | "
              f"60 min med {txt(m60)} | max fav {moy(fav):+5.2f} | max contre {moy(con):+5.2f}")

    print(f"\nBILAN BALAYAGES - {len(lignes)} signaux termines")
    print("(le prix casse un plus bas / plus haut, puis revient et repart)\n")
    bloc("Tous", lignes)
    groupes = defaultdict(list)
    for l in lignes:
        groupes["sens : " + l["sens"]].append(l)
        groupes["liquidite cassee : " + l["liquidite_cassee"]].append(l)
        groupes["keltner casse : " + l["keltner_casse"]].append(l)
        if l.get("session"):
            groupes["session : " + l["session"]].append(l)
        if l.get("annonce_proche"):
            groupes["annonce a moins de 30 min : " + l["annonce_proche"]].append(l)
    for cle in sorted(groupes):
        bloc(cle, groupes[cle])
    if len(lignes) < 30:
        print("\nAttention : moins de 30 signaux, les chiffres ne sont pas encore fiables.")


def bilan_stops(fichier=None, titre="ICEBERGS"):
    """Compare plusieurs tailles de stop sur les memes signaux (objectif 2R)."""
    fichier = fichier or FICHIER
    if not fichier.exists():
        return
    colonne = f"test_sl{int(SL_VARIANTES[0] * 10)}"
    with open(fichier, encoding="utf-8-sig") as f:
        lignes = [l for l in csv.DictReader(f, delimiter=";") if l.get(colonne)]
    if fichier == FICHIER:
        lignes = _regrouper_anciens(lignes)
    if not lignes:
        print(f"TAILLES DE STOP ({titre}) : pas encore de signal mesure avec cette version.")
        return
    print(f"\nTAILLES DE STOP ({titre}) - {len(lignes)} signaux")
    print("(entree sur reaction, objectif 2R ; esperance = (2 x gagnants - perdants) / trades)\n")
    for taille in SL_VARIANTES:
        cle = f"test_sl{int(taille * 10)}"
        tranches = [l for l in lignes if l.get(cle) in ("stop", "2R")]
        if not tranches:
            print(f"  stop {taille * 10:>3.0f} pips : aucun signal tranche")
            continue
        gagnes = sum(1 for l in tranches if l[cle] == "2R")
        esperance = (2 * gagnes - (len(tranches) - gagnes)) / len(tranches)
        print(f"  stop {taille * 10:>3.0f} pips (objectif {2 * taille * 10:>3.0f}) : "
              f"{len(tranches):>3} tranches | 2R avant stop {100 * gagnes / len(tranches):5.1f} % | "
              f"esperance {esperance:+5.2f} R | en cours : {len(lignes) - len(tranches)}")


def bilan_cycles():
    if not FICHIER_CYCLES.exists():
        print("CYCLE DES 5 BOUGIES : pas encore de signal enregistre.")
        return
    with open(FICHIER_CYCLES, encoding="utf-8-sig") as f:
        lignes = [l for l in csv.DictReader(f, delimiter=";") if l.get("mouv_15min") not in ("", None)]
    if not lignes:
        print("CYCLE DES 5 BOUGIES : pas encore de signal termine (15 min de suivi).")
        return

    def nombre(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    def bloc(titre, groupe):
        n = len(groupe)
        m5 = [v for v in (nombre(l["mouv_5min"]) for l in groupe) if v is not None]
        m15 = [v for v in (nombre(l["mouv_15min"]) for l in groupe) if v is not None]
        gagnants = sum(1 for v in m15 if v > 0)
        fav = [v for v in (nombre(l["max_favorable"]) for l in groupe) if v is not None]
        con = [v for v in (nombre(l["max_contraire"]) for l in groupe) if v is not None]
        moy = lambda v: statistics.mean(v) if v else 0
        med = lambda v: statistics.median(v) if v else 0
        txt = lambda v: f"{med(v):+6.2f} $" if v else "     —"
        txt2 = lambda v: f"{moy(v):+5.2f}" if v else "  —"
        m60 = [v for v in (nombre(l.get("mouv_60min")) for l in groupe) if v is not None]
        fav60 = [v for v in (nombre(l.get("max_favorable_60")) for l in groupe) if v is not None]
        print(f"  {titre:<42} {n:>4} | dans le bon sens a 15 min {100 * gagnants / max(len(m15), 1):5.1f} % | "
              f"15 min moy {moy(m15):+6.2f} med {med(m15):+6.2f} $ | 60 min med {txt(m60)} | "
              f"5 min {moy(m5):+6.2f} $ | max fav {moy(fav):+5.2f} (60 min {txt2(fav60)}) | "
              f"max contre {moy(con):+5.2f}")

    print(f"BILAN CYCLE DES 5 BOUGIES - {len(lignes)} signaux termines (suivi 60 min)")
    print("(mouvements positifs = le prix est parti dans le sens du signal)\n")
    bloc("Tous", lignes)
    groupes = defaultdict(list)
    for l in lignes:
        groupes["sens : " + l["sens"]].append(l)
        groupes["scenario : " + l["scenario"]].append(l)
        groupes["heure : " + l["heure"][:2] + "h"].append(l)
        if l.get("cote_vwap"):
            groupes["VWAP : signal " + l["cote_vwap"]].append(l)
        if l.get("zone_valeur"):
            groupes["zone : " + l["zone_valeur"]].append(l)
        _groupes_m1_m15(l, groupes)
        _groupes_marche(l, groupes)
        if l.get("iceberg_aligne"):
            groupes["avec iceberg dans le meme sens : " + l["iceberg_aligne"]].append(l)
        else:
            groupes["sans iceberg recent"].append(l)
    for cle in sorted(groupes):
        bloc(cle, groupes[cle])
    if len(lignes) < 30:
        print("\nAttention : moins de 30 signaux, les chiffres ne sont pas encore fiables.")


def bilan():
    if not FICHIER.exists():
        print("Pas encore d'icebergs enregistres.")
        return
    with open(FICHIER, encoding="utf-8-sig") as f:
        lignes = [l for l in csv.DictReader(f, delimiter=";") if l.get("mouv_15min") not in ("", None)]
    if not lignes:
        print("Pas encore d'icebergs termines (il faut 15 min de suivi).")
        return

    def nombre(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    def bloc(titre, groupe):
        n = len(groupe)
        tenus = sum(1 for l in groupe if l["casse"] == "non")
        m5 = [v for v in (nombre(l["mouv_5min"]) for l in groupe) if v is not None]
        m15 = [v for v in (nombre(l["mouv_15min"]) for l in groupe) if v is not None]
        fav = [v for v in (nombre(l["max_favorable"]) for l in groupe) if v is not None]
        con = [v for v in (nombre(l["max_contraire"]) for l in groupe) if v is not None]
        moy = lambda v: statistics.mean(v) if v else 0
        med = lambda v: statistics.median(v) if v else 0
        txt = lambda v: f"{med(v):+6.2f} $" if v else "     —"
        txt2 = lambda v: f"{moy(v):+5.2f}" if v else "  —"
        bons = 100 * sum(1 for v in m15 if v > 0) / max(len(m15), 1)
        m60 = [v for v in (nombre(l.get("mouv_60min")) for l in groupe) if v is not None]
        fav60 = [v for v in (nombre(l.get("max_favorable_60")) for l in groupe) if v is not None]
        print(f"  {titre:<42} {n:>4} | tenus {100 * tenus / n:5.1f} % | bon sens 15 min {bons:5.1f} % | "
              f"15 min moy {moy(m15):+6.2f} med {med(m15):+6.2f} $ | 60 min med {txt(m60)} | "
              f"5 min {moy(m5):+6.2f} $ | max fav {moy(fav):+5.2f} (60 min {txt2(fav60)}) | "
              f"max contre {moy(con):+5.2f}")

    avant = len(lignes)
    lignes = _regrouper_anciens(lignes)
    print(f"BILAN ICEBERGS - {len(lignes)} evenements termines ({avant} icebergs, "
          f"les renforcements d'un meme evenement comptent une seule fois)")
    print("(mouvements positifs = le prix est parti dans le sens de l'iceberg ;")
    print(" med = mediane, moins sensible qu'une moyenne a un seul gros mouvement ;")
    print(f" tenu = pas depasse de plus de {CASSE_MARGE:.0f} $ en 15 min, valable pour les icebergs")
    print(" enregistres apres la mise a jour du 22/09 apres-midi)\n")
    bloc("Tous", lignes)
    groupes = defaultdict(list)
    for l in lignes:
        groupes["cote : " + l["cote"]].append(l)
        d = nombre(l["liq_distance"])
        if d is not None:
            groupes["sur une liquidite" if d <= PROCHE_LIQUIDITE else "loin des liquidites"].append(l)
        groupes["heure : " + l["heure"][:2] + "h"].append(l)
        if l.get("cote_vwap"):
            groupes["VWAP : iceberg " + l["cote_vwap"]].append(l)
        if l.get("zone_valeur"):
            groupes["zone : " + l["zone_valeur"]].append(l)
        if l.get("flux_dans_le_sens"):
            groupes["delta 5 min dans son sens : " + l["flux_dans_le_sens"]].append(l)
        if l.get("mur"):
            groupes["mur visible : " + l["mur"]].append(l)
        _groupes_m1_m15(l, groupes)
        _groupes_marche(l, groupes)
    for cle in sorted(groupes):
        bloc(cle, groupes[cle])
    if len(lignes) < 30:
        print("\nAttention : moins de 30 observations, les chiffres ne sont pas encore fiables.")


# ---------------------------------------------------------------- rejouer
def _lire_messages(chemin):
    """Messages d'un fichier brut (.jsonl.gz de GIMALY ou kmm_brut.jsonl de capture_kmm)."""
    chemin = Path(chemin)
    ouvrir = gzip.open if chemin.suffix == ".gz" else open
    with ouvrir(chemin, "rt", encoding="utf-8") as f:
        try:
            for ligne in f:
                try:
                    e = json.loads(ligne)
                except ValueError:
                    continue
                if "data" in e:                  # format de capture_kmm.py
                    if e.get("type") != "ws_recu":
                        continue
                    try:
                        e = json.loads(e["data"])
                    except ValueError:
                        continue
                yield e
        except EOFError:                          # fichier du jour encore ouvert
            return


def rejouer(chemins, **reglages):
    """Fait passer un flux enregistre dans le detecteur et montre ce qu'il trouve."""
    trouves = []
    det = DetecteurIcebergs(lambda niv, d: trouves.append((det.t_ms, niv, det.mid)),
                            **{**REGLAGES, **reglages})
    from gimaly.trading.flux_ordres import FluxOrdres
    flux = FluxOrdres()
    cycles = []
    flux.sur_cycle = lambda sig: cycles.append(sig)
    temps, mids = [], []
    n = 0
    for chemin in chemins:
        for m in _lire_messages(chemin):
            n += 1
            flux.message(m)
            det.message(m)
            if m.get("type") == "book" and not math.isnan(det.mid):
                if not temps or det.t_ms - temps[-1] >= 1000:
                    temps.append(det.t_ms)
                    mids.append(det.mid)
    if not temps:
        print("Aucun message exploitable.")
        return
    duree = (temps[-1] - temps[0]) / 60000
    print(f"{n} messages, {duree:.0f} min de marche. Reglages : {det.volume_min} contrats min, "
          f"ratio {det.ratio_min}, {det.recharges_min} recharges min, {det.cache_min} caches min.\n")

    def mid_a(ts):
        i = bisect.bisect_left(temps, ts)
        # pas de valeur si le flux a un trou (fichiers de jours differents)
        return mids[i] if i < len(mids) and temps[i] - ts <= 120_000 else None

    evenements = {}
    print(f"== ICEBERGS DETECTES : {len(trouves)} ==")
    for ts, niv, mid0 in trouves:
        prec = evenements.get(niv.cote)
        evenements[niv.cote] = (ts, niv.prix)
        if prec and ts - prec[0] <= EVENEMENT_S * 1000 and abs(niv.prix - prec[1]) < EVENEMENT_DOLLARS:
            print(f"  {datetime.fromtimestamp(ts / 1000):%d/%m %H:%M:%S}  {niv.cote:<8} GC {niv.prix:<8} "
                  f"{niv.volume:>4.0f} contrats  (renforcement de l'evenement precedent)")
            continue
        sens = -1 if niv.cote == "vendeur" else 1
        mouv = [(mid_a(ts + h * 1000) - mid0) * sens if mid_a(ts + h * 1000) is not None else None
                for h in HORIZONS]
        casse = "?"
        i = bisect.bisect_left(temps, ts)
        fin = bisect.bisect_left(temps, ts + 900_000)
        if fin < len(temps) or i < len(temps):
            casse = "non"
            for k in range(i, min(fin, len(mids))):
                if (niv.cote == "vendeur" and mids[k] > niv.prix + CASSE_MARGE) or \
                        (niv.cote == "acheteur" and mids[k] < niv.prix - CASSE_MARGE):
                    casse = f"oui ({(temps[k] - ts) / 1000:.0f} s)"
                    break
        txt = " ".join(f"{h // 60}min {v:+.2f}" if v is not None else f"{h // 60}min —"
                       for h, v in zip(HORIZONS, mouv))
        print(f"  {datetime.fromtimestamp(ts / 1000):%d/%m %H:%M:%S}  {niv.cote:<8} GC {niv.prix:<8} "
              f"{niv.volume:>4.0f} contrats dont {niv.cache:.0f} caches, affiche moy. {niv.affiche_moyen:.1f}, "
              f"{niv.recharges} rech. | "
              f"{txt} | casse {casse}")

    print(f"\n== CYCLES DES 5 BOUGIES : {len(cycles)} ==")
    for sig in cycles:
        ts = sig["t"] * 1000
        sens = 1 if sig["sens"] == "achat" else -1
        txt = " ".join(f"{h // 60}min {(mid_a(ts + h * 1000) - sig['prix']) * sens:+.2f}"
                       if mid_a(ts + h * 1000) is not None else f"{h // 60}min —" for h in HORIZONS)
        print(f"  {datetime.fromtimestamp(sig['t']):%d/%m %H:%M}  {sig['sens']:<6} ({sig['scenario']:<12}) "
              f"GC {sig['prix']:<8} {sig['divergentes']} {sig['couleur_serie']}s delta {sig['delta_serie']:+.0f}, "
              f"saine {sig['delta_saine']:+.0f} | {txt}")

    print("\n== PRIX LES PLUS DISPUTES (pour regler les seuils) ==")
    print("  cote      prix       volume  caches  affiche moy/max  vu  recharges  ratio")
    for v in det.candidats(15):
        ratio = v.volume / max(v.affiche_moyen, 1)
        marque = "  <- iceberg" if v.signale else ""
        print(f"  {v.cote:<8}  {v.prix:<9}  {v.volume:>6.0f}  {v.cache:>6.0f}  {v.affiche_moyen:>6.1f} / {v.affiche_max:<5.0f} {v._nb_aff:>4}"
              f"  {v.recharges:>9}  {ratio:>5.1f}{marque}")


# ---------------------------------------------------------------- lancement
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bilan", action="store_true")
    ap.add_argument("--visible", action="store_true")
    ap.add_argument("--sans-mt5", action="store_true")
    ap.add_argument("--fond", action="store_true", help="lancer en arriere-plan")
    ap.add_argument("--etat", action="store_true", help="afficher l'etat")
    ap.add_argument("--arreter", action="store_true", help="arreter l'observation")
    ap.add_argument("--rejouer", nargs="*", metavar="FICHIER",
                    help="rejouer un flux enregistre (par defaut : celui du jour)")
    ap.add_argument("--volume-min", type=float)
    ap.add_argument("--ratio-min", type=float)
    ap.add_argument("--recharges-min", type=int)
    ap.add_argument("--cache-min", type=float)
    ap.add_argument("--affichages-min", type=int)
    args = ap.parse_args()
    if args.rejouer is not None:
        fichiers = args.rejouer or sorted(DOSSIER_BRUT.glob("kmm_*.jsonl.gz"))[-1:]
        if not fichiers:
            print(f"Aucun flux enregistre dans {DOSSIER_BRUT}.")
            return
        reglages = {k: v for k, v in (("volume_min", args.volume_min), ("ratio_min", args.ratio_min),
                                       ("recharges_min", args.recharges_min),
                                       ("cache_min", args.cache_min),
                                       ("affichages_min", args.affichages_min)) if v is not None}
        rejouer(fichiers, **reglages)
        return
    if args.bilan:
        bilan()
        bilan_reaction()
        bilan_stops()
        print()
        bilan_cycles()
        bilan_reaction(FICHIER_CYCLES, "CYCLES")
        print()
        bilan_balayages()
        bilan_reaction(FICHIER_BALAYAGES, "BALAYAGES")
        bilan_stops(FICHIER_BALAYAGES, "BALAYAGES")
        print()
        from gimaly.trading.valeurs_initiales import bilan as bilan_vi
        bilan_vi()
        return
    if args.fond:
        print(demarrer_en_fond())
        print(f"Journal : {JOURNAL}")
        return
    if args.arreter:
        print(arreter())
        return
    if args.etat:
        e = lire_etat()
        if not e:
            print("Jamais lance.")
            return
        print(f"{'EN COURS' if en_cours() else 'ARRETE'} - derniere mise a jour {e['maj']}")
        print(f"  {e['messages_min']} messages/min | GC {e['gc']} | XAUUSD ~ {e['xauusd']} | ecart {e['ecart']}")
        print(f"  {e['en_suivi']} en suivi, {e['enregistres']} enregistre(s) depuis le lancement")
        for d in e.get("derniers", [])[:10]:
            print(f"  {d['heure']}  {d['cote']:<8} GC {d['prix_gc']}  XAUUSD {d['prix_xau']}  "
                  f"{d['volume']:.0f} contrats  -> {d['statut']} {d['mouv_15min']}")
        return

    DOSSIER.mkdir(parents=True, exist_ok=True)
    journal = open(JOURNAL, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = _Double(sys.__stdout__, journal)
    # un seul detecteur a la fois (comme le bot) : verrou par port local, libere a la mort du processus
    import socket
    global _VERROU_DETECTEUR
    _VERROU_DETECTEUR = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        _VERROU_DETECTEUR.bind(("127.0.0.1", 47823))
    except OSError:
        print(f"{datetime.now():%H:%M:%S} Un detecteur tourne deja : ce lancement est annule.")
        return
    if STOP.exists():
        STOP.unlink()

    from gimaly.trading.flux_kmm import ecouter
    obs = Observateur(avec_mt5=not args.sans_mt5)
    obs._dernier_message = time.time()

    def horloge():
        # garde MT5, le graphique et les signaux de zones a jour meme si KMM tombe
        while not STOP.exists():
            time.sleep(1)
            try:
                obs.tic_sans_flux()
            except Exception as exc:
                print(f"horloge : {exc!r}")
    threading.Thread(target=horloge, daemon=True, name="gimaly-horloge").start()
    print(f"\n{datetime.now():%d/%m/%Y %H:%M} Observation des icebergs lancee (aucun ordre passe).")
    print(f"Reglages : {REGLAGES}\nResultats : {FICHIER}\n")
    obs.pouls()
    try:
        # 05/10 : sans KMM (session expiree, terminal inaccessible), le detecteur
        # ne s'arrete plus. Les signaux du bot (BOS cassure M15, valeur initiale
        # contre la tendance) ne dependent QUE de MT5 : l'horloge continue de les
        # calculer et de les proposer. KMM est retente toutes les 5 minutes.
        while not STOP.exists():
            try:
                ecouter(obs.message, visible=args.visible, arret=STOP.exists)
                break                                   # arret demande
            except RuntimeError as e:
                print(e)
                obs.sans_kmm = True
                print(f"{datetime.now():%H:%M} MODE MT5 SEUL : signaux du bot actifs "
                      f"(BOS, valeurs initiales), flux COMEX et icebergs indisponibles. "
                      f"Nouvel essai KMM dans 5 min.")
                for _ in range(300):
                    if STOP.exists():
                        break
                    time.sleep(1)
                if not STOP.exists():
                    print(f"{datetime.now():%H:%M} nouvel essai de connexion KMM")
    except KeyboardInterrupt:
        pass
    finally:
        obs.fermer()
        print(f"\nArrete. {obs.nb} icebergs enregistres cette session "
              f"({len(obs.en_cours)} en cours de suivi non enregistres).")


from gimaly.trading.symbole import symbole_or  # symbole de l'or du courtier

if __name__ == "__main__":
    main()
