# Nom du symbole de l'or chez ton courtier (XAUUSD, XAUUSDm, XAUUSD.pro, GOLD...).
# Le nom est cherche automatiquement par l'assistant / le lanceur et memorise dans config.local.yaml
# (ligne  trading_symbole). Tu peux aussi l'ecrire a la main.
import re
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config.local.yaml"
_MOTIF = re.compile(r"^trading_symbole:[ \t]*([^#\n]*?)[ \t]*(?:#.*)?$", re.M)
_AUTRES_DEVISES = ("EUR", "GBP", "AUD", "CHF", "JPY", "CAD", "NZD")


def lire():
    try:
        m = _MOTIF.search(CONFIG.read_text(encoding="utf-8"))
    except OSError:
        return ""
    valeur = m.group(1).strip().strip("'\"") if m else ""
    return "" if valeur.lower() in ("", "auto") else valeur


def symbole_or():
    return lire() or "XAUUSD"


def ecrire(nom):
    texte = CONFIG.read_text(encoding="utf-8")
    if _MOTIF.search(texte):
        texte = _MOTIF.sub(lambda m: "trading_symbole: " + nom, texte, count=1)
    else:
        texte = texte.rstrip("\n") + "\ntrading_symbole: " + nom + "\n"
    CONFIG.write_text(texte, encoding="utf-8")


def _classer(s):
    """None si ce n'est pas de l'or en dollars ; sinon une cle de tri (plus petit = plus probable)."""
    if getattr(s, "trade_mode", 4) == 0:            # trading desactive sur ce symbole
        return None
    brut = re.sub(r"[^A-Z0-9]", "", s.name.upper())
    desc = (getattr(s, "description", "") or "").upper()
    chemin = (getattr(s, "path", "") or "").upper()
    if any(d in brut for d in _AUTRES_DEVISES):
        return None                                  # XAUEUR, GOLDEUR...
    if brut == "XAUUSD":
        rang = 0
    elif brut.startswith("XAUUSD"):
        rang = 1
    elif brut.startswith("XAU"):
        rang = 2
    elif brut.startswith("GOLD"):
        rang = 3
    elif "GOLD" in desc and ("METAL" in chemin or "GOLD" in chemin or "COMMOD" in chemin) and "FUTUR" not in desc:
        rang = 4
    else:
        return None
    reduit = 1 if any(m in brut or m in desc for m in ("MICRO", "CENT")) or brut.endswith("C") else 0
    return (rang, reduit, s.name.upper() != brut, not s.visible, len(brut), s.name)


def detecter(mt5):
    """Symboles de l'or (en USD) proposes par le courtier, du plus probable au moins probable."""
    classes = [c for c in (_classer(s) for s in (mt5.symbols_get() or ())) if c is not None]
    classes.sort()
    return [c[-1] for c in classes]


def assurer(mt5):
    """Verifie que le symbole configure existe ; sinon cherche l'or et le memorise. Renvoie le nom ou None."""
    actuel = symbole_or()
    if mt5.symbol_info(actuel) is None:
        trouves = detecter(mt5)
        if not trouves:
            return None
        actuel = trouves[0]
        ecrire(actuel)
    mt5.symbol_select(actuel, True)
    return actuel
