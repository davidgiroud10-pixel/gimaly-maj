r"""
gimaly/trading/balayage.py - G.I.M.A.L.Y
Balayage de liquidite puis reprise : le prix casse un plus bas (ou un plus
haut), va chercher les stops qui s'y trouvent, puis revient aussitot de
l'autre cote du niveau et repart. C'est le schema du 23/09 a 11 h 55 sur
l'or : plus bas a 4308,39 balaye, reprise immediate, +15 $ derriere.

Conditions retenues (bougies M1 fermees de XAUUSD) :
  1. le prix fait un nouveau plus bas sur FENETRE bougies ;
  2. ce plus bas depasse le creux precedent de moins de PROFONDEUR_MAX x ATR
     (au-dela, c'est une vraie cassure, pas un piege a liquidite) ;
  3. dans les REPRISE_MAX minutes, le prix repasse au-dessus du niveau
     balaye d'au moins REPRISE_ATR x ATR ;
  4. le delta du flux d'ordres est du cote de la reprise.
Une zone de liquidite LuxAlgo cassee ou la bande de Keltner franchie sont
notees en plus : le bilan dira si elles ameliorent le signal.
"""
from __future__ import annotations

import math

FENETRE = 40            # bougies examinees
AVANT = 30              # bougies avant le plus bas, pour verifier qu'il est nouveau
REPRISE_MAX = 15        # minutes maximum entre le balayage et la reprise
PROFONDEUR_MAX = 2.0    # en ATR : au-dela, c'est une cassure
REPRISE_ATR = 0.5       # reprise d'au moins la moitie d'un ATR au-dessus du niveau
REPRISE_MAX_ATR = 4.0   # au-dela, le prix est deja trop loin : ce n'est plus une entree


def detecter(bougies, atr, delta_5min=0.0, niveaux_liq=None, keltner=None,
             fenetre=FENETRE, reprise_max=REPRISE_MAX, prix_actuel=None):
    """Renvoie un signal de balayage (dict) ou None. `bougies` : (o, h, l, c) fermees.
    `prix_actuel` : prix en direct. Sans lui, on utilise la derniere cloture, ce
    qui fait rater les creux en V (le prix reprend avant la fin de la bougie)."""
    if not bougies or len(bougies) < fenetre + AVANT + 2 or not atr or math.isnan(atr):
        return None
    recentes = bougies[-fenetre:]
    decalage = len(bougies) - fenetre
    prix = bougies[-1][3] if prix_actuel is None or math.isnan(prix_actuel) else prix_actuel

    for sens in ("achat", "vente"):
        haussier = sens == "achat"
        if haussier:
            i = min(range(len(recentes)), key=lambda k: recentes[k][2])
            extreme = min(recentes[i][2], prix)
        else:
            i = max(range(len(recentes)), key=lambda k: recentes[k][1])
            extreme = max(recentes[i][1], prix)
        age = len(recentes) - 1 - i                      # en minutes
        # age 0 = le plus bas est sur la bougie en cours : c'est justement le
        # creux en V qu'on veut attraper, grace au prix en direct.
        if age > reprise_max:
            continue
        avant = bougies[decalage + i - AVANT:decalage + i]
        if not avant:
            continue
        niveau = min(b[2] for b in avant) if haussier else max(b[1] for b in avant)
        profondeur = (niveau - extreme) if haussier else (extreme - niveau)
        if profondeur <= 0 or profondeur > PROFONDEUR_MAX * atr:
            continue                                     # pas un balayage : cassure ou rien
        reprise = (prix - niveau) if haussier else (niveau - prix)
        if reprise < REPRISE_ATR * atr:
            continue                                     # le prix n'est pas revenu au-dessus
        if reprise > REPRISE_MAX_ATR * atr:
            continue                                     # deja trop loin du niveau balaye
        if (haussier and delta_5min <= 0) or (not haussier and delta_5min >= 0):
            continue                                     # le flux ne confirme pas

        liquidite = "non"
        for n in (niveaux_liq or []):
            attendu = "vente" if haussier else "achat"
            if n.cote == attendu and min(extreme, niveau) - 0.3 <= n.prix <= max(extreme, niveau) + 0.3:
                liquidite = "oui"
                break
        keltner_casse = "non"
        if keltner:
            if haussier and extreme < keltner["bas"]:
                keltner_casse = "oui"
            if not haussier and extreme > keltner["haut"]:
                keltner_casse = "oui"
        return {"sens": sens, "prix": prix, "niveau": round(niveau, 2),
                "extreme": round(extreme, 2), "profondeur": round(profondeur, 2),
                "delai_reprise_min": age, "liquidite_cassee": liquidite,
                "keltner_casse": keltner_casse, "delta_5min": delta_5min}
    return None
