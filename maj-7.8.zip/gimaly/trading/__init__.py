"""
gimaly/trading - G.I.M.A.L.Y
Module de trading : lecture MT5, flux d'ordres KMM, indicateurs
(liquidite LuxAlgo, VWAP, Supertrend, Keltner, structure) et bot.
Le bot fonctionne sur compte DEMO par defaut, avec risque par trade,
perte maximale par jour et arret immediat par le bouton STOP de GIMALY.
"""
