"""MetaTrader5 dans un processus a part - G.I.M.A.L.Y

Pourquoi : la bibliotheque MetaTrader5 garde la main sur tout le programme
Python pendant ses appels. Quand MT5 est lent (grosse impulsion, envoi d'un
ordre), GIMALY entier gelait ("Python ne repond pas") : diagnostic de gel.log,
le bot etait bloque dans mt5.order_send pendant que l'interface attendait.

Ici, MT5 tourne dans un petit processus separe. Le bot lui parle par un tuyau :
pendant qu'il attend la reponse, l'interface de GIMALY continue de tourner.

Utilisation (le bot le fait tout seul) :
    mt5 = MT5Isole()
    mt5.symbol_info_tick("XAUUSD").bid
    mt5.TRADE_ACTION_DEAL
"""
from __future__ import annotations

import os
import pickle
import subprocess
import sys
import threading
import time
import types
from pathlib import Path

DELAI_APPEL = 120          # secondes : au-dela, le processus MT5 est relance
JOURNAL = Path.home() / "GIMALY" / "trading" / "mt5_isole.log"


def _convertir(x):
    """Les objets de MetaTrader5 ne passent pas d'un processus a l'autre :
    on les transforme en objets simples (memes noms d'attributs)."""
    if hasattr(x, "_asdict"):
        return types.SimpleNamespace(**{k: _convertir(v) for k, v in x._asdict().items()})
    if isinstance(x, tuple):
        return tuple(_convertir(v) for v in x)
    return x


# ------------------------------------------------------------------ enfant
def _serveur() -> None:
    # le tuyau de reponse garde la vraie sortie ; tout ce qui s'afficherait
    # (print, messages de la bibliotheque) part dans le journal
    sortie = os.fdopen(os.dup(1), "wb")
    os.dup2(2, 1)
    sys.stdout = sys.stderr
    entree = sys.stdin.buffer
    # un plantage dans la bibliotheque MetaTrader5 (code C) laisse sa trace ici
    import faulthandler
    faulthandler.enable(file=sys.stderr)

    def horodate(texte):
        sys.stderr.write(time.strftime("%d/%m %H:%M:%S  ") + texte + "\n")
        sys.stderr.flush()

    def repondre(donnees) -> bool:
        """Renvoie faux si GIMALY a ferme le tuyau (fenetre fermee, ancien
        client remplace) : on s'arrete proprement au lieu de planter."""
        try:
            sortie.write(donnees)
            sortie.flush()
            return True
        except OSError as exc:
            horodate(f"GIMALY ne lit plus la reponse ({exc!r}) : arret du programme MT5")
            return False

    import MetaTrader5 as mt5
    constantes = {k: getattr(mt5, k) for k in dir(mt5)
                  if k.isupper() and isinstance(getattr(mt5, k), int)}
    ok = mt5.initialize()
    horodate(f"demarrage, MT5 {'connecte' if ok else 'injoignable'}")
    if not repondre(pickle.dumps(("init", ok, None if ok else mt5.last_error(), constantes))):
        return
    while True:
        try:
            nom, args, kwargs = pickle.load(entree)
        except (EOFError, OSError):
            break
        if nom == "__fin__":
            break
        debut = time.time()
        try:
            fonction = getattr(mt5, nom)
            # MetaTrader5 refuse un dictionnaire de mots-cles vide a cote
            # d'arguments normaux ("Unnamed arguments not allowed")
            if args and kwargs:
                brut = fonction(*args, **kwargs)
            elif kwargs:
                brut = fonction(**kwargs)
            else:
                brut = fonction(*args)
            reponse = ("ok", _convertir(brut))
            donnees = pickle.dumps(reponse)
        except Exception as exc:
            donnees = pickle.dumps(("err", f"{nom} : {exc!r}"))
        duree = time.time() - debut
        if duree > 10:
            horodate(f"{nom} a mis {duree:.0f} s a repondre")
        if not repondre(donnees):
            break
    try:
        mt5.shutdown()
    except Exception:
        pass


# ------------------------------------------------------------------ parent
class MT5Isole:
    """Se manipule comme le module MetaTrader5 (memes fonctions, memes constantes)."""

    def __init__(self, delai: float = DELAI_APPEL) -> None:
        self._delai = delai
        self._verrou = threading.Lock()
        self._mort = False
        racine = Path(__file__).resolve().parents[2]
        JOURNAL.parent.mkdir(parents=True, exist_ok=True)
        self._journal = open(JOURNAL, "ab")
        options = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        self._proc = subprocess.Popen(
            [sys.executable, "-m", "gimaly.trading.mt5_isole"], cwd=str(racine),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self._journal,
            creationflags=options)
        try:
            _, ok, erreur, self._constantes = self._lire(60)
        except Exception:
            self.fermer()
            raise RuntimeError("MT5 injoignable : le processus MT5 n'a pas demarre "
                               f"(voir {JOURNAL})")
        if not ok:
            self.fermer()
            raise RuntimeError(f"MT5 injoignable : {erreur}")

    @property
    def vivant(self) -> bool:
        return not self._mort and self._proc.poll() is None

    def _lire(self, delai):
        self._par_minuteur = False
        """Lit une reponse ; si MT5 ne repond pas a temps, le processus est tue
        (la lecture echoue alors au lieu de bloquer le bot pour toujours)."""
        minuteur = threading.Timer(delai, self._tuer)
        minuteur.daemon = True
        minuteur.start()
        try:
            return pickle.load(self._proc.stdout)
        except (EOFError, OSError, pickle.UnpicklingError) as exc:
            self._mort = True
            cause = (f"aucune reponse en {delai:.0f} s, programme MT5 relance"
                     if getattr(self, "_par_minuteur", False) else f"programme MT5 arrete ({exc!r})")
            raise RuntimeError(f"MT5 ne repond plus : {cause}")
        finally:
            minuteur.cancel()

    def _tuer(self) -> None:
        self._par_minuteur = True
        self._mort = True
        try:
            self._proc.kill()
        except OSError:
            pass

    def _appeler(self, nom, args, kwargs):
        with self._verrou:
            if not self.vivant:
                raise RuntimeError("processus MT5 arrete")
            try:
                pickle.dump((nom, args, kwargs), self._proc.stdin)
                self._proc.stdin.flush()
            except OSError as exc:
                self._mort = True
                raise RuntimeError(f"MT5 ne repond plus ({exc!r})")
            statut, valeur = self._lire(self._delai)
        if statut == "err":
            raise RuntimeError(valeur)
        return valeur

    def __getattr__(self, nom):
        if nom.startswith("_"):
            raise AttributeError(nom)
        constantes = self.__dict__.get("_constantes", {})
        if nom in constantes:
            return constantes[nom]
        return lambda *args, **kwargs: self._appeler(nom, args, kwargs)

    def initialize(self, *args, **kwargs):
        return True        # deja fait au demarrage du processus

    def fermer(self) -> None:
        try:
            with self._verrou:
                pickle.dump(("__fin__", (), {}), self._proc.stdin)
                self._proc.stdin.flush()
        except Exception:
            pass
        try:
            self._proc.wait(5)
        except Exception:
            self._tuer()


if __name__ == "__main__":
    _serveur()
