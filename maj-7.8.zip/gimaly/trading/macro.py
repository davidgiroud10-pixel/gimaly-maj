"""Tableau macro de l'or - G.I.M.A.L.Y

Ce qui fait bouger l'or sur des jours et des semaines : inflation, taux de la
Fed et ce que le marché en attend, taux réels, dollar, peur sur les marchés.
Source : FRED (Réserve fédérale de Saint-Louis), fichiers CSV publics, sans
clé. Mis à jour toutes les 6 heures dans ~/GIMALY/trading/macro.json.

Observation seulement : n'entre pas dans les décisions du bot.
"""
from __future__ import annotations

import csv
import io
import json
import threading
import time
import urllib.request
from datetime import datetime
from pathlib import Path

FICHIER = Path.home() / "GIMALY" / "trading" / "macro.json"
DUREE_CACHE_S = 3600            # FRED (quotidien / mensuel) et COT : toutes les heures
DUREE_DIRECT_S = 120            # cours en direct et probabilites Fed : toutes les 2 min
URL = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={}"

# (code FRED, libellé, unité, calcul, lecture pour l'or)
# calcul : "niveau" = dernière valeur ; "glissement" = variation sur 12 mois (%)
# or_si_hausse : +1 si une hausse est plutôt favorable à l'or, -1 défavorable
SERIES = [
    ("CPIAUCSL", "Inflation (CPI)", "%", "glissement", +1),
    ("CPILFESL", "Inflation hors énergie et alimentation (CPI core)", "%", "glissement", +1),
    ("PCEPILFE", "Inflation PCE core (cible de la Fed : 2 %)", "%", "glissement", +1),
    ("DFEDTARU", "Taux directeur de la Fed (haut de fourchette)", "%", "niveau", -1),
    ("DGS2", "Taux à 2 ans (ce que le marché attend de la Fed)", "%", "niveau", -1),
    ("DGS10", "Taux à 10 ans", "%", "niveau", -1),
    ("DFII10", "Taux réel à 10 ans (après inflation)", "%", "niveau", -1),
    ("T10YIE", "Inflation attendue à 10 ans", "%", "niveau", +1),
    ("DTWEXBGS", "Dollar (indice large)", "", "niveau", -1),
    ("VIXCLS", "Peur sur les actions (VIX)", "", "niveau", +1),
    ("UNRATE", "Chômage américain", "%", "niveau", +1),
]

_verrou = threading.Lock()

# chiffre reel des grandes annonces, lu sur FRED apres publication :
# titre Forex Factory -> (serie FRED, calcul, format)
ANNONCES_REELLES = {
    "non-farm employment change": ("PAYEMS", "difference", "{:.0f}K"),
    "unemployment rate": ("UNRATE", "niveau", "{:.1f}%"),
    "average hourly earnings m/m": ("CES0500000003", "mensuel", "{:.1f}%"),
    "cpi m/m": ("CPIAUCSL", "mensuel", "{:.1f}%"),
    "core cpi m/m": ("CPILFESL", "mensuel", "{:.1f}%"),
    "cpi y/y": ("CPIAUCSL", "annuel", "{:.1f}%"),
    "core pce price index m/m": ("PCEPILFE", "mensuel", "{:.1f}%"),
    "unemployment claims": ("ICSA", "milliers", "{:.0f}K"),
    "advance gdp q/q": ("A191RL1Q225SBEA", "niveau", "{:.1f}%"),
}
CACHE_ANNONCE_S = 600   # le jour d'une grande annonce : FRED relu toutes les 10 min


def reels_annonces() -> dict:
    """Dernier chiffre publie pour chaque grande annonce (texte au format
    Forex Factory, ex. « 143K », « 4.1% ») et la date de la donnee."""
    sortie, deja = {}, {}
    for titre, (code, calcul, forme) in ANNONCES_REELLES.items():
        try:
            obs = deja.get(code) or _telecharger(code)
            deja[code] = obs
            if calcul == "difference":
                v = obs[-1][1] - obs[-2][1]
            elif calcul == "mensuel":
                v = (obs[-1][1] / obs[-2][1] - 1) * 100
            elif calcul == "annuel":
                v = (obs[-1][1] / obs[-13][1] - 1) * 100
            elif calcul == "milliers":
                v = obs[-1][1] / 1000
            else:
                v = obs[-1][1]
            sortie[titre] = {"valeur": forme.format(v), "date": obs[-1][0]}
        except Exception:
            continue
    return sortie


def annonce_recente(heures: float = 3.0) -> bool:
    """Une annonce americaine a fort impact est-elle tombee dans les dernieres heures ?"""
    try:
        evenements = json.loads((FICHIER.parent / "calendrier.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    maintenant = datetime.now().astimezone()
    for e in evenements:
        if str(e.get("impact", "")).lower() not in ("high", "3"):
            continue
        if str(e.get("country") or e.get("currency") or "").upper() != "USD":
            continue
        try:
            quand = datetime.fromisoformat(e["date"]).astimezone()
        except (KeyError, ValueError):
            continue
        if 0 <= (maintenant - quand).total_seconds() <= heures * 3600:
            return True
    return False

# probabilites de la prochaine decision de la Fed : marche de prediction
# Polymarket (API publique, sans cle), evenement « fed-decision-in-<mois> »
POLYMARKET = "https://gamma-api.polymarket.com/events?slug={}"
MOIS_EN = ["january", "february", "march", "april", "may", "june", "july", "august",
           "september", "october", "november", "december"]
MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
           "septembre", "octobre", "novembre", "décembre"]
DUREE_CACHE_FED_S = 3600


def _classer(question: str):
    """« Fed decreases interest rates by 25 bps… » -> ("baisse", "−25 pb")."""
    q = question.lower()
    import re as _re
    pb = _re.search(r"(\d+)\s*\+?\s*bps", q)
    taille = f"{pb.group(1)}{'+' if '+' in q.split('bps')[0][-4:] else ''} pb" if pb else ""
    if "no change" in q or "maintain" in q or "hold" in q:
        return "maintien", ""
    if "decrease" in q or "cut" in q or "lower" in q:
        return "baisse", f"−{taille}" if taille else ""
    if "increase" in q or "hike" in q or "raise" in q:
        return "hausse", f"+{taille}" if taille else ""
    return None, ""


# positions des institutions sur l'or : rapport COT de la CFTC (hebdomadaire,
# donnees du mardi publiees le vendredi), or COMEX = code 088691
COT_URL = ("https://publicreporting.cftc.gov/resource/72hh-3qpy.json?"
           "cftc_contract_market_code=088691&$order=report_date_as_yyyy_mm_dd%20DESC&$limit=160")


def cot_or() -> dict:
    """Position nette des fonds speculatifs (« managed money » : hedge funds,
    CTA) et des banques (« swap dealers ») sur les contrats a terme sur l'or,
    avec l'indice COT : ou se situe la position nette entre son minimum (0) et
    son maximum (100) sur 3 ans."""
    requete = urllib.request.Request(COT_URL, headers={"User-Agent": "GIMALY"})
    rapports = json.loads(urllib.request.urlopen(requete, timeout=30).read().decode("utf-8"))
    if not rapports:
        return {}

    def nette(r, long_, short_):
        return float(r.get(long_) or 0) - float(r.get(short_) or 0)

    fonds = [nette(r, "m_money_positions_long_all", "m_money_positions_short_all") for r in rapports]
    banques = [nette(r, "swap_positions_long_all", "swap__positions_short_all") for r in rapports]
    dernier = rapports[0]
    mini, maxi = min(fonds), max(fonds)
    indice = round((fonds[0] - mini) / (maxi - mini) * 100) if maxi > mini else 50
    variation = fonds[0] - fonds[1] if len(fonds) > 1 else 0
    variation_4 = fonds[0] - fonds[4] if len(fonds) > 4 else 0
    if indice >= 80:
        lecture = "fonds très acheteurs : position chargée, risque de prises de bénéfices"
    elif indice <= 20:
        lecture = "fonds très vendeurs : souvent proche d'un creux (rachats possibles)"
    else:
        lecture = "position des fonds dans la moyenne"
    return {"date": str(dernier.get("report_date_as_yyyy_mm_dd", ""))[:10],
            "fonds_net": int(fonds[0]), "fonds_variation": int(variation),
            "fonds_variation_4s": int(variation_4), "indice_cot": indice,
            "banques_net": int(banques[0]) if any(banques) else None,
            "interet_ouvert": int(float(dernier.get("open_interest_all") or 0)),
            "lecture": lecture,
            "tendance": ("les fonds achètent" if variation_4 > 0 else "les fonds vendent"
                         if variation_4 < 0 else "stable")}


# Plan B quand Polymarket est bloque (c'est le cas en France) : la methode du
# FedWatch de la CME, a partir du prix des contrats a terme sur le taux de la
# Fed (Fed Funds, « ZQ ») lus sur Yahoo Finance, et du taux effectif (FRED).
REUNIONS_FED = ["2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29",
                "2026-09-16", "2026-10-28", "2026-12-09",
                "2027-01-27", "2027-03-17", "2027-04-28", "2027-06-16"]
CODES_MOIS = "FGHJKMNQUVXZ"
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/{}?range=5d&interval=1d"


def fed_contrats_a_terme() -> dict:
    """Probabilites approchees de baisse / maintien / hausse a la prochaine
    reunion : taux implique par le contrat du mois qui suit la reunion,
    compare au taux effectif actuel (un ecart de 0,25 point = 100 %)."""
    from datetime import date as _d
    aujourd_hui = _d.today()
    reunion = next((_d.fromisoformat(r) for r in REUNIONS_FED if _d.fromisoformat(r) >= aujourd_hui), None)
    if reunion is None:
        raise RuntimeError("calendrier des reunions de la Fed a mettre a jour")
    mois = reunion.month % 12 + 1                      # mois qui suit la reunion
    annee = reunion.year + (1 if reunion.month == 12 else 0)
    symbole = f"ZQ{CODES_MOIS[mois - 1]}{annee % 100:02d}.CBT"
    requete = urllib.request.Request(YAHOO.format(symbole), headers={"User-Agent": "Mozilla/5.0"})
    reponse = json.loads(urllib.request.urlopen(requete, timeout=20).read().decode("utf-8"))
    prix = float(reponse["chart"]["result"][0]["meta"]["regularMarketPrice"])
    implique = 100 - prix
    effectif = _telecharger("EFFR")[-1][1]
    ecart = implique - effectif                        # en points de pourcentage
    mouvement = min(abs(ecart) / 0.25, 1.0)
    baisse = mouvement if ecart < 0 else 0.0
    hausse = mouvement if ecart > 0 else 0.0
    return {"reunion": f"{MOIS_FR[reunion.month - 1]} {reunion.year}",
            "source": f"contrats à terme {symbole}", "horodatage": time.time(),
            "maj": datetime.now().strftime("%d/%m %H:%M"),
            "baisse": round(baisse * 100, 1), "maintien": round((1 - mouvement) * 100, 1),
            "hausse": round(hausse * 100, 1),
            "detail": [{"genre": "taux implique", "taille": f"{implique:.3f} %", "proba": 0},
                       {"genre": "taux effectif", "taille": f"{effectif:.2f} %", "proba": 0}]}


# cours en direct (Yahoo Finance, quelques minutes de decalage au plus)
DIRECT = [
    ("DX-Y.NYB", "Dollar (DXY)", "", -1),
    ("^TNX", "Taux à 10 ans", "%", -1),
    ("^VIX", "Peur (VIX)", "", +1),
    ("GC=F", "Or (contrat COMEX)", "", 0),
]


def cours_direct() -> list:
    lignes = []
    for symbole, libelle, unite, sens_or in DIRECT:
        try:
            # range=1d : la « cloture precedente » est bien celle de la veille
            # (avec 5d, Yahoo donnait la cloture d'il y a 5 jours)
            url = ("https://query1.finance.yahoo.com/v8/finance/chart/"
                   f"{urllib.request.quote(symbole)}?range=1d&interval=5m")
            requete = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            meta = json.loads(urllib.request.urlopen(requete, timeout=15).read().decode("utf-8"))["chart"]["result"][0]["meta"]
            prix = float(meta["regularMarketPrice"])
            veille = float(meta.get("chartPreviousClose") or meta.get("previousClose") or prix)
        except Exception:
            continue
        if symbole == "^TNX" and prix > 20:            # ancien format : taux x 10
            prix, veille = prix / 10, veille / 10
        variation = prix - veille
        pourcent = variation / veille * 100 if veille else 0
        effet = 0 if abs(pourcent) < 0.1 else (sens_or if variation > 0 else -sens_or)
        # un taux se lit en points de base (0,01 %), pas en % de variation
        texte = (f"{variation * 100:+.0f} pb" if unite == "%" else f"{pourcent:+.2f} %")
        lignes.append({"libelle": libelle, "valeur": round(prix, 3 if unite == "%" else 2), "unite": unite,
                       "variation": round(variation, 3), "pourcent": round(pourcent, 2), "effet_or": effet,
                       "texte_variation": texte})
    return lignes


def fed_probabilites() -> dict:
    try:
        return _fed_polymarket()
    except Exception as exc_poly:
        try:
            return fed_contrats_a_terme()
        except Exception as exc_zq:
            raise RuntimeError(f"Polymarket : {exc_poly} | contrats a terme : {exc_zq!r}")


def _fed_polymarket() -> dict:
    """Probabilites (%) de baisse, maintien et hausse des taux a la prochaine
    reunion de la Fed, selon les paris sur Polymarket."""
    maintenant = datetime.now()
    derniere_erreur, essais = "", []
    for decalage in range(0, 4):
        mois = (maintenant.month - 1 + decalage) % 12
        annee = maintenant.year + (maintenant.month - 1 + decalage) // 12
        for slug in (f"fed-decision-in-{MOIS_EN[mois]}", f"fed-decision-in-{MOIS_EN[mois]}-{annee}"):
            essais.append(slug)
            try:
                requete = urllib.request.Request(POLYMARKET.format(slug), headers={"User-Agent": "GIMALY"})
                evenements = json.loads(urllib.request.urlopen(requete, timeout=20).read().decode("utf-8"))
            except Exception as exc:
                derniere_erreur = repr(exc)
                continue
            for ev in evenements if isinstance(evenements, list) else [evenements]:
                if ev.get("closed") or not ev.get("markets"):
                    continue
                totaux = {"baisse": 0.0, "maintien": 0.0, "hausse": 0.0}
                detail = []
                for m in ev["markets"]:
                    if m.get("closed"):
                        continue
                    genre, taille = _classer(m.get("question", ""))
                    try:
                        prix = json.loads(m.get("outcomePrices") or "[]")
                        oui = float(prix[0])
                    except (ValueError, IndexError, TypeError):
                        continue
                    if genre:
                        totaux[genre] += oui
                        detail.append({"genre": genre, "taille": taille, "proba": round(oui * 100, 1)})
                somme = sum(totaux.values())
                if somme <= 0:
                    continue
                return {"reunion": f"{MOIS_FR[mois]} {annee}", "source": "Polymarket",
                        "horodatage": time.time(), "maj": maintenant.strftime("%d/%m %H:%M"),
                        **{k: round(v / somme * 100, 1) for k, v in totaux.items()},
                        "detail": sorted(detail, key=lambda d: -d["proba"])}
    # rien trouve : on dit pourquoi (bloque par le reseau, ou aucun evenement ouvert)
    raise RuntimeError(derniere_erreur or f"aucun evenement ouvert parmi {', '.join(essais)}")


def _telecharger(code: str) -> list[tuple[str, float]]:
    requete = urllib.request.Request(URL.format(code), headers={"User-Agent": "GIMALY"})
    texte = urllib.request.urlopen(requete, timeout=20).read().decode("utf-8", "ignore")
    sortie = []
    for ligne in csv.reader(io.StringIO(texte)):
        if len(ligne) < 2 or not ligne[0][:1].isdigit():
            continue
        try:
            sortie.append((ligne[0], float(ligne[1])))
        except ValueError:
            continue                      # « . » = jour sans valeur
    return sortie


def _mesure(obs: list[tuple[str, float]], calcul: str):
    """(valeur, valeur precedente, date) selon le calcul demande."""
    if calcul == "glissement":
        # series mensuelles : variation sur 12 mois
        if len(obs) < 14:
            return None
        v = (obs[-1][1] / obs[-13][1] - 1) * 100
        p = (obs[-2][1] / obs[-14][1] - 1) * 100
        return round(v, 2), round(p, 2), obs[-1][0]
    if len(obs) < 2:
        return None
    # series quotidiennes : on compare a il y a environ un mois (22 seances) ;
    # series mensuelles (chomage) : a la publication precedente
    from datetime import date as _d
    ecart_jours = (_d.fromisoformat(obs[-1][0]) - _d.fromisoformat(obs[-2][0])).days
    if ecart_jours >= 25:
        reference = obs[-2][1]
    else:
        reference = obs[-23][1] if len(obs) > 23 else obs[0][1]
    return round(obs[-1][1], 2), round(reference, 2), obs[-1][0]


def _lecture(code, valeur, precedente, sens_or, valeurs):
    """Phrase courte : ce que la valeur veut dire pour l'or."""
    variation = valeur - precedente
    if abs(variation) < max(0.05, abs(precedente) * 0.005):      # bruit : considere stable
        tendance = "stable"
    else:
        tendance = "en hausse" if variation > 0 else "en baisse"
    effet = 0 if tendance == "stable" else (sens_or if variation > 0 else -sens_or)
    remarque = ""
    if code == "PCEPILFE":
        remarque = "au-dessus de la cible : la Fed reste prudente" if valeur > 2.5 else "proche de la cible"
    elif code == "DGS2" and "DFEDTARU" in valeurs:
        ecart = valeur - valeurs["DFEDTARU"]
        if ecart < -0.25:
            remarque = "sous le taux Fed : le marché attend des baisses de taux"
            effet = max(effet, 1)
        elif ecart > 0.25:
            remarque = "au-dessus du taux Fed : le marché attend des hausses"
            effet = min(effet, -1)
        else:
            remarque = "proche du taux Fed : pas de changement attendu"
    elif code == "VIXCLS":
        remarque = "peur élevée" if valeur > 25 else "marché serein" if valeur < 15 else "normal"
    return tendance, effet, remarque


def mettre_a_jour() -> dict:
    lignes, valeurs, erreurs = [], {}, []
    for code, libelle, unite, calcul, sens_or in SERIES:
        try:
            mesure = _mesure(_telecharger(code), calcul)
        except Exception as exc:
            erreurs.append(f"{code} : {exc!r}")
            continue
        if not mesure:
            continue
        valeur, precedente, date = mesure
        valeurs[code] = valeur
        lignes.append({"code": code, "libelle": libelle, "unite": unite, "valeur": valeur,
                       "precedente": precedente, "date": date, "sens_or": sens_or,
                       "comparaison": "le mois d'avant" if calcul == "glissement" else "il y a 1 mois"})
    for l in lignes:
        l["tendance"], l["effet_or"], l["remarque"] = _lecture(
            l["code"], l["valeur"], l["precedente"], l["sens_or"], valeurs)
    try:
        fed = fed_probabilites()
    except Exception as exc:
        fed = {}
        erreurs.append(f"Polymarket : {exc!r}")
    try:
        cot = cot_or()
    except Exception as exc:
        cot = {}
        erreurs.append(f"COT CFTC : {exc!r}")
    score = sum(l["effet_or"] for l in lignes)
    donnees = {"maj": datetime.now().strftime("%d/%m/%Y %H:%M"), "horodatage": time.time(),
               "lignes": lignes, "score_or": score, "erreurs": erreurs, "fed": fed, "cot": cot,
               "direct": cours_direct(), "horodatage_direct": time.time(),
               "reels": reels_annonces(),
               "maj_direct": datetime.now().strftime("%H:%M"),
               "resume": ("plutôt favorable à l'or" if score >= 2 else
                          "plutôt défavorable à l'or" if score <= -2 else "neutre pour l'or")}
    FICHIER.parent.mkdir(parents=True, exist_ok=True)
    temp = FICHIER.with_suffix(".tmp")
    temp.write_text(json.dumps(donnees, ensure_ascii=False, indent=1), encoding="utf-8")
    temp.replace(FICHIER)
    return donnees


def lire() -> dict:
    try:
        return json.loads(FICHIER.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def rafraichir_en_fond() -> None:
    """A appeler souvent : ne telecharge que si le cache a plus de 6 h, dans
    un fil a part (jamais de reseau dans le fil qui appelle)."""
    donnees = lire()
    duree = CACHE_ANNONCE_S if annonce_recente() else DUREE_CACHE_S
    complet = not donnees or time.time() - donnees.get("horodatage", 0) >= duree
    fed_seul = (not complet and time.time() - donnees.get("horodatage_direct", 0) >= DUREE_DIRECT_S)
    if not (complet or fed_seul):
        return
    if not _verrou.acquire(blocking=False):
        return

    def travail():
        try:
            if complet:
                mettre_a_jour()
            else:
                # cours en direct et probabilites de la Fed : toutes les 2 minutes
                d = lire()
                try:
                    d["fed"] = fed_probabilites() or d.get("fed", {})
                except Exception:
                    pass
                d["direct"] = cours_direct() or d.get("direct", [])
                d["horodatage_direct"] = time.time()
                d["maj_direct"] = datetime.now().strftime("%H:%M")
                temp = FICHIER.with_suffix(".tmp")
                temp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
                temp.replace(FICHIER)
        except Exception as exc:
            print(f"macro : mise a jour impossible ({exc!r})")
        finally:
            _verrou.release()
    threading.Thread(target=travail, daemon=True, name="gimaly-macro").start()


if __name__ == "__main__":
    d = mettre_a_jour()
    print(f"Macro {d['maj']} - {d['resume']} (score {d['score_or']:+d})")
    for l in d["lignes"]:
        fleche = {1: "or +", -1: "or -", 0: "     "}[max(-1, min(1, l["effet_or"]))]
        print(f"  {l['libelle']:<55} {l['valeur']:>8}{l['unite']:<2} ({l['comparaison']} : "
              f"{l['precedente']}) {l['tendance']:<9} {fleche}  {l['remarque']}")
    f = d.get("fed") or {}
    if f:
        print(f"\n  Prochaine reunion de la Fed ({f['reunion']}, {f['source']}) : baisse {f['baisse']} % | "
              f"maintien {f['maintien']} % | hausse {f['hausse']} %")
        for x in f["detail"]:
            print(f"    {x['genre']:<14} {x['taille']:<9} " + (f"{x['proba']} %" if x["proba"] else ""))
    else:
        print("\n  Probabilites de la Fed indisponibles (Polymarket injoignable ?)")
    if d.get("direct"):
        print(f"\n  En direct ({d.get('maj_direct')}) : " + " | ".join(
            f"{x['libelle']} {x['valeur']}{x['unite']} ({x.get('texte_variation', '')})" for x in d["direct"]))
    c = d.get("cot") or {}
    if c:
        print(f"\n  Institutions (COT CFTC du {c['date']}) : fonds speculatifs nets {c['fonds_net']:+,} contrats "
              f"(semaine {c['fonds_variation']:+,}, 4 semaines {c['fonds_variation_4s']:+,}) | indice COT "
              f"{c['indice_cot']}/100 | {c['tendance']} | {c['lecture']}")
    else:
        print("\n  Rapport COT indisponible")
    for e in d["erreurs"]:
        print("  erreur", e)
