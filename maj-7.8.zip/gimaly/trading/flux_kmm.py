"""Flux KMM desactive dans cette installation : le detecteur passe en MODE MT5 SEUL (signaux calcules
sur MT5 : cassures, valeurs initiales, scalps Keltner) et reessaie toutes les 5 minutes."""


def ecouter(sur_message, visible=False, arret=None):
    raise RuntimeError("flux KMM non disponible dans cette installation : mode MT5 seul")
