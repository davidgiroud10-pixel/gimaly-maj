r"""
gimaly/trading/respiration.py - G.I.M.A.L.Y
Zones de respiration du marche : apres une impulsion, le prix "respire" en
revenant sur une partie du mouvement, entre 38,2 % et 61,8 % (Fibonacci),
avant de repartir dans le sens de la tendance.

Calcul sur les bougies M1 de XAUUSD (MT5), comme ton graphique TradingView :
  1. reperer les sommets et creux (pivots de PIVOT_N bougies de chaque cote),
  2. la tendance vient de la structure (sommets et creux ascendants ou
     descendants) ; l'impulsion va du dernier creux au plus haut atteint
     depuis (haussiere), ou du dernier sommet au plus bas (baissiere),
  3. elle ne compte que si elle mesure au moins IMPULSION_ATR_MIN x l'ATR,
  4. la zone de respiration est entre 38,2 % et 61,8 % de retracement ;
     elle est invalidee si le prix est revenu au-dela de 78,6 %.

Le meme fichier calcule aussi le canal de Keltner de ton indicateur KSD
(EMA 20 des clotures, bandes a 2 x ATR 10) : fonctions keltner / evaluer_keltner.

Test sur ton MT5 :
  .\.venv\Scripts\python.exe -m gimaly.trading.respiration
"""
from __future__ import annotations

import math

PIVOT_N = 10              # bougies de chaque cote pour un sommet / creux (M1)
PIVOT_N_M15 = 5           # en M15 : 5 bougies = 1 h 15 de chaque cote
IMPULSION_ATR_MIN = 3.0   # impulsion d'au moins 3 x l'ATR(14) M1
FIB_HAUT = 0.382          # debut de la zone de respiration
FIB_BAS = 0.618           # fin de la zone
FIB_INVALIDE = 0.786      # au-dela, l'impulsion est consideree comme cassee


def _atr(bougies, n=14):
    if len(bougies) < n + 1:
        return math.nan
    tr = [max(h - l, abs(h - bougies[i - 1][3]), abs(l - bougies[i - 1][3]))
          for i, (o, h, l, c) in enumerate(bougies) if i > 0]
    atr = sum(tr[:n]) / n
    for x in tr[n:]:
        atr = (atr * (n - 1) + x) / n
    return atr


def _pivots(bougies, n):
    """Sommets et creux confirmes, en alternance (zigzag)."""
    hauts = [b[1] for b in bougies]
    bas = [b[2] for b in bougies]
    points = []
    for i in range(n, len(bougies) - n):
        if hauts[i] >= max(hauts[i - n:i]) and hauts[i] > max(hauts[i + 1:i + n + 1]):
            points.append((i, "haut", hauts[i]))
        if bas[i] <= min(bas[i - n:i]) and bas[i] < min(bas[i + 1:i + n + 1]):
            points.append((i, "bas", bas[i]))
    zigzag = []
    for p in points:
        if zigzag and zigzag[-1][1] == p[1]:
            garder_nouveau = p[2] > zigzag[-1][2] if p[1] == "haut" else p[2] < zigzag[-1][2]
            if garder_nouveau:
                zigzag[-1] = p
        else:
            zigzag.append(p)
    return zigzag


def _tendance(zigzag):
    """Structure : sommets et creux ascendants = haussiere, descendants = baissiere.
    Sinon, sens de la plus grande des deux dernieres jambes."""
    hauts = [p[2] for p in zigzag if p[1] == "haut"]
    bas = [p[2] for p in zigzag if p[1] == "bas"]
    if len(hauts) >= 2 and len(bas) >= 2:
        hh, hl = hauts[-1] > hauts[-2], bas[-1] > bas[-2]
        if hh and hl:
            return "haussiere"
        if not hh and not hl:
            return "baissiere"
    if len(zigzag) >= 3:
        a, b, c = zigzag[-3:]
        jambe1, jambe2 = b[2] - a[2], c[2] - b[2]      # signees
        plus_grande = jambe1 if abs(jambe1) > abs(jambe2) else jambe2
        return "haussiere" if plus_grande > 0 else "baissiere"
    return None


def calculer(bougies, pivot_n=PIVOT_N, impulsion_atr_min=IMPULSION_ATR_MIN):
    """bougies : liste de (open, high, low, close) fermees, la plus recente en dernier.
    Renvoie un dict decrivant la zone de respiration, ou None."""
    if len(bougies) < 3 * pivot_n:
        return None
    atr = _atr(bougies)
    zigzag = _pivots(bougies, pivot_n)
    tendance = _tendance(zigzag)
    if tendance is None or math.isnan(atr):
        return None
    prix = bougies[-1][3]
    depart_type = "bas" if tendance == "haussiere" else "haut"
    departs = [p for p in zigzag if p[1] == depart_type]
    if not departs:
        return None
    # L'impulsion part du dernier creux (ou sommet) confirme AVANT l'extreme
    # atteint depuis : si la tendance a repris apres une respiration, la
    # nouvelle impulsion part du creux de cette respiration.
    i_dep = departs[-1][0]
    for p in reversed(departs):
        i_dep = p[0]
        suite = range(i_dep, len(bougies))
        if tendance == "haussiere":
            i_ext = max(suite, key=lambda k: bougies[k][1])
        else:
            i_ext = min(suite, key=lambda k: bougies[k][2])
        if i_ext > i_dep:
            break
    prix0 = bougies[i_dep][2] if tendance == "haussiere" else bougies[i_dep][1]

    if tendance == "haussiere":
        extreme = bougies[i_ext][1]
        amplitude = extreme - prix0
        zone_haut = extreme - FIB_HAUT * amplitude
        zone_bas = extreme - FIB_BAS * amplitude
        limite = extreme - FIB_INVALIDE * amplitude
        invalide = min(b[2] for b in bougies[i_ext:]) < limite
    else:
        extreme = bougies[i_ext][2]
        amplitude = prix0 - extreme
        zone_bas = extreme + FIB_HAUT * amplitude
        zone_haut = extreme + FIB_BAS * amplitude
        limite = extreme + FIB_INVALIDE * amplitude
        invalide = max(b[1] for b in bougies[i_ext:]) > limite

    if amplitude < impulsion_atr_min * atr:
        etat = "impulsion trop faible"
    elif invalide:
        etat = "invalidee (retracement au-dela de 78,6 %)"
    elif zone_bas <= prix <= zone_haut:
        etat = "dans la zone"
    elif (tendance == "haussiere" and prix > zone_haut) or (tendance == "baissiere" and prix < zone_bas):
        etat = "pas encore atteinte"
    else:
        etat = "depassee"
    return {
        "tendance": tendance, "depart": prix0, "extreme": extreme, "amplitude": amplitude,
        "zone_haut": zone_haut, "zone_bas": zone_bas, "invalidation": limite, "atr": atr,
        "etat": etat, "valide": etat in ("dans la zone", "pas encore atteinte", "depassee"),
        "bougies_depuis_extreme": len(bougies) - 1 - i_ext,
    }


KELTNER_LONGUEUR = 20       # EMA des clotures (reglage KSD)
KELTNER_MULT = 2.0          # largeur des bandes en ATR
KELTNER_ATR = 10            # longueur de l'ATR
KELTNER_EXTREME = 0.8       # position au-dela de laquelle le prix est "a l'extreme"


def keltner(bougies, longueur=KELTNER_LONGUEUR, mult=KELTNER_MULT, n_atr=KELTNER_ATR):
    """Canal de Keltner sur des bougies fermees (open, high, low, close)."""
    if len(bougies) < max(longueur, n_atr) + 2:
        return None
    a = 2 / (longueur + 1)
    ema = bougies[0][3]
    for b in bougies[1:]:
        ema = a * b[3] + (1 - a) * ema
    atr = _atr(bougies, n_atr)
    if math.isnan(atr) or atr <= 0:
        return None
    return {"milieu": ema, "haut": ema + mult * atr, "bas": ema - mult * atr, "atr": atr,
            "position": (bougies[-1][3] - ema) / (mult * atr)}


def position_keltner(canal, prix):
    """-1 = bande basse, 0 = milieu, +1 = bande haute."""
    if not canal or prix is None or (isinstance(prix, float) and math.isnan(prix)):
        return math.nan
    return (prix - canal["milieu"]) / (canal["haut"] - canal["milieu"])


def zone_keltner(pos):
    if math.isnan(pos):
        return ""
    if pos > 1:
        return "au-dessus de la bande haute"
    if pos < -1:
        return "sous la bande basse"
    return "moitie haute" if pos >= 0 else "moitie basse"


def evaluer_keltner(canal, prix, cote):
    """(position, zone, 'oui' si le prix est a l'extreme du canal cote rebond :
    en bas pour un acheteur, en haut pour un vendeur)."""
    pos = position_keltner(canal, prix)
    if math.isnan(pos):
        return math.nan, "", ""
    extreme = (cote == "acheteur" and pos <= -KELTNER_EXTREME) or \
              (cote == "vendeur" and pos >= KELTNER_EXTREME)
    return pos, zone_keltner(pos), ("oui" if extreme else "non")


def ema(bougies, n=50):
    a = 2 / (n + 1)
    valeur = bougies[0][3]
    for b in bougies[1:]:
        valeur = a * b[3] + (1 - a) * valeur
    return valeur


def tendance_unite(bougies, pivot_n=PIVOT_N, ema_n=50):
    """Tendance d'une unite de temps : structure (sommets/creux) + position
    du prix par rapport a l'EMA. Renvoie None si pas assez de bougies."""
    if len(bougies) < max(3 * pivot_n, ema_n + 5):
        return None
    structure = _tendance(_pivots(bougies, pivot_n))
    moyenne = ema(bougies, ema_n)
    prix = bougies[-1][3]
    if structure is None:
        structure = "haussiere" if prix > moyenne else "baissiere"
    return {"tendance": structure, "ema": moyenne, "au_dessus_ema": prix > moyenne,
            "accord": (structure == "haussiere") == (prix > moyenne)}


def tendance_globale(unites):
    """unites : {"M1": {...}, "M5": {...}, ...}. Resume multi-echelle."""
    valides = {k: v for k, v in unites.items() if v}
    if not valides:
        return None
    hausse = sum(1 for v in valides.values() if v["tendance"] == "haussiere")
    total = len(valides)
    fond = [v["tendance"] for k, v in valides.items() if k in ("H1", "H4")]
    if fond and all(t == "haussiere" for t in fond):
        tendance_fond = "haussiere"
    elif fond and all(t == "baissiere" for t in fond):
        tendance_fond = "baissiere"
    else:
        tendance_fond = "mixte"
    return {"score": f"{hausse}/{total} haussiere", "hausse": hausse, "total": total,
            "fond": tendance_fond,
            "detail": {k: ("hausse" if v["tendance"] == "haussiere" else "baisse")
                       for k, v in valides.items()}}


def accord_tendance(global_, cote):
    """'oui' si le signal va dans le sens de la tendance de fond (H1 + H4)."""
    if not global_ or global_["fond"] == "mixte":
        return ""
    haussier = cote in ("acheteur", "achat")
    return "oui" if (global_["fond"] == "haussiere") == haussier else "non"


def evaluer(zone, prix, cote):
    """Pour un signal au prix XAUUSD `prix` du cote 'acheteur' ou 'vendeur' :
    renvoie (dans_la_zone, dans_le_sens_de_la_tendance) en 'oui' / 'non' / ''."""
    if not zone or prix is None or (isinstance(prix, float) and math.isnan(prix)):
        return "", ""
    dans = zone["valide"] and zone["zone_bas"] <= prix <= zone["zone_haut"]
    sens = (zone["tendance"] == "haussiere" and cote == "acheteur") or \
           (zone["tendance"] == "baissiere" and cote == "vendeur")
    return ("oui" if dans else "non"), ("oui" if sens else "non")


from gimaly.trading.symbole import symbole_or  # symbole de l'or du courtier

if __name__ == "__main__":
    import MetaTrader5 as mt5

    if not mt5.initialize():
        raise SystemExit(f"MT5 injoignable : {mt5.last_error()}")
    try:
        for nom, tf, n, piv in (("M1", mt5.TIMEFRAME_M1, 1500, PIVOT_N),
                                ("M15", mt5.TIMEFRAME_M15, 500, PIVOT_N_M15)):
            rates = mt5.copy_rates_from_pos(symbole_or(), tf, 1, n)
            if rates is None:
                print(f"{nom} : pas de donnees ({mt5.last_error()})")
                continue
            bougies = [(float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]))
                       for r in rates]
            print(f"\n=== {nom} ===")
            z = calculer(bougies, pivot_n=piv)
            if not z:
                print("Pas assez de donnees pour la respiration.")
            else:
                print(f"Tendance {z['tendance']} : impulsion {z['depart']:.2f} -> {z['extreme']:.2f} "
                      f"({z['amplitude']:.2f} $, ATR {nom} {z['atr']:.2f})")
                print(f"Zone de respiration : {z['zone_bas']:.2f} - {z['zone_haut']:.2f} "
                      f"(invalidation {z['invalidation']:.2f})")
                print(f"Prix {bougies[-1][3]:.2f} : {z['etat']}")
            k = keltner(bougies)
            if k:
                print(f"Keltner : bande basse {k['bas']:.2f} - milieu {k['milieu']:.2f} - "
                      f"bande haute {k['haut']:.2f} | prix {zone_keltner(k['position'])} ({k['position']:+.2f})")
    finally:
        mt5.shutdown()
