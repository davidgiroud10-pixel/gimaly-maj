r"""
gimaly/trading/publication.py - G.I.M.A.L.Y
Met les setups au format attendu par le bot de la winleague et les envoie sur
Telegram. Tant que `trading_publication` vaut "me", tout part dans TES
messages enregistres : rien ne touche le canal tant que tu ne l'as pas decide.

Format d'ouverture (un seul instrument, prix fermes, jamais de conditionnel) :
    SELL XAUUSD
    PE 4322.40
    SL 4326.40
    TP1 4318.40
    TP2 4314.40
    TP3 4310.40

Suivi, toujours EN REPONSE au message du trade :
    TP1 touche ✅ +40 pips | +1.0R
    BE
    SL touche ❌ -40 pips | -1R

1 $ = 10 pips sur l'or.

Test (sans rien envoyer) :
  .\.venv\Scripts\python.exe -m gimaly.trading.publication
Test avec envoi dans tes messages enregistres :
  .\.venv\Scripts\python.exe -m gimaly.trading.publication --envoyer
"""
from __future__ import annotations

import re

PIPS_PAR_DOLLAR = 10
# Mots que le lecteur de la ligue interprete comme une consigne ou qui font
# rejeter le signal (guide Bull The Bot).
INTERDITS_SETUP = ("be", "break", "vers", "si ", "peut-etre", "peut etre", "prepa", "zone",
                   "limit", "?", "securisez", "fermez", "deplacez", "prenez", "mets", "prends")
INTERDITS_SUIVI = ("deplacez", "fermez", "securisez", "prenez", "mets", "prends", "%")


def pips(distance_dollars: float) -> float:
    return abs(distance_dollars) * PIPS_PAR_DOLLAR


def verifier_setup(sens: str, symbole: str, pe: float, sl: float, tps: list) -> list:
    """Renvoie la liste des problemes. Vide = le message peut partir."""
    problemes = []
    if sens.upper() not in ("BUY", "SELL"):
        problemes.append("le sens doit etre BUY ou SELL")
    if not symbole or " " in symbole.strip():
        problemes.append("un seul instrument, sans espace")
    if not tps:
        problemes.append("au moins un TP est obligatoire")
    if not pe or not sl:
        problemes.append("PE et SL sont obligatoires")
    if pe and sl and tps:
        achat = sens.upper() == "BUY"
        if achat and sl >= pe:
            problemes.append("achat : le SL doit etre SOUS le PE")
        if not achat and sl <= pe:
            problemes.append("vente : le SL doit etre AU-DESSUS du PE")
        for i, tp in enumerate(tps, 1):
            if achat and tp <= pe:
                problemes.append(f"achat : TP{i} doit etre au-dessus du PE")
            if not achat and tp >= pe:
                problemes.append(f"vente : TP{i} doit etre sous le PE")
        ordonnes = sorted(tps, reverse=not achat)
        if list(tps) != ordonnes:
            problemes.append("les TP doivent aller du plus proche au plus loin")
    return problemes


def texte_setup(sens: str, symbole: str, pe: float, sl: float, tps: list,
                risque: float | None = None, decimales: int = 2) -> str:
    """Le message d'ouverture. `risque` = 0.5 pour un demi-risque."""
    f = lambda v: f"{v:.{decimales}f}"
    lignes = [f"{sens.upper()} {symbole.upper()}"]
    lignes.append(f"PE {f(pe)}" + (f" ({risque:.2f}%)" if risque else ""))
    lignes.append(f"SL {f(sl)}")
    for i, tp in enumerate(tps, 1):
        lignes.append(f"TP{i} {f(tp)}")
    return "\n".join(lignes)


def rapport_risque(pe: float, sl: float, tp: float) -> float:
    risque = abs(pe - sl)
    return abs(tp - pe) / risque if risque else 0.0


def texte_tp(numero: int, pe: float, sl: float, tp: float) -> str:
    return (f"TP{numero} touché ✅ +{pips(tp - pe):.0f} pips | "
            f"+{rapport_risque(pe, sl, tp):.1f}R")


def texte_be() -> str:
    """Message separe, pour que le lecteur de la ligue le voie a coup sur."""
    return "BE"


def texte_sl(pe: float, sl: float) -> str:
    return f"SL touché ❌ -{pips(pe - sl):.0f} pips | -1R"


def texte_point_mort() -> str:
    return "Sortie au point mort ➖ 0 pip | 0R"


def texte_cloture() -> str:
    """Cloture totale, TOUJOURS en reponse au signal (guide Bull The Bot :
    le verbe seul suffit en reply, aucun mot en plus)."""
    return "Fermez tout"


def texte_bilan_sortie(pe: float, sortie: float, sl_initial: float, achat: bool) -> str:
    """Resultat d'une sortie avant SL/TP. Le mot Bilan en tete fait ignorer
    le message par Bull The Bot (compte rendu, pas consigne)."""
    gain = (sortie - pe) if achat else (pe - sortie)
    risque = abs(pe - sl_initial)
    r = gain / risque if risque else 0.0
    signe = "+" if gain >= 0 else "-"
    return f"Bilan : sortie a {sortie:.2f} | {signe}{pips(gain):.0f} pips | {r:+.2f}R"


def _mots_interdits(texte: str, interdits) -> list:
    minuscule = texte.lower()
    return [mot for mot in interdits if mot in minuscule]


def controler(texte: str, suivi: bool = False) -> list:
    """Derniere verification avant envoi : mots pieges du guide."""
    problemes = _mots_interdits(texte, INTERDITS_SUIVI if suivi else INTERDITS_SETUP)
    if suivi and re.search(r"\bSL\b\s*[0-9]", texte):
        problemes.append("un prix apres SL serait lu comme un deplacement de stop")
    if not suivi and len(texte) > 800:
        problemes.append("message trop long")
    return problemes


def charger_config():
    """Recupere la config de GIMALY, quel que soit l'emplacement du module."""
    import importlib

    for chemin in ("gimaly.config", "gimaly.core.config", "config"):
        try:
            module = importlib.import_module(chemin)
        except ImportError:
            continue
        for nom in ("charger_config", "charger", "lire_config", "lire", "get_config", "Config"):
            fabrique = getattr(module, nom, None)
            if callable(fabrique):
                try:
                    return fabrique()
                except TypeError:
                    continue
        for nom in ("CONFIG", "config"):
            valeur = getattr(module, nom, None)
            if valeur is not None and not callable(valeur):
                return valeur
    return None


def publier(config, texte: str, destination: str = "me", repondre_a: int | None = None,
            suivi: bool = False) -> tuple[int, list]:
    """Envoie le message. Renvoie (identifiant du message, problemes detectes).
    Si un probleme est trouve, RIEN n'est envoye et l'identifiant vaut 0."""
    problemes = controler(texte, suivi=suivi)
    # Le message de passage au point mort est voulu : il ne doit pas etre
    # bloque par le controle des mots (il contient justement "BE").
    if texte.strip().lower().replace("é", "e") in ("be", "passez a be", "passez au be",
                                                   "sl au be", "sl a be", "fermez tout"):
        problemes = []
    if problemes:
        return 0, problemes
    from gimaly.bridges.telegram_lecture import envoyer_signal
    return envoyer_signal(config, destination, texte, repondre_a), []


if __name__ == "__main__":
    import sys

    pe, sl, tps = 4322.40, 4326.40, [4318.40, 4314.40, 4310.40]
    setup = texte_setup("SELL", "XAUUSD", pe, sl, tps, risque=0.5)
    print("--- OUVERTURE ---")
    print(setup)
    print("problemes :", verifier_setup("SELL", "XAUUSD", pe, sl, tps) or "aucun",
          "|", controler(setup) or "aucun mot piege")
    print("\n--- SUIVI (en reponse au message du trade) ---")
    for i, tp in enumerate(tps, 1):
        print(texte_tp(i, pe, sl, tp))
    print(texte_be())
    print(texte_sl(pe, sl))
    print(texte_point_mort())

    if "--envoyer" in sys.argv:
        config = charger_config()
        if config is None:
            print("\nConfig de GIMALY introuvable : envoi annule.")
        else:
            identifiant, problemes = publier(config, setup, "me")
            print("\nEnvoi :", f"message {identifiant}" if identifiant else problemes)
