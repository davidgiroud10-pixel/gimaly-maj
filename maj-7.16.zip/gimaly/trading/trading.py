﻿r"""
gimaly/trading/trading.py - G.I.M.A.L.Y
Le bot : il prend les signaux reperes par le detecteur, passe les ordres sur
MetaTrader 5 et publie le setup au format de la ligue.

Reglages par defaut (modifiables dans config.local.yaml) :
  trading_actif: false          # rien ne se passe tant que ce n'est pas true
  trading_risque: 1.0           # % du capital risque par trade
  trading_capital: 10000        # capital de reference (0 = solde reel du compte)
  trading_sl_pips: 20           # stop par defaut (20 pips = 2 $)
  trading_sl_max_pips: 70       # au-dela, le signal est refuse (prix trop loin du niveau)
  trading_tp_r: [2, 4]          # TP1 a 2R (moitie), TP2 a 4R (le reste) si aucun niveau
  trading_tp_marche: true       # viser les vrais niveaux (liquidites, VWAP, Keltner...)
  trading_tp_r_min: 1.5         # un TP place sur un niveau ne descend jamais sous ce multiple
  trading_max_jour: 3           # trades par jour au maximum
  trading_pause_perte: 0        # minutes d'attente apres un trade perdant (0 = aucune)
  trading_sens_tendance: false  # true = refuse tout signal contre la tendance de fond
  trading_note_min: 50          # note minimale du setup (0-100) pour entrer
  trading_note_min_contre: 65   # note exigee quand le signal va contre la tendance de fond
  trading_message_be: "BE"      # texte envoye au passage au point mort
  trading_perte_max_jour: 2.0   # % de perte qui arrete la journee
  trading_sessions: ["Londres", "New York"]
  trading_publication: "me"     # "me" = tes messages enregistres
  trading_magic: 770923         # signature des ordres du bot
  trading_autorise_reel: false  # securite : refuse de trader un compte reel
  trading_mode: strict          # "exploration" = prend aussi les signaux hors filtre
                                # (demo), marques dans le journal ; seuls les trades
                                # "strict" sont publies dans la ligue

Securites :
  - compte DEMO uniquement tant que trading_autorise_reel reste false ;
  - un seul trade a la fois, 3 par jour, arret a -2 % sur la journee ;
  - rien dans les 30 minutes autour d'une annonce a fort impact ;
  - le bot ne touche QUE ses propres positions (numero magique) ;
  - le fichier icebergs.stop (bouton STOP de GIMALY) l'arrete aussi.

Test a blanc, sans passer d'ordre :
  .\.venv\Scripts\python.exe -m gimaly.trading.trading
Bilan des trades du bot :
  .\.venv\Scripts\python.exe -m gimaly.trading.trading --bilan
Fermer immediatement la ou les positions du bot :
  .\.venv\Scripts\python.exe -m gimaly.trading.trading --fermer
Repartir pour la journee (remet a zero le compteur de trades et la perte) :
  .\.venv\Scripts\python.exe -m gimaly.trading.trading --reprendre
"""
from __future__ import annotations

import csv
import json
import re
from collections import deque
import math
import threading
import time
from datetime import datetime
from pathlib import Path

DOSSIER = Path.home() / "GIMALY" / "trading"
FICHIER_ORDRES = DOSSIER / "ordres.jsonl"        # signaux ecrits par le detecteur
# 05/10 : chaque signal REFUSE est suivi comme un trade « fantome » (memes
# PE / SL / TP que s'il avait ete pris) : on sait enfin ce que chaque regle
# de refus fait gagner ou perdre
FICHIER_REFUSES = DOSSIER / "trades_refuses.csv"
FICHIER_FANTOMES = DOSSIER / "fantomes_ouverts.json"
COLONNES_REFUSES = ["date", "heure", "genre", "sens", "motif", "pe", "sl", "tp", "r_objectif",
                    "issue", "R", "minutes"]
FICHIER_TRADES = DOSSIER / "trades_bot.csv"
FICHIER_ETAT = DOSSIER / "trading_etat.json"
FICHIER_REPRISE = DOSSIER / "trading_reprise.json"   # remise a zero des compteurs du jour
FICHIER_NIVEAUX = DOSSIER / "icebergs_etat.json"     # niveaux du marche, ecrits par le detecteur
FICHIER_JOURNAL = DOSSIER / "trading.log"            # ce que fait le bot, et pourquoi
MARGE_TP = 0.15                                      # $ : on vise juste avant le niveau
STOP = DOSSIER / "icebergs.stop"
from gimaly.trading.symbole import symbole_or  # symbole de l'or du courtier
SYMBOLE = symbole_or()
PIPS_PAR_DOLLAR = 10
AGE_MAX_SIGNAL = 90                              # secondes : au-dela, on laisse tomber
MAX_POSITIONS_EXPLORATION = 3                    # positions simultanees en exploration

COLONNES = ["date", "heure", "sens", "genre", "volume", "pe", "sl", "tp1", "tp2",
            "risque_pct", "raison", "message_id", "tp1_atteint", "tp2_atteint",
            "resultat", "gain_devise", "R", "resultat_ligue_pct", "note", "points",
            "filtre", "ecarts",
            # donnees du carnet et du tape au moment du signal (en observation)
            "carnet_son_cote", "carnet_en_face", "carnet_desequilibre", "gros_ordres",
            "tape_vitesse", "flux_valeurs", "valeur_initiale", "tendance_h1_accord"]

# Note de qualite du setup : ce qu'un trader regarde avant d'entrer. Chaque
# critere rapporte des points, le total est plafonne a 100.
CRITERES = (
    ("tendance de fond", 20),
    ("sur une liquidite", 15),
    ("extreme Keltner M1", 15),
    ("zone de respiration", 15),
    ("hors zone de valeur", 10),
    ("extreme Keltner M15", 10),
    ("flux dans le sens", 10),
    ("dollar favorable", 0),     # 0 depuis le 25/09 : "favorable" donnait de moins bons
                                 # resultats (icebergs et balayages), a verifier
)


def _preparer_journal():
    """Cree trades_bot.csv, ou lui ajoute les colonnes apparues depuis.

    Sans ca, un ancien fichier garde son en-tete et les nouvelles valeurs
    (note, resultat ligue) tombent dans les mauvaises colonnes."""
    if not FICHIER_TRADES.exists():
        with open(FICHIER_TRADES, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f, delimiter=";").writerow(COLONNES)
        return
    with open(FICHIER_TRADES, encoding="utf-8-sig") as f:
        lecteur = csv.DictReader(f, delimiter=";")
        entete = lecteur.fieldnames or []
        if entete == COLONNES:
            return
        lignes = list(lecteur)
    with open(FICHIER_TRADES, "w", newline="", encoding="utf-8-sig") as f:
        ecrivain = csv.DictWriter(f, fieldnames=COLONNES, delimiter=";", extrasaction="ignore")
        ecrivain.writeheader()
        ecrivain.writerows(lignes)
    journal(f"trades_bot.csv : colonnes mises a jour, {len(lignes)} trades conserves.")


OBSERVATIONS = ("carnet_son_cote", "carnet_en_face", "carnet_desequilibre", "gros_ordres",
                "tape_vitesse", "valeur_initiale", "tendance_h1_accord")


def observations(contexte):
    """Donnees du carnet et du tape au moment du signal : categories pour le
    bilan, et valeurs brutes lisibles. Elles n'entrent pas (encore) dans la
    note : on les teste d'abord sur les trades reels."""
    contexte = contexte or {}
    obs = {k: str(contexte.get(k, "") or "") for k in OBSERVATIONS}

    def v(cle):
        val = contexte.get(cle, "")
        return "?" if val in ("", None) else val

    morceaux = []
    if contexte.get("carnet_son_cote") or contexte.get("carnet_ajout_son_cote") not in (None, ""):
        morceaux.append(f"carnet son cote +{v('carnet_ajout_son_cote')}/-{v('carnet_retrait_son_cote')}, "
                        f"en face +{v('carnet_ajout_en_face')}/-{v('carnet_retrait_en_face')}")
    if contexte.get("gros_ordres"):
        morceaux.append(f"gros ordres {v('gros_son_sens')} pour / {v('gros_contre')} contre")
    if contexte.get("tape_1min") not in (None, ""):
        morceaux.append(f"tape {v('tape_1min')}/min ({contexte.get('tape_vitesse') or '?'})")
    if contexte.get("delta_5min") not in (None, ""):
        morceaux.append(f"delta 5 min {v('delta_5min')}")
    obs["flux_valeurs"] = " | ".join(morceaux)
    return obs


def texte_pourquoi(trade) -> str:
    """Explication courte de l'entree, publiee juste apres le setup. Aucun
    prix, aucun TP / SL / R : le message ne doit pas pouvoir etre lu comme un
    resultat par le classement de la ligue.

    05/10 : le texte passe le CONTROLE DE LA LIGUE (publication.controler) :
    ni « ? », ni « zone », ni « be » (meme a l'interieur d'un mot, comme
    « iceberg »), ni « si », « vers », « limit »… Avant, le titre « Pourquoi ce
    trade ? » suffisait a faire refuser le message, qui ne partait jamais.
    """
    achat = trade.get("sens") == "achat"
    obs = trade.get("observations") or {}
    raison = str(trade.get("raison", "")).lower()
    tendance = "haussière" if "tendance h1 haussiere" in raison else \
               "baissière" if "tendance h1 baissiere" in raison else ""
    if not tendance and obs.get("tendance_h1_accord") == "avec":
        tendance = "haussière" if achat else "baissière"
    sens_tendance = f" (tendance de fond H1 {tendance})" if tendance else ""
    genre = trade.get("genre", "")
    if genre == "bos_cassure":
        corps = (f"Cassure de structure en M15 (BOS) dans le sens du marché{sens_tendance}. "
                 f"Le prix vient de clôturer au-delà du dernier {'sommet' if achat else 'creux'} : "
                 f"les {'acheteurs' if achat else 'vendeurs'} reprennent la main.\n"
                 f"Protection placée derrière le dernier {'creux' if achat else 'sommet'}, "
                 f"là où le scénario serait invalidé.")
    elif genre == "vi_contre":
        corps = ("Retour du prix sur le point de départ d'une impulsion M15 (valeur initiale), "
                 "à contre-courant de la tendance H1 : ces niveaux déclenchent souvent un "
                 "rebond technique, en tendance comme en range.\n"
                 "Protection placée de l'autre côté du niveau, objectif mesuré.")
    elif genre == "scalp_vi_m5":
        corps = ("Retour du prix sur le point de départ d'une impulsion M5 (valeur initiale), "
                 "à contre-courant de la tendance H1 : ces niveaux déclenchent souvent un "
                 "rebond technique, en tendance comme en range.\n"
                 "Protection placée de l'autre côté du niveau, objectif mesuré.")
    elif genre == "scalp_keltner_large":
        corps = (f"Le prix est sorti du canal de Keltner M1 par la bande {'basse' if achat else 'haute'}, "
                 f"puis a reclôturé à l'intérieur : retour attendu en direction du centre du canal.\n"
                 f"Protection placée au-delà de la mèche, objectif mesuré.")
    elif genre == "valeur_initiale":
        corps = (f"Retour du prix sur le point de départ d'une impulsion M15 (valeur initiale), "
                 f"dans le sens du marché{sens_tendance}. Ces niveaux servent souvent d'appui "
                 f"avant que le mouvement reprenne.\n"
                 f"Protection placée de l'autre côté du niveau.")
    elif genre == "iceberg":
        corps = (f"Gros ordre caché repéré sur le marché à terme de l'or : "
                 f"un {'acheteur' if achat else 'vendeur'} défend ce niveau.")
    else:
        corps = "Signal détecté par l'analyse du flux d'ordres et de la structure du marché."
    # ni « achat / vente / buy / sell » ni « % » dans le titre : rien qui
    # ressemble a une nouvelle annonce de trade pour les lecteurs automatiques
    filtres = ("session active, aucun retracement contraire en cours" if genre in ("vi_contre", "scalp_vi_m5")
               else "session active, tendance confirmée, aucun retracement contraire en cours")
    return (f"🧠 Pourquoi ce trade\n{corps}\n"
            f"Filtres validés : {filtres}.\n"
            f"Gestion entièrement automatique par GIMALY BOT.")


def note_setup(contexte, cote="", marche=None):
    """(note sur 100, points obtenus). `contexte` = la ligne du signal,
    `marche` = session, dollar, tendance du moment."""
    contexte = contexte or {}
    marche = marche or {}
    points = []
    total = 0
    valeurs = dict(CRITERES)

    def compter(nom, condition):
        nonlocal total
        if condition and valeurs[nom] > 0:
            total += valeurs[nom]
            points.append(f"{nom} +{valeurs[nom]}")

    compter("tendance de fond",
            (marche.get("tendance_accord") or contexte.get("tendance_accord")) == "oui")
    liquidite = contexte.get("liquidite_cassee") == "oui"
    try:
        liquidite = liquidite or float(contexte.get("liq_distance", 99)) <= 2.0
    except (TypeError, ValueError):
        pass
    compter("sur une liquidite", liquidite)
    compter("extreme Keltner M1", contexte.get("keltner_extreme") == "oui"
            or contexte.get("keltner_casse") == "oui")
    compter("extreme Keltner M15", contexte.get("keltner_extreme_m15") == "oui")
    compter("zone de respiration", contexte.get("respiration") == "oui"
            or contexte.get("respiration_m15") == "oui")
    compter("hors zone de valeur",
            str(contexte.get("zone_valeur", "")).startswith(("au-dessus", "sous")))
    compter("flux dans le sens", contexte.get("flux_dans_le_sens") == "oui")
    compter("dollar favorable", contexte.get("dollar_favorable") == "oui"
            or marche.get("dollar_favorable") == "oui")
    # "reaction rapide" retiree le 25/09 : moins de 1 min etait la seule tranche
    # negative ; ces signaux ne sont d'ailleurs plus proposes au bot.
    return min(100, total), points


RACINE = Path(__file__).resolve().parents[2]      # ...\gimaly (le projet)
_YAML = {"t": 0.0, "valeurs": {}}


_YAML_SIGNALE = set()


def _lire_yaml_tolerant(yaml, fichier):
    """yaml.safe_load, mais si UNE ligne est invalide (par exemple un chemin Windows entre guillemets doubles), on lit les
    autres lignes au lieu de perdre TOUT le fichier (le bot retomberait en silence sur ses valeurs par defaut)."""
    texte = fichier.read_text(encoding="utf-8-sig")
    try:
        return yaml.safe_load(texte)
    except Exception as exc:  # noqa: BLE001
        donnees, ignorees = {}, []
        for ligne in texte.splitlines():
            if not ligne.strip() or ligne[0] in " \t#" or ":" not in ligne:
                continue
            try:
                un = yaml.safe_load(ligne)
            except Exception:  # noqa: BLE001
                ignorees.append(ligne.split(":", 1)[0])
                continue
            if isinstance(un, dict):
                donnees.update(un)
        cle = (str(fichier), tuple(ignorees))
        if cle not in _YAML_SIGNALE:
            _YAML_SIGNALE.add(cle)
            premiere = (str(exc).splitlines() or [repr(exc)])[0]
            journal(f"ALERTE {fichier.name} : ligne(s) illisible(s) ignoree(s) : {', '.join(ignorees) or '?'} ({premiere})")
        return donnees


def _yaml_local():
    """Lit config.local.yaml directement : l'objet config de GIMALY ne garde
    que les cles qu'il connait, donc les reglages ajoutes recemment n'y sont
    pas forcement."""
    if time.time() - _YAML["t"] < 30:
        return _YAML["valeurs"]
    valeurs = {}
    for nom in ("config.local.yaml", "config.yaml"):
        fichier = RACINE / nom
        if not fichier.exists():
            continue
        try:
            import yaml
            donnees = _lire_yaml_tolerant(yaml, fichier) or {}
            if isinstance(donnees, dict):
                valeurs = {**donnees, **valeurs}      # config.local.yaml prioritaire
        except Exception:
            continue
    _YAML["t"], _YAML["valeurs"] = time.time(), valeurs
    return valeurs


def journal(texte):
    """Le bot tourne dans GIMALY : sans ce journal, ses refus etaient invisibles."""
    print(f"[trading] {texte}")
    try:
        DOSSIER.mkdir(parents=True, exist_ok=True)
        with open(FICHIER_JOURNAL, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%d/%m %H:%M:%S}  {texte}\n")
    except OSError:
        pass


def _config(config):
    fichier = _yaml_local()

    def lire(nom, defaut):
        valeur = getattr(config, nom, None) if config else None
        if valeur is None:
            valeur = fichier.get(nom, defaut)
        return defaut if valeur is None else valeur
    return {
        "actif": bool(lire("trading_actif", False)),
        "risque": float(lire("trading_risque", 1.0)),
        "capital": float(lire("trading_capital", 10000)),
        "sl_pips": float(lire("trading_sl_pips", 20)),
        "sl_max_pips": float(lire("trading_sl_max_pips", 70)),
        "sl_min_pips": float(lire("trading_sl_min_pips", 15)),     # stop jamais plus court
        "lots_max": float(lire("trading_lots_max", 1.5)),          # garde-fou sur le volume
        "intervalle_ordres_s": float(lire("trading_intervalle_ordres_s", 60)),
        "ordres_par_heure": int(lire("trading_ordres_par_heure", 6)),
        "tp_r": list(lire("trading_tp_r", [2, 4])),
        "tp_marche": bool(lire("trading_tp_marche", True)),
        "tp_r_min": float(lire("trading_tp_r_min", 1.5)),
        "tp_niveau": bool(lire("trading_tp_niveau", True)),   # TP des scalps sur un niveau du marche
        "tp_niveau_r_min": float(lire("trading_tp_niveau_r_min", 1.0)),
        "max_jour": int(lire("trading_max_jour", 3)),
        "pause_perte": float(lire("trading_pause_perte", 0)),
        "sens_tendance": bool(lire("trading_sens_tendance", False)),
        "note_min": float(lire("trading_note_min", 50)),
        "note_min_contre": float(lire("trading_note_min_contre", 65)),
        "message_be": str(lire("trading_message_be", "BE")),
        "perte_max_jour": float(lire("trading_perte_max_jour", 2.0)),
        "sessions": list(lire("trading_sessions", ["Londres", "New York"])),
        "publication": str(lire("trading_publication", "me")),
        "magic": int(lire("trading_magic", 770923)),
        "autorise_reel": False,   # paquet : demo uniquement
        "mode": str(lire("trading_mode", "strict")).strip().lower(),
        # Configuration « candidate » issue du bilan du 28/09. En mode strict
        # elle decide des trades ; en exploration, elle decide seulement de
        # l'etiquette strict / exploration (le bilan compare les deux).
        "signaux": [str(x).strip().lower() for x in (lire("trading_signaux", None) or ["iceberg", "balayage"])],
        "ecarts_ignores": [str(x).strip() for x in (lire("trading_ecarts_ignores", None) or [])],
        "filtre_carnet": bool(lire("trading_filtre_carnet", False)),
        "signaux_publier": bool(lire("trading_signaux_publier", False)),
        "signaux_source": str(lire("trading_signaux_source", "fichier") or "fichier").strip().lower(),
        "signaux_canal": str(lire("trading_signaux_canal", "") or "").strip(),
        "signaux_secret": str(lire("trading_signaux_secret", "") or "").strip(),
        "explication": bool(lire("trading_explication", True)),   # 2e message « pourquoi »
        "sortie_fausse_cassure": bool(lire("trading_sortie_fausse_cassure", True)),
        "sortie_au_temps": bool(lire("trading_sortie_au_temps", True)),   # 13/10 : sortie a duree_max_min
        # seulement dans le sens de la tendance H1 (EMA 20/50) : bilan du 28/09
        "filtre_tendance_h1": bool(lire("trading_filtre_tendance_h1", False)),
        # si le 2e niveau est a moins de cet ecart (en R) du TP1 : un seul TP
        "ecart_tp_r": float(lire("trading_ecart_tp_r", 1.0)),
    }


_VALEUR_LOT = {"t": 0.0, "v": None, "exact": None, "alerte": ""}


def _valeur_par_dollar(mt5, info):
    """Gain (ou perte) d'UN lot pour 1 $ de mouvement de l'or, dans la devise du compte. Sources, de la plus sure a la
    moins sure : 1. order_calc_profit (MetaTrader calcule lui-meme) ; 2. la derniere valeur reussie de ce calcul ; 3. la
    taille du contrat (100 $ par lot pour 1 $ d'or) si le profit est dans la devise du compte. On garde la PLUS GRANDE
    (lots plus petits = plus prudent). trade_tick_value / trade_tick_size est FAUX sur certains serveurs (10 fois trop faible
    sur MetaQuotes-Demo : lots 10 fois trop gros, stop a -10 R) : on ne s'en sert JAMAIS. Sans valeur sure : None (pas de trade)."""
    if _VALEUR_LOT["v"] and time.time() - _VALEUR_LOT["t"] < 60:
        return _VALEUR_LOT["v"]
    tick_formule = info.trade_tick_value / max(info.trade_tick_size, 1e-9)
    exact = None
    try:
        tick = mt5.symbol_info_tick(SYMBOLE)
        prix = float(getattr(tick, "ask", 0) or getattr(tick, "bid", 0) or 0)
        if prix > 0:
            gain = mt5.order_calc_profit(mt5.ORDER_TYPE_BUY, SYMBOLE, 1.0, prix, prix + 1.0)
            if gain is not None and gain > 0:
                exact = float(gain)
                _VALEUR_LOT["exact"] = exact
    except Exception:  # noqa: BLE001
        exact = None
    if exact is None:
        exact = _VALEUR_LOT["exact"]                      # derniere valeur reussie
    contrat = None
    try:
        compte = mt5.account_info()
        if compte is not None and getattr(info, "currency_profit", None) == getattr(compte, "currency", None):
            contrat = float(info.trade_contract_size)
    except Exception:  # noqa: BLE001
        contrat = None
    sures = [v for v in (exact, contrat) if v and v > 0]
    if not sures:                                         # aucune valeur sure : PAS de trade (None), on reessaie au prochain
        message = "ALERTE valeur d'un lot introuvable (MetaTrader ne repond pas) : trade refuse par prudence"
        if _VALEUR_LOT["alerte"] != message:
            _VALEUR_LOT["alerte"] = message
            journal(message)
        return None
    valeur = max(sures)
    if tick_formule > 0 and abs(valeur / tick_formule - 1) > 0.05:
        message = (f"ALERTE valeur d'un lot : MetaTrader donne {tick_formule:.2f} (tick) mais la valeur sure est "
                   f"{valeur:.2f} par $ : la valeur sure est utilisee pour les lots")
        if _VALEUR_LOT["alerte"] != message:
            _VALEUR_LOT["alerte"] = message
            journal(message)
    _VALEUR_LOT["t"], _VALEUR_LOT["v"] = time.time(), valeur
    return valeur


class Bot:
    def __init__(self, config=None, mt5=None):
        self.config = config
        self.reglages = _config(config)
        self.mt5 = mt5
        self.trades = {}          # position_id -> infos du trade
        self.refus = deque(maxlen=10)
        self._position_fichier = 0
        try:
            if FICHIER_ORDRES.exists():
                self._position_fichier = FICHIER_ORDRES.stat().st_size   # ne pas rejouer l'historique
        except OSError:
            pass
        self._dernier_etat = 0.0
        DOSSIER.mkdir(parents=True, exist_ok=True)
        _preparer_journal()

    # ------------------------------------------------------------ MT5
    def _reconnecter_mt5(self) -> bool:
        """05/10 : MT5 ferme puis rouvert = le bot gardait une connexion morte
        (« MT5 déconnecté du compte » jusqu'a son redemarrage). Toutes les 30 s
        tant que la connexion est perdue : on la refait. Vrai si c'est reparti."""
        if time.time() - getattr(self, "_t_reco", 0) < 30:
            return False
        self._t_reco = time.time()
        self._essais_reco = getattr(self, "_essais_reco", 0) + 1
        ancien = self.mt5
        try:                                  # 1) reinitialiser la liaison existante
            if ancien is not None:
                try:
                    ancien.shutdown()
                except Exception:
                    pass
                if ancien.initialize():
                    infos = ancien.terminal_info()
                    if infos is not None and getattr(infos, "connected", False):
                        journal(f"MT5 reconnecte (essai {self._essais_reco})")
                        return True
        except Exception:
            pass
        try:                                  # 2) sinon : nouvelle liaison, l'ancienne est fermee
            for methode in ("fermer", "arreter", "close", "stop"):
                fermer = getattr(ancien, methode, None) if ancien is not None else None
                if callable(fermer):
                    try:
                        fermer()
                    except Exception:
                        pass
                    break
            self.mt5 = None
            infos = self._mt5().terminal_info()
            if infos is not None and getattr(infos, "connected", False):
                journal(f"MT5 reconnecte avec une nouvelle liaison (essai {self._essais_reco})")
                return True
        except Exception as exc:
            if self._essais_reco in (1, 10) or self._essais_reco % 60 == 0:
                journal(f"reconnexion MT5 impossible pour l'instant : {exc!r}")
        return False

    def _mt5(self):
        """MT5 tourne dans un processus a part (mt5_isole.py) : un appel lent
        (ordre pendant une impulsion) ne gele plus tout GIMALY."""
        if self.mt5 is not None and getattr(self.mt5, "vivant", True):
            return self.mt5
        relance = self.mt5 is not None
        try:
            from gimaly.trading.mt5_isole import MT5Isole
            self.mt5 = MT5Isole()
        except RuntimeError as exc:
            if "n'a pas demarre" not in str(exc):
                raise
            journal(f"{exc} : MT5 utilise directement (GIMALY peut geler pendant les ordres)")
            import MetaTrader5 as mt5
            if not mt5.initialize():
                raise RuntimeError(f"MT5 injoignable : {mt5.last_error()}")
            self.mt5 = mt5
        if relance:
            # un ordre a pu passer pendant la panne : on reprend ce qui est ouvert
            journal("processus MT5 relance")
            try:
                self.adopter_positions()
            except Exception as exc:
                journal(f"reprise des positions impossible : {exc!r}")
        return self.mt5

    def compte(self):
        mt5 = self._mt5()
        return mt5.account_info()

    def capital(self):
        """Capital servant de base au risque. Le solde d'un compte demo gonfle
        vite et fausserait les pourcentages publies a la ligue : on prend donc
        un capital de reference, sauf si trading_capital vaut 0."""
        reference = self.reglages["capital"]
        if reference > 0:
            return reference
        compte = self.compte()
        return compte.balance if compte else 0.0

    # ------------------------------------------------------------ verifications
    @property
    def exploration(self):
        return self.reglages.get("mode") == "exploration"

    def _filtres_rates(self, marche):
        """Filtres de marche qu'un trade d'exploration ne respecte pas."""
        r, ecarts = self.reglages, []
        if not marche:
            return ecarts
        if r["sessions"] and marche.get("session") not in r["sessions"]:
            ecarts.append("hors session")
        if r["sens_tendance"] and marche.get("tendance_accord") == "non":
            ecarts.append("contre la tendance de fond")
        return ecarts

    MAX_OUVERTES = 3      # trades du bot ouverts en meme temps (99 = pas de limite)

    def _compte_voulu(self):
        # numero du compte MT5 choisi par l'utilisateur (compte.bat), relu depuis config.local.yaml
        # (au plus toutes les 30 s) : pas de redemarrage necessaire. 0 = pas de restriction.
        try:
            return int(str(_yaml_local().get("trading_mt5_compte", 0) or 0).strip() or 0)
        except (TypeError, ValueError):
            return -1          # valeur illisible : par prudence le bot ne trade pas

    def peut_trader(self, marche=None, filtres=True):
        """Renvoie (autorise, raison). La raison explique le refus.
        filtres=False (exploration) : les securites restent (demo, perte du
        jour, annonces, STOP), seuls session et tendance ne bloquent plus."""
        r = self.reglages
        if not r["actif"]:
            return False, "trading_actif est a false"
        if STOP.exists():
            return False, "arret demande (STOP)"
        compte = self.compte()
        if compte is None:
            return False, "compte MT5 illisible"
        if compte.trade_mode != 0 and not r["autorise_reel"]:
            return False, "compte NON demo : refus (trading_autorise_reel est a false)"
        voulu = self._compte_voulu()
        if voulu < 0:
            return False, "trading_mt5_compte illisible dans config.local.yaml (compte.bat pour corriger)"
        if voulu and compte.login != voulu:
            return False, (f"MT5 est connecte au compte {compte.login}, le bot est reserve au compte "
                           f"{voulu} (compte.bat pour changer)")
        ouvertes = self.positions()
        # 21/10 : plusieurs trades en meme temps, jusqu'a MAX_OUVERTES
        if len(ouvertes) >= self.MAX_OUVERTES:
            return False, f"{len(ouvertes)} trades du bot deja en cours (max {self.MAX_OUVERTES})"
        faits, perte = self.journee()
        if faits >= r["max_jour"]:
            return False, f"{faits} trades deja pris aujourd'hui"
        if perte <= -abs(r["perte_max_jour"]) / 100 * self.capital():
            return False, f"perte du jour atteinte ({perte:.2f})"
        attente = self.pause_restante()
        if attente > 0:
            return False, f"pause apres perte : encore {attente:.0f} min"
        if marche:
            if filtres and r["sessions"] and marche.get("session") not in r["sessions"]:
                return False, f"hors sessions autorisees ({marche.get('session')})"
            if marche.get("annonce_proche") == "oui":
                return False, "annonce economique a moins de 30 min"
            if filtres and r["sens_tendance"] and marche.get("tendance_accord") == "non":
                return False, f"contre la tendance de fond ({marche.get('tendance_fond', '?')})"
        return True, "ok"

    def _decalage_serveur(self):
        """MT5 enregistre a l'heure de SON serveur, pas a celle du PC. Sans ce
        decalage, les trades du jour ne sont pas retrouves."""
        mt5 = self._mt5()
        tick = mt5.symbol_info_tick(SYMBOLE)
        if tick is None or not tick.time:
            return 0.0
        return tick.time - time.time()

    def _fenetre(self, depuis_horodatage=None):
        """(debut, fin) a l'heure du serveur, pour interroger l'historique."""
        decalage = self._decalage_serveur()
        if depuis_horodatage is None:
            minuit = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            depuis_horodatage = minuit.timestamp()
        return (datetime.fromtimestamp(depuis_horodatage + decalage),
                datetime.fromtimestamp(time.time() + decalage + 120))

    def positions(self):
        mt5 = self._mt5()
        return [p for p in (mt5.positions_get(symbol=SYMBOLE) or ())
                if p.magic == self.reglages["magic"]]

    def pause_restante(self):
        """Minutes restantes avant de pouvoir retrader apres une perte.

        Enchainer les entrees juste apres un stop est ce qui coute le plus cher :
        c'etait deja visible dans l'historique manuel (23 % de reussite)."""
        minutes = self.reglages["pause_perte"]
        if minutes <= 0:
            return 0.0
        mt5 = self._mt5()
        debut, fin = self._fenetre(time.time() - 6 * 3600)
        pertes = [d for d in (mt5.history_deals_get(debut, fin) or ())
                  if d.magic == self.reglages["magic"] and d.entry != 0 and d.profit < 0]
        if not pertes:
            return 0.0
        derniere = max(d.time for d in pertes) - self._decalage_serveur()
        return max(0.0, minutes - (time.time() - derniere) / 60)

    def depuis(self):
        """Debut de la periode comptee : minuit, ou la derniere reprise."""
        minuit = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        try:
            marque = json.loads(FICHIER_REPRISE.read_text(encoding="utf-8")).get("t", 0)
        except (OSError, ValueError):
            marque = 0
        return max(minuit, float(marque))

    def reprendre(self):
        """Remet a zero les compteurs du jour (trades pris et perte), sans
        toucher a l'historique : utile en demo pour continuer a tester."""
        DOSSIER.mkdir(parents=True, exist_ok=True)
        FICHIER_REPRISE.write_text(json.dumps({"t": time.time()}), encoding="utf-8")
        self._dernier_etat = 0.0
        self._ecrire_etat()
        return "Compteurs du jour remis a zero : le bot peut reprendre."

    def journee(self):
        """(nombre de trades pris depuis minuit ou la derniere reprise, resultat).
        L'historique des operations est lourd a lire pour MT5 : on le garde 30 s
        (avant : relu 2 fois toutes les 5 s, ce qui figeait MT5 aux heures chargees)."""
        cache = getattr(self, "_journee_cache", None)
        if cache and time.time() - cache[0] < 30:
            return cache[1]
        valeur = self._journee_mt5()
        self._journee_cache = (time.time(), valeur)
        return valeur

    def _journee_mt5(self):
        mt5 = self._mt5()
        debut, fin = self._fenetre(self.depuis())
        deals = mt5.history_deals_get(debut, fin) or ()
        miens = [d for d in deals if d.magic == self.reglages["magic"]]
        entrees = sum(1 for d in miens if d.entry == 0)
        resultat = sum(d.profit + d.commission + d.swap for d in miens)
        return entrees, resultat

    # ------------------------------------------------------------ taille
    def volume(self, distance_sl):
        """Lot correspondant au risque voulu pour cette distance de stop."""
        mt5 = self._mt5()
        info = mt5.symbol_info(SYMBOLE)
        compte = self.compte()
        if info is None or compte is None or distance_sl <= 0:
            return 0.0
        risque = self.reglages["risque"] / 100 * self.capital()
        valeur_point = _valeur_par_dollar(mt5, info)   # par lot et par $ (valeur reelle demandee a MetaTrader)
        if not valeur_point:
            return 0.0                                   # valeur d'un lot introuvable : pas de trade (voir ALERTE)
        lots = risque / (distance_sl * valeur_point)
        pas = info.volume_step or 0.01
        lots = math.floor(lots / pas) * pas
        return max(info.volume_min, min(info.volume_max, round(lots, 2)))

    # ------------------------------------------------------------ ouverture
    def ouvrir(self, sens, sl_prix=None, genre="", raison="", marche=None, contexte=None,
               ecarts=None, distant=False, distance_ref=None):
        """sens : 'achat' ou 'vente'. Renvoie (trade, message) ou (None, refus).
        ecarts : filtres du detecteur que le signal ne respecte pas (vide = strict)."""
        # filtres du detecteur que la configuration juge inutiles (ex. extreme
        # Keltner M1) : gardes dans le journal pour info, mais sans effet
        # 06/10 : mode scalping en TEST : jamais trade ni publie, suivi en fantome
        if not distant and str(genre).startswith("scalp_") and str(genre).lower() not in self.reglages["signaux"]:
            self._fantome(sens, sl_prix, genre, contexte, "test scalping")
            return None, None
        ecarts = [e for e in (ecarts or []) if e not in self.reglages["ecarts_ignores"]]
        if genre and self.reglages["signaux"] and genre.lower() not in self.reglages["signaux"]:
            ecarts.append(f"signal {genre} non retenu")
        if self.reglages["filtre_carnet"] and (contexte or {}).get("carnet_desequilibre") == "dans son sens":
            # bilan du 28/09 : carnet qui penche du cote du signal = -0,8 R / trade
            ecarts.append("carnet penche dans son sens")
        if self.reglages["filtre_tendance_h1"]:
            accord = (contexte or {}).get("tendance_h1_accord")
            if not accord and (contexte or {}).get("tendance_h1"):
                t = contexte["tendance_h1"]
                accord = "mixte" if t == "mixte" else ("avec" if (t == "haussiere") == (sens in ("achat", "acheteur", "buy")) else "contre")
            # « vi_contre » est par construction contre la tendance H1 : c'est le
            # signal lui-meme (bilan par semaine du 02/10 : positif en tendance
            # ET en range), pas un ecart
            if accord != "avec" and not (genre in ("vi_contre", "scalp_vi_m5") and accord == "contre") \
                    and genre != "scalp_keltner_large":     # 21/10 : exempte du filtre H1
                ecarts.append("pas dans le sens de la tendance H1")
        def fantome(motif_refus):
            return self._fantome(sens, sl_prix, genre, contexte, motif_refus)

        if distant:
            ecarts = []          # deja decide par l'editeur : ses filtres ne sont pas rejoues
        if ecarts and not self.exploration:
            fantome("hors filtre : " + ", ".join(ecarts))
            return None, None          # hors filtre, mode strict : ignore sans bruit
        autorise, motif = self.peut_trader(marche, filtres=not (self.exploration or distant))
        if not autorise:
            return None, f"pas de trade : {motif}{fantome(motif)}"
        cote = "acheteur" if sens in ("achat", "acheteur", "buy") else "vendeur"
        note, points = note_setup(contexte, cote, marche)
        contre = (marche or {}).get("tendance_accord") == "non"
        seuil = self.reglages["note_min_contre"] if contre else self.reglages["note_min"]
        if self.exploration:
            ecarts += self._filtres_rates(marche)
        if note < seuil and not distant:
            if not self.exploration:
                fantome(f"note {note}/100 < {seuil:.0f}")
                return None, (f"pas de trade : note {note}/100 < {seuil:.0f}"
                              f"{' (contre la tendance)' if contre else ''} "
                              f"[{', '.join(points) or 'aucun critere'}]")
            ecarts.append("note basse")
        strict = not ecarts
        mt5 = self._mt5()
        mt5.symbol_select(SYMBOLE, True)
        tick = mt5.symbol_info_tick(SYMBOLE)
        info = mt5.symbol_info(SYMBOLE)
        if tick is None or info is None:
            return None, "prix indisponible"
        achat = sens in ("achat", "acheteur", "buy")
        pe = tick.ask if achat else tick.bid
        defaut = self.reglages["sl_pips"] / PIPS_PAR_DOLLAR
        if distance_ref:
            sl = pe - float(distance_ref) if achat else pe + float(distance_ref)
        elif sl_prix is None:
            sl = pe - defaut if achat else pe + defaut
        else:
            sl = float(sl_prix)
            if (achat and sl >= pe) or (not achat and sl <= pe):
                sl = pe - defaut if achat else pe + defaut
        distance = abs(pe - sl)
        minimum = self.reglages["sl_min_pips"] / PIPS_PAR_DOLLAR
        if distance < minimum:
            # 29/09 : une vente avec un stop a 3 pips -> 4,2 lots, stop refuse par MT5
            # (trop pres du prix) et sortie a -2 R. Le stop ne descend plus sous
            # le minimum ; le volume est recalcule pour garder 1 % de risque.
            sl = pe - minimum if achat else pe + minimum
            distance = minimum
        maximum = self.reglages["sl_max_pips"] / PIPS_PAR_DOLLAR
        if (contexte or {}).get("sl_max_pips"):
            # valeur initiale M15 : la zone elle-meme fait souvent 8 a 14 $, le
            # stop est donc large par construction (le volume garde 1 % de risque)
            maximum = float(contexte["sl_max_pips"]) / PIPS_PAR_DOLLAR
        if distance > maximum:
            # le prix s'est deja trop eloigne du niveau : l'entree n'a plus de sens
            return None, (f"pas de trade : stop a {distance * PIPS_PAR_DOLLAR:.0f} pips "
                          f"(maximum {self.reglages['sl_max_pips']:.0f})")
        tp = [pe + r * distance if achat else pe - r * distance for r in self.reglages["tp_r"]]
        lots = min(self.volume(distance), self.reglages["lots_max"])
        if lots <= 0:
            return None, "volume calcule nul"
        # frein : pas plus d'un ordre par minute ni de N par heure (29/09 : MT5
        # figeait quand les signaux s'enchainaient en rafale)
        maintenant = time.time()
        envois = [t for t in getattr(self, "_envois", []) if maintenant - t < 3600]
        self._envois = envois
        if envois and maintenant - envois[-1] < self.reglages["intervalle_ordres_s"]:
            fantome("frein : un ordre par minute")
            return None, (f"pas de trade : dernier ordre il y a {maintenant - envois[-1]:.0f} s "
                          f"(minimum {self.reglages['intervalle_ordres_s']:.0f} s entre deux ordres)")
        if len(envois) >= self.reglages["ordres_par_heure"]:
            fantome("frein : ordres par heure")
            return None, f"pas de trade : deja {len(envois)} ordres dans l'heure (maximum {self.reglages['ordres_par_heure']})"
        self._envois.append(maintenant)

        demande = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": SYMBOLE, "volume": lots,
            "type": mt5.ORDER_TYPE_BUY if achat else mt5.ORDER_TYPE_SELL,
            "price": pe, "sl": round(sl, info.digits), "deviation": 20,
            "magic": self.reglages["magic"], "comment": f"GIMALY {genre}"[:31],
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": self._remplissage(info),
        }
        resultat = mt5.order_send(demande)
        if resultat is not None and resultat.retcode != mt5.TRADE_RETCODE_DONE \
                and "stop" in str(getattr(resultat, "comment", "")).lower():
            # « Invalid stops » : le prix a bouge entre la lecture et l'envoi. On
            # entre sans stop et on le pose aussitot (sinon : stop garde par le bot)
            journal(f"ordre refuse ({resultat.comment}) : nouvel envoi sans stop, pose juste apres")
            demande.pop("sl", None)
            resultat = mt5.order_send(demande)
        if resultat is None or resultat.retcode != mt5.TRADE_RETCODE_DONE:
            return None, f"ordre refuse : {getattr(resultat, 'comment', mt5.last_error())}"

        # Les TP sont recalcules sur le prix REELLEMENT obtenu, sinon les R
        # publies ne tombent pas juste (2,2R au lieu de 2R).
        pe_reel = resultat.price or pe
        # Pendant une impulsion, l'ordre peut etre execute plus loin que le prix
        # lu : avec le stop au meme niveau, la distance grandit alors que le
        # volume a ete calcule pour l'ancienne distance (pertes de -1,5 R).
        # On decale le stop pour garder exactement le risque prevu.
        if abs(pe_reel - sl) > distance * 1.05:
            sl = pe_reel - distance if achat else pe_reel + distance
            journal(f"execution a {pe_reel} au lieu de {pe} : stop decale a {sl:.2f} "
                    f"pour garder 1 R")
        distance_reelle = abs(pe_reel - sl) or distance
        tp, raisons_tp = self.objectifs(achat, pe_reel, distance_reelle)
        if (contexte or {}).get("tp_r"):
            # objectif fixe impose par le signal (valeur initiale : 2R, un seul TP)
            tp_r = float(contexte["tp_r"])
            tp = [round(pe_reel + tp_r * distance_reelle if achat else pe_reel - tp_r * distance_reelle, 2)]
            raisons_tp = [f"{tp_r:g}R"]
            if self.reglages.get("tp_niveau", True):
                # TP coherent : le niveau du marche le plus proche (comme pour le stop), meme a 1R
                choix = self.tp_sur_niveau(achat, pe_reel, distance_reelle, tp_r)
                if choix:
                    tp, raisons_tp = [choix[0]], [choix[1]]
        trade = {
            "position": resultat.order, "sens": "achat" if achat else "vente", "genre": genre,
            "pe": pe_reel, "sl": sl, "tp": tp, "volume": lots,
            "restant": lots, "raison": raison, "raisons_tp": raisons_tp,
            "note": note, "points": points, "tp_atteints": [], "message_id": 0,
            "ouvert": time.time(), "digits": info.digits,
            "ouvert_serveur": int(getattr(tick, "time", 0) or 0),
            # sortie au temps si rien n'est touche (valeur initiale : 4 h)
            # BOS : niveau casse a surveiller (sortie si fausse cassure)
            "niveau_casse": float((contexte or {}).get("niveau_casse") or 0) or None,
            "unite_casse": (contexte or {}).get("unite_casse") or "M15",
            "expire": (time.time() + float(contexte["duree_max_min"]) * 60
                       if (contexte or {}).get("duree_max_min") and self.reglages.get("sortie_au_temps", True) else None),
            "strict": strict, "ecarts": ecarts,
            "observations": observations(contexte),
            # la ligue ne recoit que les trades "strict" ; l'exploration reste
            # dans les messages enregistres
            "destination": self.reglages["publication"] if strict else "me",
        }
        # Le TP final est ecrit sur la position pour qu'il soit visible dans MT5
        # (le bot gere lui-meme le partiel au TP1 et le point mort).
        self._poser_sltp(trade["position"], sl, self._tp_mt5(achat, tp[-1]))
        trade["message_id"] = self._publier_setup(trade)
        self.trades[trade["position"]] = trade
        self._journal(trade, "ouvert")
        details = ", ".join(f"{t:.2f} ({r})" for t, r in zip(tp, raisons_tp))
        return trade, (("" if strict else f"EXPLORATION (hors filtre : {', '.join(ecarts)}) | ")
                       + f"note {note}/100 [{', '.join(points)}] | "
                       f"{trade['sens'].upper()} {lots} lot(s) a {trade['pe']:.2f}, "
                       f"SL {sl:.2f} ({distance_reelle * PIPS_PAR_DOLLAR:.0f} pips), TP {details}"
                       + (f" | {trade['observations']['flux_valeurs']}"
                          if trade["observations"].get("flux_valeurs") else ""))

    def niveaux_marche(self):
        """Niveaux lus dans l'etat du detecteur : liquidites LuxAlgo, VWAP, POC,
        zone de valeur, bandes de Keltner, zones de respiration."""
        try:
            etat = json.loads(FICHIER_NIVEAUX.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        if time.time() - etat.get("maj_ts", 0) > 300:
            return []                        # etat trop vieux : on ne s'y fie pas
        return etat.get("niveaux_xau") or []

    def tp_sur_niveau(self, achat, pe, distance, tp_r_max):
        """Signal a objectif fixe : le niveau du marche le plus proche dont le gain est compris entre
        `tp_niveau_r_min` et l'objectif fixe du signal. Renvoie (cible, nom du niveau) ou None (on garde
        alors l'objectif fixe)."""
        if distance <= 0:
            return None
        mini = self.reglages.get("tp_niveau_r_min", 1.0) * distance
        maxi = tp_r_max * distance
        meilleur = None
        for n in self.niveaux_marche():
            try:
                prix = float(n["prix"])
            except (KeyError, TypeError, ValueError):
                continue
            cible = prix - MARGE_TP if achat else prix + MARGE_TP
            gain = (cible - pe) if achat else (pe - cible)
            if gain < mini or gain > maxi:
                continue
            if meilleur is None or gain < meilleur[0]:
                meilleur = (gain, round(cible, 2), n.get("nom", "niveau"))
        return (meilleur[1], meilleur[2]) if meilleur else None

    def _contexte_publie(self, contexte, trade):
        """Contexte envoye aux amis : l'objectif en R est celui REELLEMENT pose (niveau ou fixe), pour que leur
        TP soit le meme multiple du risque que le tien."""
        if not contexte or not contexte.get("tp_r"):
            return contexte
        try:
            risque = abs(float(trade["pe"]) - float(trade["sl"]))
            gain = abs(float(trade["tp"][-1]) - float(trade["pe"]))
            if risque > 0 and gain > 0:
                return {**contexte, "tp_r": round(gain / risque, 2)}
        except (KeyError, IndexError, TypeError, ValueError):
            pass
        return contexte

    def objectifs(self, achat, pe, distance):
        """TP poses sur de vrais niveaux quand il y en a, sinon multiples du risque.
        Renvoie (liste de TP, liste de raisons)."""
        secours = [pe + r * distance if achat else pe - r * distance for r in self.reglages["tp_r"]]
        raisons = [f"{r}R" for r in self.reglages["tp_r"]]
        if not self.reglages["tp_marche"] or distance <= 0:
            return secours, raisons
        mini = self.reglages["tp_r_min"] * distance
        candidats = []
        for n in self.niveaux_marche():
            try:
                prix = float(n["prix"])
            except (KeyError, TypeError, ValueError):
                continue
            avance = (prix - pe) if achat else (pe - prix)
            if avance < mini:
                continue                     # trop proche : le rapport ne tiendrait pas
            cible = prix - MARGE_TP if achat else prix + MARGE_TP
            candidats.append((abs(cible - pe), round(cible, 2), n.get("nom", "niveau")))
        candidats.sort()
        if not candidats:
            return secours, raisons
        tp, raisons = [], []
        for _, cible, nom in candidats:
            if tp and abs(cible - tp[-1]) < 0.3 * distance:
                continue                     # deux niveaux colles : c'est le meme
            if tp and abs(cible - tp[-1]) < self.reglages["ecart_tp_r"] * distance:
                # le niveau suivant est juste derriere le TP1 : un 2e TP n'aurait
                # aucun interet (10 pips de plus), toute la position sort au TP1
                return tp, raisons
            tp.append(cible)
            raisons.append(nom)
            if len(tp) == len(self.reglages["tp_r"]):
                break
        while len(tp) < len(self.reglages["tp_r"]):
            manquant = self.reglages["tp_r"][len(tp)]
            cible = pe + manquant * distance if achat else pe - manquant * distance
            if tp and ((achat and cible <= tp[-1]) or (not achat and cible >= tp[-1])):
                cible = tp[-1] + (2 * distance if achat else -2 * distance)
            tp.append(round(cible, 2))
            raisons.append(f"{manquant}R")
        return tp, raisons

    def _remplissage(self, info):
        mt5 = self._mt5()
        mode = getattr(info, "filling_mode", 0)
        if mode & 2:
            return mt5.ORDER_FILLING_IOC
        if mode & 1:
            return mt5.ORDER_FILLING_FOK
        return mt5.ORDER_FILLING_RETURN

    # ------------------------------------------------------------ publication
    def _publier_setup(self, trade):
        from gimaly.trading.publication import texte_setup, verifier_setup, publier
        sens = "BUY" if trade["sens"] == "achat" else "SELL"
        problemes = verifier_setup(sens, SYMBOLE, trade["pe"], trade["sl"], trade["tp"])
        if problemes:
            journal(f"setup non publie : {problemes}")
            return 0
        texte = texte_setup(sens, SYMBOLE, trade["pe"], trade["sl"], trade["tp"],
                            risque=self.reglages["risque"])
        destination = trade.get("destination", self.reglages["publication"])
        identifiant, problemes = publier(self.config, texte, destination)
        if problemes:
            journal(f"publication refusee : {problemes}")
        elif identifiant and self.reglages.get("explication", True):
            # second message : pourquoi le bot est entre (sans prix ni R, pour
            # ne jamais etre pris pour une annonce de resultat par la ligue)
            try:
                _, souci = publier(self.config, texte_pourquoi(trade), destination)
                if souci:
                    journal(f"explication non publiee : {souci}")
            except Exception as exc:
                journal(f"explication non publiee : {exc!r}")
        return identifiant

    def _repondre(self, trade, texte):
        if not trade.get("message_id"):
            return
        from gimaly.trading.publication import publier
        _, problemes = publier(self.config, texte,
                               trade.get("destination", self.reglages["publication"]),
                               repondre_a=trade["message_id"], suivi=True)
        if problemes:
            journal(f"reponse refusee : {problemes}")

    # ------------------------------------------------------------ suivi
    def adopter_positions(self):
        """Apres un redemarrage de GIMALY, le bot retrouve ses positions :
        sans ca, il les voit sans les gerer (ni TP, ni point mort, ni message)."""
        for p in self.positions():
            if p.ticket in self.trades:
                continue
            achat = p.type == 0
            sl = p.sl or (p.price_open - self.reglages["sl_pips"] / PIPS_PAR_DOLLAR if achat
                          else p.price_open + self.reglages["sl_pips"] / PIPS_PAR_DOLLAR)
            distance = abs(p.price_open - sl) or self.reglages["sl_pips"] / PIPS_PAR_DOLLAR
            ligne = self._ligne_journal(p.price_open)
            if ligne:
                tp = [float(ligne[c]) for c in ("tp1", "tp2") if ligne.get(c) not in ("", None)]
                raisons = [x.strip() for x in (ligne.get("raison") or "").partition(" | TP : ")[2]
                           .split(",") if x.strip()]
                message_id = int(ligne.get("message_id") or 0)
                strict = ligne.get("filtre", "strict") != "exploration"
                try:
                    sl_initial = float(ligne["sl"])
                except (KeyError, TypeError, ValueError):
                    sl_initial = None
                ecarts = [e.strip() for e in (ligne.get("ecarts") or "").split(",") if e.strip()]
            else:
                tp, raisons = self.objectifs(achat, p.price_open, distance)
                message_id, strict, ecarts, sl_initial = 0, True, [], None
                ligne = {}
            # TP deja pris avant le redemarrage ? Le prix d'ouverture ne le dit
            # pas. Deux indices fiables : le stop deja au point mort (pose au
            # TP1) ou un volume reduit par rapport a celui du journal. Sans ca,
            # chaque redemarrage refaisait le partiel du TP1 : 0,09 -> 0,05 -> 0,03.
            try:
                volume_initial = float(ligne.get("volume") or 0) or p.volume
            except (TypeError, ValueError):
                volume_initial = p.volume
            stop_protege = (sl >= p.price_open - 0.3) if achat else (sl <= p.price_open + 0.3)
            atteints = [1] if len(tp) > 1 and (stop_protege or p.volume < volume_initial * 0.75) else []
            trade = {
                # genre, note et raison relus dans le journal : sinon le bilan
                # classait ces trades a part ("repris") et faussait les stats
                "position": p.ticket, "sens": "achat" if achat else "vente",
                "genre": ligne.get("genre") or "repris",
                "note": ligne.get("note", ""),
                "points": [x.strip() for x in (ligne.get("points") or "").split(",") if x.strip()],
                "pe": p.price_open, "sl": sl, "tp": tp, "volume": volume_initial, "restant": p.volume,
                "raison": (ligne.get("raison") or "position reprise apres redemarrage").split(" | TP : ")[0],
                "raisons_tp": raisons,
                "tp_atteints": atteints, "message_id": message_id, "ouvert": time.time(),
                # stop au point mort ou mieux (le stop du point mort peut etre
                # legerement au-dela du PE)
                "digits": 2, "sl_be": (sl >= p.price_open - 0.3) if achat else (sl <= p.price_open + 0.3),
                "strict": strict, "ecarts": ecarts, "sl_initial": sl_initial,
                "ouvert_serveur": int(getattr(p, "time", 0) or 0),
                "observations": {k: ligne.get(k, "") for k in OBSERVATIONS + ("flux_valeurs",)},
                "destination": self.reglages["publication"] if strict else "me",
            }
            self.trades[p.ticket] = trade
            if tp and not p.tp:
                self._poser_sltp(p.ticket, sl, self._tp_mt5(achat, tp[-1]))
            journal(f"position reprise : {trade['sens']} {p.volume} a {p.price_open:.2f}, "
                    f"SL {sl:.2f}, TP {', '.join(f'{t:.2f}' for t in tp)}")

    def _ligne_journal(self, pe):
        """Retrouve le trade dans trades_bot.csv (pour garder le message Telegram)."""
        for ligne in reversed(trades_termines() + self._lignes_ouvertes()):
            try:
                if abs(float(ligne["pe"]) - pe) < 0.5:
                    return ligne
            except (KeyError, TypeError, ValueError):
                continue
        return None

    @staticmethod
    def _lignes_ouvertes():
        if not FICHIER_TRADES.exists():
            return []
        with open(FICHIER_TRADES, encoding="utf-8-sig") as f:
            return [l for l in csv.DictReader(f, delimiter=";") if l.get("resultat") == "ouvert"]

    def surveiller(self):
        """A appeler regulierement : partiels aux TP, break-even, cloture."""
        self.adopter_positions()
        if not self.trades:
            self._ecrire_etat()
            return
        mt5 = self._mt5()
        ouvertes = {p.ticket: p for p in self.positions()}
        for position, trade in list(self.trades.items()):
            if position not in ouvertes:
                self._cloture(trade)
                continue
            if self._stop_garde(trade, ouvertes[position]):
                continue
            if self._fausse_cassure(trade, ouvertes[position]):
                continue
            if trade.get("expire") and time.time() > trade["expire"]:
                journal(f"{trade['sens']} ({trade['genre']}) : duree maximale atteinte, sortie au prix du marche")
                # 06/10 : annoncer la sortie a Bull The Bot (sinon les suiveurs
                # restent en position jusqu'a leur SL)
                trade["sortie_anticipee"] = "duree maximale"
                from gimaly.trading.publication import texte_cloture
                self._repondre(trade, texte_cloture())
                self._fermer_partiel(trade, ouvertes[position], tout=True)
                trade["expire"] = None
                continue
            tick = mt5.symbol_info_tick(SYMBOLE)
            if tick is None:
                continue
            # Le graphique affiche le prix vendeur (bid) : un TP « touche sur le
            # graphique » l'est au bid, pour une vente comme pour un achat. Mesure
            # a l'ask, une vente ratait son TP d'un spread (0,2 a 0,4 $), et la
            # ligue, qui lit le graphique, l'aurait compte touche.
            prix = tick.bid
            extreme = self._extreme_bid(trade)
            if extreme is not None:
                # meche de quelques secondes entre deux verifications
                prix = max(prix, extreme) if trade["sens"] == "achat" else min(prix, extreme)
            for i, cible in enumerate(trade["tp"], 1):
                if i in trade["tp_atteints"]:
                    continue
                atteint = prix >= cible if trade["sens"] == "achat" else prix <= cible
                if not atteint:
                    continue
                trade["tp_atteints"].append(i)
                dernier = i == len(trade["tp"])
                self._fermer_partiel(trade, ouvertes[position], tout=dernier)
                from gimaly.trading.publication import texte_tp
                self._repondre(trade, texte_tp(i, trade["pe"], trade.get("sl_initial") or trade["sl"], cible))
                if i == 1 and not dernier:
                    if self._deplacer_sl(ouvertes[position], trade["pe"]):
                        trade["sl_be"] = True
                        self._repondre(trade, self.reglages["message_be"])
        self._ecrire_etat()

    def _fermer_partiel(self, trade, position, tout=False):
        mt5 = self._mt5()
        info = mt5.symbol_info(SYMBOLE)
        pas = info.volume_step or 0.01
        if tout:
            volume = position.volume
        else:
            volume = math.floor((trade["volume"] / len(trade["tp"])) / pas) * pas
            volume = max(info.volume_min, min(volume, position.volume))
        tick = mt5.symbol_info_tick(SYMBOLE)
        achat = trade["sens"] == "achat"
        demande = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": SYMBOLE, "volume": round(volume, 2),
            "type": mt5.ORDER_TYPE_SELL if achat else mt5.ORDER_TYPE_BUY,
            "position": position.ticket, "price": tick.bid if achat else tick.ask,
            "deviation": 20, "magic": self.reglages["magic"], "comment": "GIMALY TP",
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": self._remplissage(info),
        }
        resultat = mt5.order_send(demande)
        if resultat is None or resultat.retcode != mt5.TRADE_RETCODE_DONE:
            journal(f"cloture partielle refusee : {getattr(resultat, 'comment', '')}")
        else:
            trade["restant"] = max(0.0, trade["restant"] - volume)

    def _tp_mt5(self, achat, tp):
        """TP ecrit sur la position MT5. Une vente se ferme a l'ask : on
        remonte son TP du spread pour qu'il se declenche quand le graphique
        (bid) touche le niveau publie."""
        if achat or not tp:
            return tp
        try:
            tick = self._mt5().symbol_info_tick(SYMBOLE)
            spread = max(0.0, tick.ask - tick.bid)
        except Exception:
            spread = 0.3
        return round(tp + spread + 0.02, 2)

    def _extreme_bid(self, trade):
        """Plus bas (vente) ou plus haut (achat) du bid sur la bougie M1 en
        cours et la precedente, depuis l'entree du trade."""
        try:
            mt5 = self._mt5()
            bougies = mt5.copy_rates_from_pos(SYMBOLE, mt5.TIMEFRAME_M1, 0, 2)
        except Exception:
            return None
        if bougies is None or len(bougies) == 0:
            return None
        # Heures du serveur des deux cotes. La bougie de l'entree est exclue :
        # sa partie d'avant l'entree pourrait faire croire a un TP touche.
        entree = trade.get("ouvert_serveur")
        if not entree:
            return None
        premiere = (int(entree) // 60 + 1) * 60
        recentes = [b for b in bougies if int(b["time"]) >= premiere]
        if not recentes:
            return None
        if trade["sens"] == "achat":
            return max(float(b["high"]) for b in recentes)
        return min(float(b["low"]) for b in recentes)

    def _deplacer_sl(self, position, prix):
        return self._poser_sltp(position.ticket, prix, position.tp)

    def _fausse_cassure(self, trade, position) -> bool:
        """BOS : si une bougie M15 close APRES l'entree revient de l'autre cote
        du niveau casse, la cassure a echoue : sortie au marche plutot que
        d'attendre le stop (02/10 : achat BOS a l'ouverture de Londres, pic a
        4198 puis retour sous le niveau, stop plein ; simule : +0,29 R au lieu
        de +0,15 R sur les BOS M15 dans le sens de la tendance)."""
        if not self.reglages.get("sortie_fausse_cassure", True) or not trade.get("niveau_casse"):
            return False
        if time.time() - trade.get("controle_cassure", 0) < 20:
            return False
        trade["controle_cassure"] = time.time()
        mt5 = self._mt5()
        unite = {"M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15}.get(trade.get("unite_casse"), mt5.TIMEFRAME_M15)
        duree = 300 if trade.get("unite_casse") == "M5" else 900
        rates = mt5.copy_rates_from_pos(SYMBOLE, unite, 1, 1)       # derniere bougie close
        if rates is None or not len(rates):
            return False
        bougie = rates[-1]
        if int(bougie["time"]) + duree <= int(trade.get("ouvert_serveur") or 0):
            return False                                           # close avant l'entree
        cloture = float(bougie["close"])
        niveau = trade["niveau_casse"]
        achat = trade["sens"] == "achat"
        if (achat and cloture < niveau) or (not achat and cloture > niveau):
            journal(f"{trade['sens']} ({trade['genre']}) : fausse cassure, cloture {trade.get('unite_casse')} "
                    f"{cloture:.2f} revenue {'sous' if achat else 'au-dessus de'} {niveau:.2f}, sortie au marche")
            trade["sortie_anticipee"] = "fausse cassure"
            from gimaly.trading.publication import texte_cloture
            self._repondre(trade, texte_cloture())
            self._fermer_partiel(trade, position, tout=True)
            trade["niveau_casse"] = None
            return True
        return False

    def _stop_garde(self, trade, position) -> bool:
        """Filet de securite : si la position n'a pas de stop dans MT5 (pose
        refuse, reprise apres une panne du programme MT5...), le bot le fait
        respecter lui-meme. Il retente de le poser, et si le prix l'a deja
        depasse, il sort au marche. Renvoie vrai s'il a ferme la position.
        Journal du 28/09 : une vente reprise sans stop a fini a -1,5 R."""
        if position.sl:
            trade.pop("stop_manquant", None)
            return False
        achat = trade["sens"] == "achat"
        stop = trade["pe"] if trade.get("sl_be") else (trade.get("sl") or 0)
        if not stop:
            return False
        tick = self._mt5().symbol_info_tick(SYMBOLE)
        if tick is None:
            return False
        prix_sortie = tick.bid if achat else tick.ask
        depasse = prix_sortie <= stop if achat else prix_sortie >= stop
        if depasse:
            journal(f"{trade['sens']} ({trade['genre']}) : stop {stop:.2f} depasse sans stop dans MT5, "
                    f"sortie au marche a {prix_sortie:.2f}")
            self._fermer_partiel(trade, position, tout=True)
            return True
        if not trade.get("stop_manquant"):
            journal(f"{trade['sens']} ({trade['genre']}) : pas de stop dans MT5, le bot le surveille "
                    f"({stop:.2f}) et retente de le poser")
            trade["stop_manquant"] = True
        if time.time() - trade.get("essai_stop", 0) >= 30:       # une tentative toutes les 30 s
            trade["essai_stop"] = time.time()
            tp = trade["tp"][-1] if trade.get("tp") else 0
            self._poser_sltp(position.ticket, stop, self._tp_mt5(achat, tp) if tp else 0)
        return False

    def _poser_sltp(self, ticket, sl, tp):
        """Ecrit le stop et l'objectif sur la position, pour qu'ils soient
        visibles dans MT5 comme pour un trade passe a la main."""
        mt5 = self._mt5()
        info = mt5.symbol_info(SYMBOLE)
        demande = {"action": mt5.TRADE_ACTION_SLTP, "symbol": SYMBOLE, "position": ticket,
                   "sl": round(float(sl), info.digits), "tp": round(float(tp or 0), info.digits)}
        resultat = mt5.order_send(demande)
        if resultat is None or resultat.retcode != mt5.TRADE_RETCODE_DONE:
            journal(f"SL/TP non poses : {getattr(resultat, 'comment', mt5.last_error())}")
            return False
        return True

    def _cloture(self, trade):
        """La position n'existe plus : on determine pourquoi et on l'annonce."""
        self._journee_cache = None
        from gimaly.trading.publication import texte_sl, texte_point_mort, texte_bilan_sortie
        mt5 = self._mt5()
        # Toutes les operations de la position, quelle que soit la date : pour
        # un trade repris apres redemarrage, la fenetre partait de la reprise
        # et oubliait les partiels deja encaisses (trade compte a 0,0).
        try:
            miens = list(mt5.history_deals_get(position=trade["position"]) or ())
        except Exception:
            miens = []
        if not miens:
            debut, fin = self._fenetre(trade["ouvert"] - 120)
            deals = mt5.history_deals_get(debut, fin) or ()
            miens = [d for d in deals if d.position_id == trade["position"]]
        gain = sum(d.profit + d.commission + d.swap for d in miens)
        self._sortie_reelle(trade, miens)
        if not trade["tp_atteints"]:
            # 21/10 : position fermee ni au stop ni par le bot = fermeture a la main (MT5) : plus
            # annoncee comme un stop loss a la ligue
            px_sortie, dist0 = trade.get("prix_sortie"), self._distance_initiale(trade)
            a_la_main = (not trade.get("sortie_anticipee") and px_sortie is not None and dist0
                         and abs(px_sortie - trade["sl"]) > 1.0 + 0.2 * dist0)
            if a_la_main:
                achat = trade["sens"] == "achat"
                try:
                    from gimaly.trading.publication import texte_cloture
                    self._repondre(trade, texte_cloture())
                except Exception:
                    pass
                self._repondre(trade, texte_bilan_sortie(trade["pe"], px_sortie,
                                                         trade.get("sl_initial") or trade["sl"], achat))
                resultat = "fermeture manuelle"
            elif trade.get("sortie_anticipee"):
                achat = trade["sens"] == "achat"
                sortie = trade.get("prix_sortie") or trade["pe"]
                self._repondre(trade, texte_bilan_sortie(trade["pe"], sortie,
                                                         trade.get("sl_initial") or trade["sl"], achat))
                ecart = (sortie - trade["pe"]) if achat else (trade["pe"] - sortie)
                resultat = "point mort" if ecart >= -0.3 else "stop loss"
            elif trade.get("sl_be"):
                self._repondre(trade, texte_point_mort())
                resultat = "point mort"
            else:
                self._repondre(trade, texte_sl(trade["pe"], trade["sl"]))
                resultat = "stop loss"
        else:
            resultat = f"TP{max(trade['tp_atteints'])}"
            # au moins un TP touche : message final avec le R total reellement obtenu
            self._repondre(trade, self._texte_final(trade, gain))
        self._journal(trade, resultat, gain)
        journal(f"trade termine : {resultat}, {gain:+.2f} "
                f"({self.resultat_ligue(trade, resultat):+.2f} % ligue)")
        self.trades.pop(trade["position"], None)

    def _sortie_reelle(self, trade, deals):
        """Le bot verifie les prix toutes les 5 s, mais MT5 ferme tout seul au
        TP final pose sur la position : un TP touche entre deux verifications
        passait inapercu (trade annonce "reste stoppe" alors qu'il etait au TP2).
        On regarde donc le prix reel de la derniere sortie."""
        sorties = sorted((d for d in deals if d.entry != 0), key=lambda d: d.time)
        if not sorties:
            return
        prix = float(sorties[-1].price)
        achat = trade["sens"] == "achat"
        from gimaly.trading.publication import texte_tp
        for i, cible in enumerate(trade["tp"], 1):
            if i in trade["tp_atteints"]:
                continue
            # une vente sort a l'ask : le prix de sortie depasse le TP du spread
            if (achat and prix >= cible - 0.05) or (not achat and prix <= cible + 0.6):
                trade["tp_atteints"].append(i)
                self._repondre(trade, texte_tp(i, trade["pe"], trade.get("sl_initial") or trade["sl"], cible))
        trade["tp_atteints"].sort()
        if len(trade["tp_atteints"]) < len(trade["tp"]):
            # reste sorti sans TP : au point mort (ou mieux) ou stoppe
            gain = (prix - trade["pe"]) if achat else (trade["pe"] - prix)
            if not trade.get("sortie_anticipee"):
                trade["sl_be"] = gain >= -0.3
        trade["prix_sortie"] = prix

    def fermer_tout(self, raison="ferme a la main"):
        """Ferme toutes les positions du bot (bouton du volet ou --fermer)."""
        mt5 = self._mt5()
        positions = self.positions()
        if not positions:
            return "Aucune position du bot a fermer."
        info = mt5.symbol_info(SYMBOLE)
        fermees = []
        for p in positions:
            tick = mt5.symbol_info_tick(SYMBOLE)
            achat = p.type == 0
            demande = {
                "action": mt5.TRADE_ACTION_DEAL, "symbol": SYMBOLE, "volume": p.volume,
                "type": mt5.ORDER_TYPE_SELL if achat else mt5.ORDER_TYPE_BUY,
                "position": p.ticket, "price": tick.bid if achat else tick.ask,
                "deviation": 30, "magic": self.reglages["magic"], "comment": "GIMALY fermeture",
                "type_time": mt5.ORDER_TIME_GTC, "type_filling": self._remplissage(info),
            }
            resultat = mt5.order_send(demande)
            if resultat is not None and resultat.retcode == mt5.TRADE_RETCODE_DONE:
                fermees.append(f"{p.volume} lot(s) a {resultat.price:.2f}")
            else:
                return f"Fermeture refusee : {getattr(resultat, 'comment', mt5.last_error())}"
        for trade in list(self.trades.values()):
            trade["tp_atteints"] = trade["tp_atteints"] or []
            self._journal(trade, raison)
            self.trades.pop(trade["position"], None)
        self._ecrire_etat()
        return "Position(s) fermee(s) : " + ", ".join(fermees)

    # ------------------------------------------------------------ journal
    def resultat_ligue(self, trade, resultat):
        """Resultat en % selon la regle de la winleague : le risque du trade est
        divise entre les TP (2 TP = moitie chacun), et chaque TP rapporte son
        propre R. Un stop coute le risque entier, une sortie au point mort ne
        rapporte rien sur la part restante."""
        risque = self.reglages["risque"]
        distance = self._distance_initiale(trade)
        if not distance:
            return 0.0
        part = risque / max(len(trade["tp"]), 1)
        total = 0.0
        for i, cible in enumerate(trade["tp"], 1):
            if i in trade["tp_atteints"]:
                total += part * abs(cible - trade["pe"]) / distance
        restants = len(trade["tp"]) - len(trade["tp_atteints"])
        if (not trade["tp_atteints"] and trade.get("prix_sortie") is not None
                and (resultat == "fermeture manuelle" or trade.get("sortie_anticipee"))):
            # 21/10 : sortie anticipee ou a la main : pourcentage proportionnel au prix de sortie reel
            ecart = ((trade["prix_sortie"] - trade["pe"]) if trade["sens"] == "achat"
                     else (trade["pe"] - trade["prix_sortie"]))
            total += risque * ecart / distance
        elif not trade["tp_atteints"] and resultat == "stop loss":
            total -= risque
        elif trade["tp_atteints"] and restants and not trade.get("sl_be"):
            # TP1 touche mais le stop n'a pas pu etre remonte : le reste a ete stoppe
            total -= part * restants
        return round(total, 3)

    @staticmethod
    def _distance_initiale(trade):
        """Distance PE-stop de depart (un trade repris apres redemarrage peut
        avoir son stop deja au point mort : on garde celui du journal)."""
        return abs(trade["pe"] - (trade.get("sl_initial") or trade["sl"]))

    def _texte_final(self, trade, gain):
        """Dernier message du trade : ce qui a ete touche et le vrai R total.
        Avec 2 TP, chaque TP porte la moitie du risque : TP1 a 2R puis sortie au
        point mort = +1R au total, TP1 et TP2 (2R et 4R) = +3R."""
        risque = self.reglages["risque"]
        distance = self._distance_initiale(trade) or 1
        morceaux = []
        for i, cible in enumerate(trade["tp"], 1):
            if i in trade["tp_atteints"]:
                morceaux.append(f"TP{i} +{abs(cible - trade['pe']) / distance:.1f}R")
        if len(trade["tp_atteints"]) < len(trade["tp"]):
            morceaux.append("reste sorti au point mort" if trade.get("sl_be") else "reste stoppé")
        theorique = self.resultat_ligue(trade, "") / risque if risque else 0.0
        texte = f"Trade terminé 🏁 {' · '.join(morceaux)} | total {theorique:+.1f}R"
        reel = gain / self._risque_pris(trade) if gain and risque else None
        if reel is not None and abs(reel - theorique) >= 0.05:
            texte += f" (réel sur le compte {reel:+.2f}R)"
        return texte

    def _risque_pris(self, trade):
        """Argent risque sur CE trade = lot x distance du stop x valeur du point (comme dans volume()).
        Secours : risque% x solde (ancienne formule) si MT5 ne repond pas."""
        try:
            info = self._mt5().symbol_info(SYMBOLE)
            valeur_point = _valeur_par_dollar(self._mt5(), info)
            risque = float(trade["volume"]) * abs(float(trade["pe"]) - float(trade["sl"])) * valeur_point
            if risque > 0:
                return risque
        except Exception:  # noqa: BLE001
            pass
        return max(self.reglages["risque"] / 100 * max(self.capital(), 1), 1e-9)

    def _journal(self, trade, resultat, gain=0.0):
        maintenant = datetime.now()
        distance = abs(trade["pe"] - trade["sl"]) or 1
        ligne = {
            "date": maintenant.strftime("%d/%m/%Y"), "heure": maintenant.strftime("%H:%M:%S"),
            "sens": trade["sens"], "genre": trade["genre"], "volume": trade["volume"],
            "pe": round(trade["pe"], 2), "sl": round(trade["sl"], 2),
            "tp1": round(trade["tp"][0], 2),
            "tp2": round(trade["tp"][1], 2) if len(trade["tp"]) > 1 else "",
            "risque_pct": self.reglages["risque"],
            "raison": (trade["raison"] + " | TP : " + ", ".join(trade.get("raisons_tp", [])))[:250],
            "message_id": trade["message_id"],
            "tp1_atteint": "oui" if 1 in trade["tp_atteints"] else "non",
            "tp2_atteint": "oui" if 2 in trade["tp_atteints"] else "non",
            "resultat": resultat, "gain_devise": round(gain, 2),
            "resultat_ligue_pct": self.resultat_ligue(trade, resultat),
            "note": trade.get("note", ""), "points": ", ".join(trade.get("points", []))[:200],
            "filtre": "strict" if trade.get("strict", True) else "exploration",
            **(trade.get("observations") or {}),
            "ecarts": ", ".join(trade.get("ecarts", [])),
            "R": round(gain / self._risque_pris(trade), 2) if gain else "",
        }
        with open(FICHIER_TRADES, "a", newline="", encoding="utf-8-sig") as f:
            csv.DictWriter(f, fieldnames=COLONNES, delimiter=";").writerow(ligne)

    def _ecrire_etat(self):
        if time.time() - self._dernier_etat < 5:
            return
        self._dernier_etat = time.time()
        try:
            faits, resultat = self.journee()
        except Exception as exc:
            faits, resultat = 0, 0.0
            journal(f"journee illisible : {exc!r}")
        # MT5 pret a trader ? (29/09 : bouton Algo Trading coupe apres un
        # redemarrage de MT5, ordre refuse sans que personne ne le voie)
        mt5_alerte = ""
        try:
            infos = self._mt5().terminal_info()
            if infos is None or not getattr(infos, "connected", True):
                mt5_alerte = "MT5 déconnecté du compte"
            elif not getattr(infos, "trade_allowed", True):
                mt5_alerte = "trading automatique désactivé dans MT5 (bouton Algo Trading)"
        except Exception:
            mt5_alerte = "MT5 injoignable"
        if mt5_alerte and mt5_alerte != getattr(self, "_derniere_alerte", ""):
            journal(f"ALERTE : {mt5_alerte}")
        if mt5_alerte in ("MT5 déconnecté du compte", "MT5 injoignable"):
            if self._reconnecter_mt5():
                mt5_alerte = ""
        elif not mt5_alerte and getattr(self, "_derniere_alerte", "") and getattr(self, "_essais_reco", 0):
            journal("MT5 de nouveau connecté")
            self._essais_reco = 0
        self._derniere_alerte = mt5_alerte
        etat = {"maj": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                "mt5_alerte": mt5_alerte,
                "actif": self.reglages["actif"], "trades_du_jour": faits,
                "resultat_du_jour": round(resultat, 2),
                # sans `marche` : la session et les annonces sont verifiees au
                # moment du signal, pas ici
                "attente": self.peut_trader()[1],
                "pause_perte_min": round(self.pause_restante()),
                "refus": list(self.refus)[::-1],
                "en_cours": [{"sens": t["sens"], "pe": round(t["pe"], 2),
                              "sl": round(t["sl"], 2), "tp": [round(x, 2) for x in t["tp"]],
                              "tp_atteints": t["tp_atteints"], "genre": t["genre"],
                              "ouvert": round(t.get("ouvert", 0)), "note": t.get("note", ""),
                              "points": t.get("points", []),
                              "filtre": "strict" if t.get("strict", True) else "exploration",
                              "ecarts": t.get("ecarts", [])}
                             for t in self.trades.values()],
                "reglages": self.reglages}
        try:
            FICHIER_ETAT.write_text(json.dumps(etat, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass

    # ------------------------------------------------- trades refuses (fantomes)
    def _niveaux(self, sens, sl_prix, contexte):
        """PE / SL / TP exactement comme `ouvrir` les aurait poses (sans ordre)."""
        mt5 = self._mt5()
        tick = mt5.symbol_info_tick(SYMBOLE)
        if tick is None:
            return None
        achat = sens in ("achat", "acheteur", "buy")
        pe = tick.ask if achat else tick.bid
        defaut = self.reglages["sl_pips"] / PIPS_PAR_DOLLAR
        sl = float(sl_prix) if sl_prix is not None else (pe - defaut if achat else pe + defaut)
        if (achat and sl >= pe) or (not achat and sl <= pe):
            sl = pe - defaut if achat else pe + defaut
        distance = abs(pe - sl)
        minimum = self.reglages["sl_min_pips"] / PIPS_PAR_DOLLAR
        if distance < minimum:
            sl, distance = (pe - minimum if achat else pe + minimum), minimum
        maximum = float((contexte or {}).get("sl_max_pips") or self.reglages["sl_max_pips"]) / PIPS_PAR_DOLLAR
        if distance > maximum:
            return None                     # aurait de toute facon ete refuse
        r_objectif = float((contexte or {}).get("tp_r") or max(self.reglages["tp_r"]))
        tp = pe + r_objectif * distance if achat else pe - r_objectif * distance
        return achat, round(pe, 2), round(sl, 2), round(tp, 2), r_objectif

    def _fantome(self, sens, sl_prix, genre, contexte, motif) -> str:
        """Enregistre le signal refuse comme trade fantome ; renvoie un rappel
        « aurait ete : SL … TP … » pour le message de refus. Jamais bloquant."""
        try:
            niveaux = self._niveaux(sens, sl_prix, contexte)
            if niveaux is None:
                return ""
            achat, pe, sl, tp, r_objectif = niveaux
            fantomes = self._charger_fantomes()
            maintenant = time.time()
            for f in fantomes:                # un meme signal repete : un seul fantome
                if f["genre"] == genre and f["achat"] == achat and abs(f["pe"] - pe) < 1.0 \
                        and maintenant - f["t"] < 900:
                    return f" | aurait ete : SL {sl:.2f}, TP {tp:.2f}"
            duree = (contexte or {}).get("duree_max_min")
            fantomes.append({"t": maintenant, "genre": genre, "achat": achat, "motif": str(motif)[:160],
                             "pe": pe, "sl": sl, "tp": tp, "r_objectif": r_objectif,
                             "expire": maintenant + float(duree) * 60 if duree else maintenant + 8 * 3600})
            self._sauver_fantomes(fantomes)
            return f" | aurait ete : SL {sl:.2f}, TP {tp:.2f}"
        except Exception as exc:
            journal(f"fantome non enregistre : {exc!r}")
            return ""

    def _charger_fantomes(self) -> list:
        try:
            return json.loads(FICHIER_FANTOMES.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def _sauver_fantomes(self, fantomes: list) -> None:
        temp = FICHIER_FANTOMES.with_suffix(".tmp")
        temp.write_text(json.dumps(fantomes), encoding="utf-8")
        temp.replace(FICHIER_FANTOMES)

    def suivre_fantomes(self):
        """Toutes les 30 s : chaque fantome est rejoue sur les bougies M1 depuis
        son entree (le stop d'abord si stop et objectif tombent dans la meme
        bougie, comme dans les bilans). Resultat ecrit dans trades_refuses.csv."""
        if time.time() - getattr(self, "_t_fantomes", 0) < 30:
            return
        self._t_fantomes = time.time()
        fantomes = self._charger_fantomes()
        if not fantomes:
            return
        mt5 = self._mt5()
        restants, termines = [], []
        maintenant = time.time()
        # heures du serveur MT5 (decalees) : meme conversion que _fenetre()
        decalage = self._decalage_serveur()
        for f in fantomes:
            barres = mt5.copy_rates_range(SYMBOLE, mt5.TIMEFRAME_M1,
                                          datetime.fromtimestamp(f["t"] - 120 + decalage),
                                          datetime.fromtimestamp(maintenant + decalage + 120))
            issue, r = None, None
            risque = abs(f["pe"] - f["sl"]) or 1e-9
            for b in (barres if barres is not None else []):
                if int(b["time"]) - decalage + 60 <= f["t"]:
                    continue                  # bougie close avant l'entree
                haut, bas = float(b["high"]), float(b["low"])
                stop = bas <= f["sl"] if f["achat"] else haut >= f["sl"]
                objectif = haut >= f["tp"] if f["achat"] else bas <= f["tp"]
                if stop:
                    issue, r = "stop", -1.0
                    break
                if objectif:
                    issue, r = "objectif", f["r_objectif"]
                    break
            if issue is None and maintenant >= f["expire"]:
                tick = mt5.symbol_info_tick(SYMBOLE)
                if tick is not None:
                    prix = tick.bid if f["achat"] else tick.ask
                    issue = "duree max"
                    r = round(((prix - f["pe"]) if f["achat"] else (f["pe"] - prix)) / risque, 2)
            if issue is None:
                restants.append(f)
            else:
                termines.append((f, issue, r))
        if not termines:
            return
        self._sauver_fantomes(restants)
        nouveau = not FICHIER_REFUSES.exists()
        with open(FICHIER_REFUSES, "a", newline="", encoding="utf-8-sig") as sortie:
            ecrivain = csv.DictWriter(sortie, fieldnames=COLONNES_REFUSES, delimiter=";")
            if nouveau:
                ecrivain.writeheader()
            for f, issue, r in termines:
                debut = datetime.fromtimestamp(f["t"])
                ecrivain.writerow({"date": debut.strftime("%d/%m/%Y"), "heure": debut.strftime("%H:%M:%S"),
                                   "genre": f["genre"], "sens": "achat" if f["achat"] else "vente",
                                   "motif": f["motif"], "pe": f["pe"], "sl": f["sl"], "tp": f["tp"],
                                   "r_objectif": f["r_objectif"], "issue": issue, "R": r,
                                   "minutes": round((maintenant - f["t"]) / 60)})
                journal(f"trade refuse {f['genre']} {'achat' if f['achat'] else 'vente'} "
                        f"({f['motif'][:60]}) : {issue}, {r:+.2f} R")

    # ------------------------------------------------------------ boucle
    def _publier_signal(self, signal, trade):
        """Editeur : publie le signal ACCEPTE (strict) pour les bots des amis, avec la DISTANCE du stop
        (aucun prix absolu a rejouer). Ne doit jamais gener le bot."""
        try:
            r = self.reglages
            if not r.get("signaux_publier") or not trade.get("strict", True):
                return
            if not r.get("signaux_canal") or not r.get("signaux_secret"):
                return
            from gimaly.trading import signaux_distants as sd
            sd.publier_en_fond({
                "sens": signal.get("sens", ""), "genre": signal.get("genre", ""),
                "raison": signal.get("raison", ""), "marche": signal.get("marche"),
                "contexte": self._contexte_publie(signal.get("contexte"), trade), "ecarts": signal.get("ecarts") or [],
                "sl_dist": round(abs(float(trade["pe"]) - float(trade["sl"])), 2),
                "pe_ref": trade["pe"], "t_signal": signal.get("t"),
            }, r["signaux_canal"], r["signaux_secret"], journal=journal)
        except Exception as exc:  # noqa: BLE001 - la publication ne doit jamais gener le bot
            journal(f"signaux partages : erreur ignoree {exc!r}")

    def _traiter_signaux_distants(self):
        """Ami : les signaux viennent du canal de l'editeur (signes, recents, sans doublon). Ses filtres ne
        sont pas rejoues : seuls le capital, la distance du stop et les securites locales s'appliquent."""
        rec = self.__dict__.get("_recepteur")
        if rec is None:
            canal, secret = self.reglages.get("signaux_canal"), self.reglages.get("signaux_secret")
            if not canal or not secret:
                if not self.__dict__.get("_signaux_alerte"):
                    journal("source distante : canal ou secret manquant dans la configuration")
                    self._signaux_alerte = True
                return
            from gimaly.trading import signaux_distants as sd
            rec = self._recepteur = sd.Recepteur(canal, secret, journal=journal)
            rec.demarrer()
            journal("source distante : ecoute des signaux de l'editeur")
        signaux = rec.recuperer()
        if (DOSSIER / "icebergs.stop").exists():
            return          # PAUSE du panneau : les signaux recus pendant la pause sont ignores
        for p in signaux:
            trade, message = self.ouvrir(
                p.get("sens", ""), sl_prix=None, genre=p.get("genre", ""), raison=p.get("raison", ""),
                marche=p.get("marche"), contexte=p.get("contexte"), ecarts=p.get("ecarts"),
                distant=True, distance_ref=p.get("sl_dist"))
            if message is None:
                continue
            journal(f"{p.get('sens', '')} ({p.get('genre', '')}) : {message}")
            if trade is None:
                self.refus.append({"heure": datetime.now().strftime("%H:%M:%S"),
                                   "ts": round(time.time()), "prix": None, "sens": p.get("sens", ""),
                                   "genre": p.get("genre", ""), "motif": message})

    def traiter_signaux(self):
        """Lit les signaux ecrits par le detecteur et ouvre s'ils sont valables."""
        if self.reglages.get("signaux_source") == "distant":
            return self._traiter_signaux_distants()
        if not FICHIER_ORDRES.exists():
            return
        try:
            with open(FICHIER_ORDRES, encoding="utf-8") as f:
                f.seek(self._position_fichier)
                lignes = f.readlines()
                self._position_fichier = f.tell()
        except OSError:
            return
        for ligne in lignes:
            try:
                signal = json.loads(ligne)
            except ValueError:
                continue
            if time.time() - signal.get("t", 0) > AGE_MAX_SIGNAL:
                continue          # signal trop vieux : le prix a deja bouge
            _cle = (signal.get("sens"), signal.get("genre"), signal.get("sl"))
            _vus = self.__dict__.setdefault("_signaux_vus", {})
            if time.time() - _vus.get(_cle, 0) < 600:
                continue          # meme signal deja traite (emis deux fois par le detecteur)
            _vus[_cle] = time.time()
            trade, message = self.ouvrir(
                signal.get("sens", ""), sl_prix=signal.get("sl"),
                genre=signal.get("genre", ""), raison=signal.get("raison", ""),
                marche=signal.get("marche"), contexte=signal.get("contexte"),
                ecarts=signal.get("ecarts"))
            if message is None:
                continue          # hors filtre en mode strict : rien a signaler
            journal(f"{signal.get('sens', '')} ({signal.get('genre', '')}) : {message}")
            if trade is not None:
                self._publier_signal(signal, trade)
            if trade is None:
                self.refus.append({"heure": datetime.now().strftime("%H:%M:%S"),
                                   "ts": round(time.time()),
                                   "prix": (signal.get("contexte") or {}).get("prix_xau"),
                                   "sens": signal.get("sens", ""),
                                   "genre": signal.get("genre", ""), "motif": message})

    def boucle(self, pause=5.0, arret=None):
        """Tourne en continu : signaux puis suivi des positions."""
        import traceback
        deja_vues = {}           # erreur -> derniere fois ecrite dans le journal
        while not (arret and arret()):
            try:
                self.traiter_signaux()
                self.surveiller()
                try:
                    self.suivre_fantomes()
                except Exception as exc:          # le suivi des fantomes ne gene jamais le trading
                    journal(f"suivi des trades refuses : {exc!r}")
                try:
                    from gimaly.trading import strategie_poc
                    strategie_poc.suivre(self)       # simulation POC : jamais d'ordre, inactive sans drapeau
                except Exception as exc:          # ne gene jamais le trading
                    journal(f"simulation POC : {exc!r}")
                self._ecrire_etat()
            except Exception as exc:
                # Une meme erreur toutes les 5 s noyait le journal sans dire
                # d'ou elle venait : on l'ecrit une fois (avec la ligne fautive)
                # puis au plus toutes les 10 minutes.
                cle = repr(exc)
                if time.time() - deja_vues.get(cle, 0) > 600:
                    deja_vues[cle] = time.time()
                    lieu = traceback.extract_tb(exc.__traceback__)
                    trace = " <- ".join(f"{f.name}:{f.lineno}" for f in reversed(lieu[-4:]))
                    journal(f"erreur : {cle} [{trace}]")
            time.sleep(pause)

    def demarrer_en_thread(self):
        # même verrou que le bot du moteur (--boucle) : jamais deux bots en même
        # temps, quelle que soit la façon dont ils ont été lancés
        import socket
        self._verrou = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self._verrou.bind(("127.0.0.1", 47822))
        except OSError:
            journal("bot NON démarré dans GIMALY : un autre bot tourne déjà (moteur ?)")
            raise RuntimeError("un autre bot tourne déjà (moteur GIMALY v2)")
        fil = threading.Thread(target=self.boucle, daemon=True, name="gimaly-trading")
        fil.start()
        return fil


def trades_termines():
    """Les trades du bot deja clotures, lus dans trades_bot.csv."""
    if not FICHIER_TRADES.exists():
        return []
    with open(FICHIER_TRADES, encoding="utf-8-sig") as f:
        return [l for l in csv.DictReader(f, delimiter=";")
                if l.get("resultat") not in ("", "ouvert", None)]


def bilan():
    """Resultats du bot : ce qu'il a pris, et ce que ca a donne."""
    lignes = trades_termines()
    if not lignes:
        print("BILAN DU BOT : aucun trade termine pour l'instant.")
        return

    def nombre(x):
        try:
            return float(str(x).replace(",", "."))
        except (TypeError, ValueError):
            return None

    def bloc(titre, groupe):
        n = len(groupe)
        if not n:
            return
        gains = [v for v in (nombre(l["gain_devise"]) for l in groupe) if v is not None]
        r = [v for v in (nombre(l["R"]) for l in groupe) if v is not None]
        ligue = [v for v in (nombre(l.get("resultat_ligue_pct")) for l in groupe) if v is not None]
        notes = [v for v in (nombre(l.get("note")) for l in groupe) if v is not None]
        tp1 = sum(1 for l in groupe if l["tp1_atteint"] == "oui")
        tp2 = sum(1 for l in groupe if l["tp2_atteint"] == "oui")
        stops = sum(1 for l in groupe if l["resultat"] == "stop loss")
        morts = sum(1 for l in groupe if l["resultat"] == "point mort")
        total = sum(gains)
        print(f"  {titre:<30} {n:>3} trades | TP1 {100 * tp1 / n:5.1f} % | TP2 {100 * tp2 / n:5.1f} % | "
              f"stop {100 * stops / n:5.1f} % | point mort {100 * morts / n:5.1f} % | "
              f"total {total:+9.2f} | moyenne {total / n:+7.2f} | "
              f"R cumule {sum(r):+6.2f} | ligue {sum(ligue):+6.2f} % "
              f"({(sum(ligue) / len(ligue)) if ligue else 0:+5.2f} % / trade) | "
              f"note moy {(sum(notes) / len(notes)) if notes else 0:5.1f}")

    print(f"BILAN DU BOT - {len(lignes)} trades termines")
    print("(R = multiple du risque ; ligue = resultat en % selon la regle winleague :")
    print(" le risque est reparti entre les TP, chaque TP rapporte son propre R)\n")
    bloc("Tous", lignes)
    groupes = {}
    for l in lignes:
        for cle, valeur in (("sens", l.get("sens")), ("signal", l.get("genre")),
                            ("resultat", l.get("resultat")), ("jour", l.get("date")),
                            ("filtre", l.get("filtre")),
                            ("carnet son cote", l.get("carnet_son_cote")),
                            ("carnet en face", l.get("carnet_en_face")),
                            ("carnet desequilibre", l.get("carnet_desequilibre")),
                            ("gros ordres", l.get("gros_ordres")),
                            ("tape", l.get("tape_vitesse")),
                            ("valeur initiale", l.get("valeur_initiale")),
                            ("tendance H1", l.get("tendance_h1_accord"))):
            if valeur:
                groupes.setdefault(f"{cle} : {valeur}", []).append(l)
        # chaque filtre rate, pour savoir lequel coute ou rapporte vraiment
        for ecart in filter(None, (e.strip() for e in (l.get("ecarts") or "").split(","))):
            groupes.setdefault(f"hors filtre : {ecart}", []).append(l)
    for cle in sorted(groupes):
        bloc(cle, groupes[cle])
    print("\nDERNIERS TRADES")
    for l in lignes[-10:]:
        print(f"  {l['date']} {l['heure']} {l['sens']:<6} ({l['genre']:<9}) PE {l['pe']:<9} "
              f"SL {l['sl']:<9} -> {l['resultat']:<12} {l['gain_devise']:>9} "
              f"({l['R']} R)  {l['raison'][:60]}")


def proposer(sens, sl=None, genre="", raison="", marche=None, contexte=None, ecarts=None):
    """Appele par le detecteur : depose un signal que le bot lira.
    ecarts : filtres que le signal ne respecte pas (vide = signal strict)."""
    DOSSIER.mkdir(parents=True, exist_ok=True)
    with open(FICHIER_ORDRES, "a", encoding="utf-8") as f:
        f.write(json.dumps({"t": time.time(), "sens": sens, "sl": sl, "genre": genre,
                            "raison": raison, "marche": marche, "contexte": contexte,
                            "ecarts": ecarts or []},
                           ensure_ascii=False) + "\n")


def est_actif(config=None) -> bool:
    """Le bot doit-il demarrer ? (lu dans la config ou dans config.local.yaml)"""
    return _config(config)["actif"]


if __name__ == "__main__":
    import sys

    if "--bilan" in sys.argv:
        bilan()
        raise SystemExit

    if "--reprendre" in sys.argv:
        from gimaly.trading.publication import charger_config as _cc
        print(Bot(_cc()).reprendre())
        raise SystemExit

    if "--refuses" in sys.argv:
        # bilan des trades refuses : ce que chaque regle de refus a fait gagner ou perdre
        try:
            with open(FICHIER_REFUSES, encoding="utf-8-sig") as f:
                lignes = list(csv.DictReader(f, delimiter=";"))
        except OSError:
            print("Aucun trade refuse termine pour l'instant.")
            raise SystemExit
        groupes = {}
        for l in lignes:
            motif = re.sub(r"\d+\.\d+|\b\d{2,}\b", "#", l.get("motif", ""))[:70]   # « H1 » reste lisible
            for cle in (f"{l.get('genre')} | {motif}", f"TOUS | {motif}"):
                groupes.setdefault(cle, []).append(float(l.get("R") or 0))
        print(f"TRADES REFUSES TERMINES : {len(lignes)} (s'ils avaient ete pris)\n")
        print(f"  {'signal | motif du refus':<85}{'cas':>5}{'gagnants':>10}{'total':>10}{'moyenne':>10}")
        for cle, rs in sorted(groupes.items(), key=lambda x: (not x[0].startswith("TOUS"), -len(x[1]))):
            gagnants = sum(1 for r in rs if r > 0)
            print(f"  {cle:<85}{len(rs):>5}{gagnants:>10}{sum(rs):>+9.2f}R{sum(rs) / len(rs):>+9.2f}R")
        raise SystemExit

    if "--fermer" in sys.argv:
        from gimaly.trading.publication import charger_config as _cc
        print(Bot(_cc()).fermer_tout())
        raise SystemExit

    if "--boucle" in sys.argv:
        # GIMALY v2 (étape 7B) : le bot tourne dans son propre processus, lancé et
        # surveillé par le moteur, au lieu de vivre dans la fenêtre GIMALY.
        # Un seul bot à la fois (verrou par port local) ; arrêt par le fichier bot.stop.
        import os
        import socket

        verrou = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            verrou.bind(("127.0.0.1", 47822))
        except OSError:
            print("Un bot tourne déjà : ce lancement est annulé.")
            raise SystemExit(1)
        racine = Path(__file__).resolve().parents[2]
        try:                                   # identifiants (Telegram, clés) du fichier .env
            for _ligne in (racine / ".env").read_text(encoding="utf-8").splitlines():
                if _ligne.strip() and not _ligne.strip().startswith("#") and "=" in _ligne:
                    _cle, _val = _ligne.split("=", 1)
                    os.environ.setdefault(_cle.strip(), _val.strip().strip('"').strip("'"))
        except OSError:
            pass
        # session Telegram dédiée au bot (voir telegram_lecture._client) : la
        # fenêtre GIMALY garde « gimaly.session », le bot du moteur « gimaly_bot.session »
        os.environ.setdefault("GIMALY_TELEGRAM_SESSION", "gimaly_bot")
        ARRET_BOT = DOSSIER / "bot.stop"
        ARRET_BOT.unlink(missing_ok=True)
        from gimaly.trading.publication import charger_config as _cc
        bot = Bot(_cc())
        journal("bot lancé dans son propre processus (moteur GIMALY v2)")
        try:
            bot.boucle(arret=ARRET_BOT.exists)
        finally:
            journal("bot arrêté (processus du moteur)")
        raise SystemExit

    from gimaly.trading.publication import charger_config

    bot = Bot(charger_config())
    print("Reglages :", bot.reglages)
    try:
        compte = bot.compte()
        print(f"Compte ...{str(compte.login)[-3:]} | {compte.server} | "
              f"{'DEMO' if compte.trade_mode == 0 else 'REEL'} | solde {compte.balance:.2f}")
        print(f"Capital de reference : {bot.capital():.2f} "
              f"({'trading_capital' if bot.reglages['capital'] > 0 else 'solde du compte'}) | "
              f"risque {bot.reglages['risque']} % = {bot.reglages['risque'] / 100 * bot.capital():.2f}")
        autorise, motif = bot.peut_trader({"session": "Londres", "annonce_proche": "non"})
        print("Peut trader :", autorise, "-", motif)
        distance = bot.reglages["sl_pips"] / PIPS_PAR_DOLLAR
        print(f"Volume pour un stop de {bot.reglages['sl_pips']:.0f} pips : "
              f"{bot.volume(distance)} lot(s)")
        faits, resultat = bot.journee()
        print(f"Aujourd'hui : {faits} trade(s) du bot, resultat {resultat:+.2f}")
    except Exception as exc:
        print("Erreur :", exc)
