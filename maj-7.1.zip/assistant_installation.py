"""Assistant d'installation GIMALY Trading : te guide etape par etape (lance par installer.bat)."""
import os
import re
import subprocess
import sys
import time
from pathlib import Path

RACINE = Path(__file__).resolve().parent
CONFIG = RACINE / "config.local.yaml"
DOSSIER = Path.home() / "GIMALY" / "trading"
TOTAL = 6


def titre(n, texte):
    print("\n" + "=" * 62)
    print(f"  ETAPE {n}/{TOTAL} : {texte}")
    print("=" * 62)


def attendre(message="Appuie sur ENTREE quand c'est fait (ou tape Q puis ENTREE pour quitter) : "):
    if input(message).strip().lower() == "q":
        print("\nInstallation interrompue. Tu pourras la reprendre en relancant installer.bat.")
        raise SystemExit(1)


def oui_non(question, defaut=True):
    reponse = input(f"{question} [{'O/n' if defaut else 'o/N'}] ").strip().lower()
    return defaut if not reponse else reponse.startswith(("o", "y"))


def regler(cle, valeur):
    """Change la valeur d'une ligne `cle: valeur  # commentaire` de config.local.yaml sans toucher au reste."""
    texte = CONFIG.read_text(encoding="utf-8")
    motif = re.compile(rf"^({re.escape(cle)}:[ \t]*)([^#\n]*?)([ \t]*(?:#.*)?)$", re.M)
    if not motif.search(texte):
        texte = texte.rstrip("\n") + f"\n{cle}: {valeur}\n"
    else:
        texte = motif.sub(lambda m: f"{m.group(1)}{valeur}{m.group(3) if m.group(3).strip() else ''}", texte, count=1)
    CONFIG.write_text(texte, encoding="utf-8")


def connexion_mt5():
    import MetaTrader5 as mt5
    if not mt5.initialize():
        return mt5, None, f"MetaTrader 5 est injoignable ({mt5.last_error()})"
    compte = mt5.account_info()
    if compte is None:
        mt5.shutdown()
        return mt5, None, "MetaTrader 5 est ouvert mais aucun compte n'est connecte"
    return mt5, compte, ""


def etape_mt5():
    titre(1, "MetaTrader 5 et compte DEMO")
    print("Ouvre MetaTrader 5 et connecte-toi a un compte DEMO.")
    print("(Menu Fichier > Ouvrir un compte > choisis ton courtier > compte demo.)")
    print("Puis clique sur le bouton 'Algo Trading' en haut : il doit devenir VERT.\n")
    while True:
        attendre("Appuie sur ENTREE quand MetaTrader 5 est ouvert et connecte : ")
        mt5, compte, probleme = connexion_mt5()
        if compte is None:
            print(f"\n  [PROBLEME] {probleme}.")
            print("  -> Ouvre MetaTrader 5, connecte-toi, puis recommence.")
            continue
        if compte.trade_mode != 0:
            mt5.shutdown()
            print(f"\n  [PROBLEME] Le compte {compte.login} sur {compte.server} n'est PAS un compte demo.")
            print("  -> Ce programme ne tourne que sur demo. Dans MT5 : Fichier > Ouvrir un compte > compte DEMO.")
            continue
        terminal = mt5.terminal_info()
        if terminal is not None and not terminal.trade_allowed:
            mt5.shutdown()
            print("\n  [PROBLEME] Le bouton 'Algo Trading' n'est pas vert.")
            print("  -> Clique dessus dans MT5 (barre du haut) jusqu'a ce qu'il soit vert.")
            continue
        print(f"\n  [OK] Compte DEMO {compte.login} sur {compte.server}, Algo Trading actif.")
        return mt5, compte


def etape_or(mt5):
    titre(2, "Recherche de l'or chez ton courtier")
    sys.path.insert(0, str(RACINE))
    from gimaly.trading import symbole as sym
    while True:
        actuel = sym.lire()
        if actuel and mt5.symbol_info(actuel) is not None:
            nom = actuel                                  # deja memorise et valide
        else:
            trouves = sym.detecter(mt5)
            nom = None
            if len(trouves) == 1:
                nom = trouves[0]
            elif len(trouves) > 1:
                print("  Plusieurs symboles de l'or existent chez ton courtier :")
                for i, n in enumerate(trouves[:6], 1):
                    print(f"    {i}) {n}")
                rep = input(f"  Lequel utiliser ? [1 = {trouves[0]}, le plus courant] : ").strip()
                if rep.isdigit() and 1 <= int(rep) <= len(trouves[:6]):
                    nom = trouves[int(rep) - 1]
                else:
                    nom = trouves[0]
            if nom is None:
                print("  [PROBLEME] Aucun symbole de l'or trouve automatiquement.")
                print("  Dans MT5, ouvre 'Market Watch' (Ctrl+M), clic droit > Symboles, cherche 'XAU' ou 'Gold'.")
                saisie = input("  Si tu connais son nom exact, tape-le ici (sinon Entree pour reessayer) : ").strip()
                if saisie and mt5.symbol_info(saisie) is not None:
                    nom = saisie
                elif saisie:
                    print(f"  '{saisie}' n'existe pas chez ton courtier.")
            if nom is None:
                if not oui_non("  Reessayer ?"):
                    print("\nInstallation interrompue : pas d'or chez ce courtier.")
                    raise SystemExit(1)
                continue
            sym.ecrire(nom)
        mt5.symbol_select(nom, True)
        info = mt5.symbol_info(nom)
        print(f"  [OK] L'or s'appelle {nom} chez ton courtier (spread {info.spread} points, lot min {info.volume_min}).")
        return


def etape_reglages(compte):
    titre(3, "Reglages (automatiques)")
    print(f"Solde de ton compte demo : {round(float(compte.balance), 2)} {compte.currency}")
    print("Le bot lit ton solde lui-meme : les lots s'adaptent a ton capital et suivent ses variations.")
    regler("trading_capital", 0)
    regler("trading_risque", "1.0")
    regler("trading_actif", "true")
    try:
        import urllib.request
        urllib.request.urlopen("https://ntfy.sh/v1/health", timeout=10).read()
        print("  [OK] Le relais des signaux est joignable.")
    except Exception as exc:
        print(f"  [ATTENTION] Relais des signaux injoignable ({exc}). Verifie ta connexion Internet et ton pare-feu.")
    print("\n  [OK] Rien d'autre a regler : le bot recoit les signaux et trade tout seul sur ton compte DEMO.")
    return True


def raccourcis():
    titre(4, "Raccourcis sur le bureau")
    if os.name != "nt":
        print("  (ignore : Windows seulement)")
        return
    if not oui_non("Creer les raccourcis 'GIMALY Panneau' et 'GIMALY Bilan' sur le bureau ?"):
        return
    script = (
        "$bureau=[Environment]::GetFolderPath('Desktop');$sh=New-Object -ComObject WScript.Shell;"
        + "".join(
            f"$s=$sh.CreateShortcut(\"$bureau\\\\GIMALY {nom}.lnk\");$s.TargetPath='{RACINE / f}';"
            f"$s.WorkingDirectory='{RACINE}';$s.Save();"
            for nom, f in (("Panneau", "panneau.bat"), ("Bilan", "bilan.bat"))))
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", script], check=True, capture_output=True, timeout=60)
        print("  [OK] Raccourcis crees sur le bureau.")
    except Exception as e:
        print(f"  Les raccourcis n'ont pas pu etre crees ({e}). Pas grave : utilise les fichiers .bat du dossier.")


def autre_bot_actif():
    """True si un bot GIMALY tourne deja sur ce PC (hors de ce dossier) : un 2e bot trade en double sur le meme compte."""
    if os.name != "nt":
        return False
    commande = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*gimaly.trading.trading*' "
                "-and $_.CommandLine -notlike '*" + RACINE.name + "*' } | Measure-Object | Select-Object -ExpandProperty Count")
    try:
        sortie = subprocess.run(["powershell", "-NoProfile", "-Command", commande], capture_output=True,
                                text=True, timeout=30).stdout.strip()
        return sortie.isdigit() and int(sortie) > 0
    except Exception:
        return False


def demarrage_auto():
    """Demarrage avec Windows : un petit fichier .bat dans le dossier Demarrage (aucune droit special)."""
    titre(5, "Demarrage automatique")
    if os.name != "nt":
        print("  (ignore : Windows seulement)")
        return
    if not oui_non("Lancer le bot automatiquement a l'ouverture de Windows (conseille) ?"):
        return
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    if not pythonw.exists():
        pythonw = Path(sys.executable)
    dossier = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    try:
        dossier.mkdir(parents=True, exist_ok=True)
        (dossier / "GIMALY Trading.bat").write_text(
            f'@echo off\r\ncd /d "{RACINE}"\r\nstart "" "{pythonw}" "{RACINE / "lancer.py"}"\r\n', encoding="utf-8")
        print("  [OK] Le bot demarrera tout seul a chaque ouverture de Windows (MetaTrader 5 doit etre ouvert).")
    except OSError as e:
        print(f"  Impossible de creer le demarrage automatique ({e}). Pas grave : le panneau peut lancer le bot.")


def fin(trade_direct):
    titre(6, "C'est pret")
    DOSSIER.mkdir(parents=True, exist_ok=True)
    (DOSSIER / "installation_ok.txt").write_text(time.strftime("%d/%m/%Y %H:%M"), encoding="utf-8")
    print("L'installation est terminee. Tu n'as plus rien a regler.\n")
    print("Le bot recoit les signaux de l'editeur et trade tout seul sur ton compte DEMO.")
    print("Il suffit que MetaTrader 5 soit ouvert, connecte a ton compte demo, avec Algo Trading en vert.")
    print("Le panneau (raccourci du bureau) montre l'etat. PAUSE / REPRENDRE coupe ou reprend les nouveaux trades.")
    if autre_bot_actif():
        print("\n  ATTENTION : un autre bot GIMALY tourne deja sur ce PC. Ne le lance pas en double :")
        print("  deux bots sur le meme compte tradent en double.")
    else:
        python = Path(sys.executable).with_name("python.exe")
        options = (subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS) if os.name == "nt" else 0
        subprocess.Popen([str(python if python.exists() else sys.executable), str(RACINE / "lancer.py")],
                         cwd=str(RACINE), creationflags=options, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, close_fds=True)
        print("\n  Le bot demarre maintenant.")
    input("\nAppuie sur ENTREE pour fermer cet assistant. ")


def main():
    print("\n" + "#" * 62)
    print("#   GIMALY TRADING - assistant d'installation".ljust(61) + "#")
    print("#" * 62)
    print("\nCet assistant te guide en 6 etapes (environ 5 minutes).")
    print("Programme experimental, COMPTE DEMO UNIQUEMENT, aucun gain garanti.")
    if not oui_non("\nAs-tu compris et veux-tu continuer ?"):
        raise SystemExit(0)
    mt5, compte = etape_mt5()
    etape_or(mt5)
    direct = etape_reglages(compte)
    try:
        mt5.shutdown()
    except Exception:
        pass
    raccourcis()
    demarrage_auto()
    fin(direct)


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nInstallation interrompue.")
