"""Panneau GIMALY Trading : l'etat du bot en un coup d'oeil + boutons DEMARRER / PAUSE-REPRISE / ARRETER.
Aucune installation de plus : tkinter est fourni avec Python. Ce panneau ne passe aucun ordre."""
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

RACINE = Path(__file__).resolve().parent
DOSSIER = Path.home() / "GIMALY" / "trading"
STOP_TRADES = DOSSIER / "icebergs.stop"
STOP_LANCEUR = DOSSIER / "lanceur.stop"
VIVANT = DOSSIER / "lanceur_vivant.txt"
CONFIG = RACINE / "config.local.yaml"
RAFRAICHIR_MS = 3000


def _symbole():
    try:
        m = re.search(r"^trading_symbole:[ \t]*([^#\n]*)", CONFIG.read_text(encoding="utf-8"), re.M)
        v = m.group(1).strip().strip("'\"") if m else ""
        return v if v and v.lower() != "auto" else "XAUUSD"
    except OSError:
        return "XAUUSD"

mt5_etat = {"erreur": "connexion en cours...", "t": 0}


# ------------------------------------------------------------------ donnees (sans interface)
def lanceur_actif():
    try:
        return time.time() - float(VIVANT.read_text(encoding="utf-8").strip()) < 60
    except (OSError, ValueError):
        return False


def trading_actif():
    try:
        m = re.search(r"^trading_actif:\s*(\w+)", CONFIG.read_text(encoding="utf-8"), re.M)
        return not (m and m.group(1).lower() in ("false", "no", "non", "0"))
    except OSError:
        return True


def lire_mt5():
    try:
        import MetaTrader5 as mt5
    except ImportError:
        return {"erreur": "MetaTrader5 n'est pas installe", "t": time.time()}
    if not mt5.initialize():
        return {"erreur": "MetaTrader 5 injoignable : ouvre-le et connecte-toi", "t": time.time()}
    try:
        compte = mt5.account_info()
        if compte is None:
            return {"erreur": "aucun compte connecte dans MetaTrader 5", "t": time.time()}
        positions = mt5.positions_get(symbol=_symbole()) or ()
        return {"erreur": "", "t": time.time(), "demo": compte.trade_mode == 0, "login": compte.login,
                "solde": compte.balance, "equity": compte.equity, "devise": compte.currency,
                "positions": len(positions), "flottant": sum(p.profit for p in positions)}
    except Exception as exc:
        return {"erreur": f"lecture MT5 impossible : {exc}", "t": time.time()}
    finally:
        mt5.shutdown()


def boucle_mt5():
    global mt5_etat
    while True:
        mt5_etat = lire_mt5()
        time.sleep(6)


def trades_du_jour():
    """(termines aujourd'hui, ouverts, derniers trades) d'apres trades_bot.csv ; listes vides si rien."""
    try:
        import bilan_reel
        debut = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        tous = sorted(bilan_reel.charger(datetime(2000, 1, 1)), key=lambda t: t["ouv"])
        jour = [t for t in tous if t["ouv"] >= debut]
        finis = [t for t in jour if t["R"] is not None]
        ouverts = [t for t in tous if t["R"] is None and t["ouv"] >= debut]
        return finis, ouverts, tous[-8:][::-1]
    except Exception:
        return [], [], []


def etat_bot():
    """(texte, couleur) de l'etat principal."""
    if not lanceur_actif():
        return "BOT ARRETE", "#8a96a3"
    if STOP_TRADES.exists():
        return "EN PAUSE : aucun nouveau trade", "#f0a030"
    if not trading_actif():
        return "OBSERVATION : aucun ordre passe", "#4aa8ff"
    return "ACTIF", "#34d27b"


def autre_bot_actif():
    if os.name != "nt":
        return False
    commande = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*gimaly.trading.trading*' "
                "-and $_.CommandLine -notlike '*" + RACINE.name + "*' } | Measure-Object | "
                "Select-Object -ExpandProperty Count")
    try:
        sortie = subprocess.run(["powershell", "-NoProfile", "-Command", commande], capture_output=True,
                                text=True, timeout=30).stdout.strip()
        return sortie.isdigit() and int(sortie) > 0
    except Exception:
        return False


# ------------------------------------------------------------------ actions
def demarrer():
    if lanceur_actif():
        return "Le bot est deja en marche."
    if mt5_etat.get("erreur"):
        return "MetaTrader 5 n'est pas pret : " + mt5_etat["erreur"]
    if mt5_etat.get("demo") is False:
        return "Compte REEL detecte : ce programme ne tourne que sur un compte DEMO."
    if autre_bot_actif():
        return "Un autre bot GIMALY tourne deja sur ce PC : arrete-le d'abord pour ne pas trader en double."
    python = Path(sys.executable).with_name("python.exe")
    if not python.exists():
        python = Path(sys.executable)
    options = (subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS) if os.name == "nt" else 0
    DOSSIER.mkdir(parents=True, exist_ok=True)
    subprocess.Popen([str(python), str(RACINE / "lancer.py")], cwd=str(RACINE), creationflags=options,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, close_fds=True)
    return "Demarrage du bot..."


def basculer_pause():
    DOSSIER.mkdir(parents=True, exist_ok=True)
    if STOP_TRADES.exists():
        STOP_TRADES.unlink()
        return "Bot repris : il peut de nouveau prendre des trades."
    STOP_TRADES.write_text("stop", encoding="utf-8")
    return "Bot en pause : plus aucun nouveau trade. Les trades ouverts gardent leur SL et leur TP."


def arreter_tout():
    DOSSIER.mkdir(parents=True, exist_ok=True)
    STOP_LANCEUR.write_text("stop", encoding="utf-8")
    return "Arret du bot demande. Les trades ouverts restent ouverts avec leur SL et leur TP."


# ------------------------------------------------------------------ interface
def main():
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk
    except ImportError:
        print("tkinter n'est pas disponible avec cette installation de Python.")
        raise SystemExit(1)

    fond, carte, texte, doux = "#0b1118", "#121c27", "#e6edf3", "#8a96a3"
    fen = tk.Tk()
    fen.title("GIMALY Trading")
    fen.configure(bg=fond)
    fen.geometry("560x620")
    fen.minsize(520, 560)

    def label(parent, taille=11, gras=False, couleur=texte, **kw):
        return tk.Label(parent, bg=parent["bg"], fg=couleur, font=("Segoe UI", taille, "bold" if gras else "normal"), **kw)

    haut = tk.Frame(fen, bg=carte, padx=16, pady=14)
    haut.pack(fill="x", padx=14, pady=(14, 8))
    label(haut, 9, couleur=doux, text="GIMALY TRADING  -  XAUUSD").pack(anchor="w")
    etat = label(haut, 20, True, text="...")
    etat.pack(anchor="w", pady=(4, 0))
    compte = label(haut, 10, couleur=doux, text="", justify="left")
    compte.pack(anchor="w", pady=(6, 0))

    jour = tk.Frame(fen, bg=carte, padx=16, pady=12)
    jour.pack(fill="x", padx=14, pady=4)
    label(jour, 9, couleur=doux, text="AUJOURD'HUI").pack(anchor="w")
    resume = label(jour, 13, True, text="", justify="left")
    resume.pack(anchor="w", pady=(4, 0))
    ouvert = label(jour, 10, couleur=doux, text="", justify="left")
    ouvert.pack(anchor="w", pady=(4, 0))

    barre = tk.Frame(fen, bg=fond)
    barre.pack(fill="x", padx=14, pady=8)
    message = label(fen, 10, couleur=doux, text="", wraplength=520, justify="left")

    def agir(fonction, confirmer=None):
        if confirmer and not messagebox.askyesno("Confirmer", confirmer):
            return
        message.config(text=fonction())
        rafraichir(False)

    def bouton(texte_bouton, commande, couleur):
        b = tk.Button(barre, text=texte_bouton, command=commande, bg=couleur, fg="#0b1118", relief="flat",
                      font=("Segoe UI", 10, "bold"), padx=10, pady=8, activebackground=couleur, cursor="hand2")
        b.pack(side="left", expand=True, fill="x", padx=3)
        return b

    bouton("DEMARRER", lambda: agir(demarrer), "#34d27b")
    b_pause = bouton("PAUSE", lambda: agir(basculer_pause), "#f0a030")
    bouton("ARRETER", lambda: agir(arreter_tout, "Arreter le bot ? Les trades ouverts restent ouverts avec leur SL et leur TP."),
           "#ff6b6b")
    message.pack(fill="x", padx=18)

    label(fen, 9, couleur=doux, text="DERNIERS TRADES").pack(anchor="w", padx=18, pady=(10, 2))
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", background=carte, fieldbackground=carte, foreground=texte, rowheight=24, borderwidth=0)
    style.configure("Treeview.Heading", background=fond, foreground=doux, borderwidth=0)
    table = ttk.Treeview(fen, columns=("heure", "sens", "res", "r"), show="headings", height=8)
    for c, t, w in (("heure", "Heure", 120), ("sens", "Sens", 80), ("res", "Resultat", 190), ("r", "R", 70)):
        table.heading(c, text=t)
        table.column(c, width=w, anchor="w" if c != "r" else "e")
    table.pack(fill="both", expand=True, padx=14, pady=(0, 14))

    def rafraichir(replanifier=True):
        texte_etat, couleur = etat_bot()
        etat.config(text=texte_etat, fg=couleur)
        b_pause.config(text="REPRENDRE" if STOP_TRADES.exists() else "PAUSE")
        m = mt5_etat
        if m.get("erreur"):
            compte.config(text="MetaTrader 5 : " + m["erreur"], fg="#ff6b6b")
        else:
            genre = "DEMO" if m["demo"] else "COMPTE REEL (le bot ne tourne pas)"
            compte.config(text=f"Compte {genre} {m['login']}  -  solde {m['solde']:.2f} {m['devise']}  -  "
                               f"equity {m['equity']:.2f}", fg=doux if m["demo"] else "#ff6b6b")
        finis, ouverts, derniers = trades_du_jour()
        if finis:
            rs = [t["R"] for t in finis]
            gains = [t["gain"] for t in finis if t["gain"] is not None]
            gagnants = sum(r > 0 for r in rs)
            euro = f"  -  {sum(gains):+.2f} {m.get('devise', '')}" if gains else ""
            resume.config(text=f"{len(finis)} trade(s) : {gagnants} gagnant(s) / {len(finis) - gagnants} perdant(s)\n"
                               f"{sum(rs):+.2f} R{euro}")
        else:
            resume.config(text="Aucun trade termine aujourd'hui")
        flottant = ""
        if not m.get("erreur"):
            flottant = f"{m['positions']} position(s) XAUUSD ouverte(s)  -  flottant {m['flottant']:+.2f} {m['devise']}"
        ouvert.config(text=flottant)
        table.delete(*table.get_children())
        for t in derniers:
            table.insert("", "end", values=(t["ouv"].strftime("%d/%m %H:%M"), t["sens"], t["res"],
                                            "" if t["R"] is None else f"{t['R']:+.2f}"))
        if replanifier:
            fen.after(RAFRAICHIR_MS, rafraichir)

    threading.Thread(target=boucle_mt5, daemon=True).start()
    rafraichir()
    fen.mainloop()


if __name__ == "__main__":
    main()
