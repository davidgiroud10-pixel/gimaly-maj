# -*- coding: utf-8 -*-
"""Bilan simple et lisible, pret a etre colle dans un message (utilise par les boutons BILAN du panneau).

  python bilan_simple.py [jour|semaine|mois|tout]

Lit seulement trades_bot.csv : ne modifie rien, aucun identifiant de compte.
"""
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

RACINE = Path(__file__).resolve().parent
NOMS = {"jour": "Aujourd'hui", "semaine": "Cette semaine", "mois": "Ce mois-ci", "tout": "Depuis le debut"}
JOURS = ("lun", "mar", "mer", "jeu", "ven", "sam", "dim")


def debut(periode, maintenant=None):
    n = maintenant or datetime.now()
    minuit = n.replace(hour=0, minute=0, second=0, microsecond=0)
    if periode == "jour":
        return minuit
    if periode == "semaine":
        return minuit - timedelta(days=minuit.weekday())
    if periode == "mois":
        return minuit.replace(day=1)
    return datetime(2000, 1, 1)


def version():
    try:
        return json.loads((RACINE / "VERSION.json").read_text(encoding="utf-8-sig")).get("version", "?")
    except (OSError, ValueError):
        return "?"


def texte_bilan(periode="jour", maintenant=None):
    n = maintenant or datetime.now()
    d = debut(periode, n)
    en_tete = f"BILAN GIMALY - {NOMS.get(periode, periode)}"
    if periode != "jour" and periode != "tout":
        en_tete += f" (depuis le {d:%d/%m/%Y})"
    elif periode == "jour":
        en_tete += f" ({d:%d/%m/%Y})"
    lignes = [en_tete, f"Version {version()}", ""]
    try:
        import bilan_reel
        trades = bilan_reel.charger(d)
    except OSError:
        lignes.append("Pas encore de trade : le bot n'a pas encore pris de position.")
        return "\n".join(lignes)
    finis = sorted((t for t in trades if t["R"] is not None), key=lambda t: t["ouv"])
    ouverts = [t for t in trades if t["R"] is None]
    if not finis:
        lignes.append("Aucun trade termine sur cette periode.")
        if ouverts:
            lignes.append(f"{len(ouverts)} trade(s) en cours.")
        return "\n".join(lignes)
    rs = [t["R"] for t in finis]
    gagnants = sum(r > 0 for r in rs)
    gains = [t["gain"] for t in finis if t["gain"] is not None]
    lignes.append(f"Trades termines : {len(finis)}  ({gagnants} gagnant(s) / {len(finis) - gagnants} perdant(s))")
    lignes.append(f"Resultat : {sum(rs):+.2f} R" + (f"   |   {sum(gains):+.2f} en argent (devise du compte)" if gains else ""))
    lignes.append(f"Moyenne par trade : {sum(rs) / len(rs):+.2f} R   |   taux de reussite : {gagnants / len(finis):.0%}")
    hors = sum(bilan_reel.manuel(t) for t in finis)
    if hors:
        lignes.append(f"Sorties a la main ou anticipees : {hors}")
    if ouverts:
        lignes.append(f"En cours : {len(ouverts)} trade(s) ouvert(s)")
    if periode in ("semaine", "mois", "tout"):
        jours = {}
        for t in finis:
            jours.setdefault(t["ouv"].date(), []).append(t["R"])
        lignes += ["", "Par jour :"]
        for j in sorted(jours)[-31:]:
            r = jours[j]
            lignes.append(f"  {j:%d/%m} {JOURS[j.weekday()]}   {len(r):>2} trade(s)   {sum(r):+6.2f} R")
    lignes += ["", "Detail des trades :" if len(finis) <= 15 else "15 derniers trades :"]
    for t in finis[-15:]:
        sens = "ACHAT" if str(t["sens"]).lower().startswith(("a", "b")) else "VENTE"
        lignes.append(f"  {t['ouv']:%d/%m %H:%M}  {sens:<6}{str(t['res']):<20}{t['R']:>+6.2f} R")
    return "\n".join(lignes)


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] in NOMS else "jour"
    print(texte_bilan(p))
